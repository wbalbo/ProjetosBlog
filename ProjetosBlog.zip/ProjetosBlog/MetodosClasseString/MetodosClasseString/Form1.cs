﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MetodosClasseString
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExibir_Click(object sender, EventArgs e)
        {
            //Format
            //txtTexto.Text = String.Format("Posso incluir o número {0}, {1} e {2} aqui!", 10, 20, 30);

            //IsNullOrEmpty
            //if (String.IsNullOrEmpty(txtTexto.Text))
            //{
            //    MessageBox.Show("Campo vazio!");
            //}
            
            //Contains
            //if (txtTexto.Text.Contains("String"))
            //{
            //    MessageBox.Show("Você digitou String!");
            //}

            //Equals
            //if (txtTexto.Text.Equals("String"))
            //{
            //    MessageBox.Show("Você digitou String!");
            //}

            //Remove
            //MessageBox.Show(txtTexto.Text.Remove(3));

            //Replace
            //if (txtTexto.Text.Equals("String"))
            //{
            //    MessageBox.Show(txtTexto.Text.Replace("String", "Integer"));
            //}

            //Substring
            //MessageBox.Show(txtTexto.Text.Substring(6));

            //ToLower
            //MessageBox.Show(txtTexto.Text.ToLower());

            //ToString
            //int valor = 100;
            //MessageBox.Show(valor.ToString());

            //ToUpper
            //MessageBox.Show(txtTexto.Text.ToUpper());
        }
    }
}
