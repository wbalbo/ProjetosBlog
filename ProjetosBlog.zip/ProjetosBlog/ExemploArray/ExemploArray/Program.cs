﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace ExemploArray
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable objTabela = new Hashtable();
            objTabela.Add(1, "Joãozinho");
            objTabela.Add(2, "Mariazinha");
        }
    }
}
