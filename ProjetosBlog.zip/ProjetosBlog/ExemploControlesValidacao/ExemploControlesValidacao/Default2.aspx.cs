﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExemploControlesValidacao
{
    public partial class Default2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Label1.Text = "Resultado: " + TextBox1.Text;
        }

        protected void btnComparar_Click(object sender, EventArgs e)
        {
            lblMensagem.Text = "O email digitado foi: " + txtValor1.Text;
        }

        public void Validar(object source, ServerValidateEventArgs args)
        {
            if (int.Parse(txtIdade.Text) > 17)
            {
                args.IsValid = true;
            }
            else
            {
                args.IsValid = false;
            }
        }

        protected void btnValidar_Click(object sender, EventArgs e)
        {
            lblInformacao.Text = "A idade informada é: " + txtIdade.Text;
        }        
    }
}
