﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;

namespace Utilidades
{
    public class UTGerais
    {
        public void ExibirJavascript(Page pagina, string titulo, string mensagem, bool usarScripts = true)
        {
            ScriptManager.RegisterClientScriptBlock(pagina, pagina.GetType(), titulo, mensagem, usarScripts);
        }
    }
}
