﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploEnumeradores
{
    class Program
    {
        enum diasDaSemana : short { Domingo = 1, Segunda, Terca, Quarta, Quinta, Sexta, Sabado }; 

        static void Main(string[] args)
        {
            for (int i = 1; i < 7; i++)
            {
                Console.WriteLine(i + " - " + Enum.GetName(typeof(diasDaSemana), i));
            }

            Console.ReadKey();
        }
    }
}
