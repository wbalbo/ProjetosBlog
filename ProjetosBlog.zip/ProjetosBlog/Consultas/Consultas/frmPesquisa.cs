﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Consultas
{
    public partial class frmPesquisa : Consultas.frmPesquisaBase
    {
        public frmPesquisa()
        {
            InitializeComponent();
        }

        public override void Pesquisar()
        {
            try
            {
                //instancio a Classe e o DataTable
                AcessoDadosConsulta acesso = new AcessoDadosConsulta(0);
                DataTable dt = new DataTable();

                //verifico qual RadioButton está checado, dependendo de qual for, chamo o método adequado
                if (rbtCodigo.Checked)
                {
                    dt = acesso.PesquisaID(int.Parse(txtPesquisa.Text));
                }
                else if (rbtDescricao.Checked)
                {
                    dt = acesso.PesquisaNomePaciente("%" + txtPesquisa.Text + "%");
                }
                else if (rbtNomeMedico.Checked)
                {
                    dt = acesso.PesquisaNomeMedico("%" + txtPesquisa.Text + "%");
                }

                //crio um novo método para carregar os itens no ListView
                Carregar(dt);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void Carregar(DataTable dt)
        {
            try
            {
                //limpo os registros do ListView
                lstPesquisa.Items.Clear();

                //carrego os dados no ListView            
                foreach (DataRow dr in dt.Rows)
                {
                    //para cada linha de meu DataTable, insiro uma linha no ListView
                    //instancio o ListViewItem, adiciono os itens e subitens, referentes
                    //aos campos que estou pesquisando em meu ListView
                    ListViewItem item = new ListViewItem();
                    item.Text = dr["IDCONSULTA"].ToString();
                    item.SubItems.Add(dr["NOMEPACIENTE"].ToString());
                    item.SubItems.Add(dr["NOMEMEDICO"].ToString());
                    item.SubItems.Add(string.Format("{0:dd/MM/yyyy}", dr["DATACONSULTA"]));
                    item.SubItems.Add(string.Format("{0:HH:mm}", dr["HORAINICIO"]));

                    //aqui adiciono a varíavel instanciada item
                    //carregada com o item e subitem ao ListView
                    lstPesquisa.Items.Add(item);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }
    }
}
