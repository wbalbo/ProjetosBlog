﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
//using Consultas.dsConsultaTableAdapters;

namespace Consultas
{
    public partial class frmPacienteHerdado : Consultas.frmBase
    {
        public frmPacienteHerdado()
        {
            InitializeComponent();
        }

        private void frmPacienteHerdado_Load(object sender, EventArgs e)
        {

        }

        public override void CarregaValores()
        {
            try
            {
                //Instancio a classe e o DataRow
                AcessoDadosPaciente acesso = new AcessoDadosPaciente(_nCodGenerico);
                DataRow dr = acesso.PesquisaID();

                //Se o DataRow for diferente de nulo, preencho as propriedades
                if (dr != null)
                {
                    lblCodigo.Text = dr["IDPACIENTE"].ToString();
                    txtNome.Text = dr["NOMEPACIENTE"].ToString();
                    txtTelefone.Text = dr["TELEFONE"].ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override bool Excluir()
        {
            try
            {
                AcessoDadosPaciente acesso = new AcessoDadosPaciente(_nCodGenerico);

                return acesso.Delete();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override bool Localizar()
        {
            try
            {
                bool bLocalizar = false;
                frmPesquisaPaciente frmPesquisa = new frmPesquisaPaciente();
                //faço abaixo uma verificação, se o usuário clicar em OK
                //minha variável bLocalizar recebe o sCdCodigo
                if (frmPesquisa.ShowDialog() == DialogResult.OK)
                {
                    bLocalizar = (frmPesquisa.sCdCodigo != string.Empty);
                    //verifico agora se meu bLocalizar retornou algum registro
                    if (bLocalizar)
                    {
                        _nCodGenerico = int.Parse(frmPesquisa.sCdCodigo);
                    }
                }

                return bLocalizar;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override bool Salvar()
        {
            try
            {
                bool bSalvar = false;

                //Instancio a classe de Acesso a Dados
                AcessoDadosPaciente acesso = new AcessoDadosPaciente();

                //Preencho as propriedades da classe, que recebem os valores da label e textbox do form
                if (sStatus == StatusCadastro.scEditando)
                {
                    acesso.nCodPaciente = int.Parse(lblCodigo.Text);
                }
                acesso.sNomePaciente = txtNome.Text;
                acesso.sNumTelefone = txtTelefone.Text;

                //Minha variável bSalvar recebe a o método Salvar, da classe instanciada, recebendo como
                //parâmetro o Status Inserindo, ou seja, ele só irá gravar os dados se o Status for Inserindo
                bSalvar = (acesso.Salvar(sStatus == StatusCadastro.scInserindo));

                return bSalvar;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }
    }
}
