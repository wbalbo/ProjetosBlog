﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Consultas
{
    public partial class frmConsultaHerdado : Consultas.frmBase
    {
        public frmConsultaHerdado()
        {
            InitializeComponent();
        }

        public int _nCodPaciente;
        public int _nCodMedico;

        public override void CarregaValores()
        {
            try
            {
                //Instancio a classe e o DataRow, que recebe o método PesquisaID de minha classe
                AcessoDadosConsulta objConsulta = new AcessoDadosConsulta(_nCodGenerico);
                DataRow dr = objConsulta.PesquisaID();

                //Se o DataRow for diferente de nulo, preencho as propriedades
                if (dr != null)
                {
                    dtConsulta.Value = DateTime.Parse(dr["DATACONSULTA"].ToString());
                    dtHrInicio.Value = DateTime.Parse(dr["HORAINICIO"].ToString());
                    dtHrFim.Value = DateTime.Parse(dr["HORAFIM"].ToString());
                    txtObservacoes.Text = dr["OBSERVACOES"].ToString();
                    txtNomeMedico.Text = dr["NOMEMEDICO"].ToString();
                    txtNomePaciente.Text = dr["NOMEPACIENTE"].ToString();
                    _nCodMedico = int.Parse(dr["IDMEDICO"].ToString());
                    _nCodPaciente = int.Parse(dr["IDPACIENTE"].ToString());
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void ConsultarMedico()
        {
            frmPesquisaMedico frmPesquisaMedico = new frmPesquisaMedico();

            try
            {
                if (frmPesquisaMedico.ShowDialog() == DialogResult.OK)
                {
                    if (frmPesquisaMedico.sCdCodigo != string.Empty)
                    {
                        _nCodMedico = int.Parse(frmPesquisaMedico.sCdCodigo);
                        txtNomeMedico.Text = frmPesquisaMedico.sDsNome;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void ConsultarPaciente()
        {
            frmPesquisaPaciente frmPesquisaPaciente = new frmPesquisaPaciente();

            try
            {
                if (frmPesquisaPaciente.ShowDialog() == DialogResult.OK)
                {
                    if (frmPesquisaPaciente.sCdCodigo != string.Empty)
                    {
                        _nCodPaciente = int.Parse(frmPesquisaPaciente.sCdCodigo);
                        txtNomePaciente.Text = frmPesquisaPaciente.sDsNome;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override bool Excluir()
        {
            try
            {
                AcessoDadosConsulta objConsulta = new AcessoDadosConsulta(_nCodGenerico);

                return objConsulta.Delete();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override bool Localizar()
        {
            try
            {
                bool bLocalizar = false;

                frmPesquisa frmPesquisa = new frmPesquisa();

                //faço abaixo uma verificação, se o usuário clicar em OK
                //minha variável bLocalizar recebe o sCdCodigo
                if (frmPesquisa.ShowDialog() == DialogResult.OK)
                {
                    bLocalizar = (frmPesquisa.sCdCodigo != string.Empty);

                    //verifico agora se meu bLocalizar retornou algum registro
                    if (bLocalizar)
                    {
                        _nCodGenerico = int.Parse(frmPesquisa.sCdCodigo);
                    }
                }

                return bLocalizar;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override bool Salvar()
        {
            try
            {
                bool bSalvar = false;

                //Instancio a classe de Acesso a Dados
                AcessoDadosConsulta objConsulta = new AcessoDadosConsulta(_nCodGenerico);

                //Se estiver editando, minha variável nCodConsulta, da classe de Acesso a Dados recebe o _nCodGenerico
                if (sStatus == StatusCadastro.scEditando)
                {
                    objConsulta.nCodConsulta = _nCodGenerico;
                }
                
                //Preencho os valores do form
                objConsulta.nCodMedico = _nCodMedico;
                objConsulta.nCodPaciente = _nCodPaciente;
                objConsulta.dDtConsulta = dtConsulta.Value;
                objConsulta.dHrInicio = DateTime.Parse(dtHrInicio.Value.ToShortTimeString());
                objConsulta.dHrFim = DateTime.Parse(dtHrFim.Value.ToShortTimeString());
                objConsulta.sObservacoes = txtObservacoes.Text;
                objConsulta.bAtivo = true;

                bSalvar = (objConsulta.Salvar(sStatus == StatusCadastro.scInserindo));

                return bSalvar;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void btnConsultarMedico_Click(object sender, EventArgs e)
        {
            ConsultarMedico();
        }

        private void btnConsultarPaciente_Click(object sender, EventArgs e)
        {
            ConsultarPaciente();
        }
    }
}
