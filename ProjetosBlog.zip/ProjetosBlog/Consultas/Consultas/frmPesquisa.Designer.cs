﻿namespace Consultas
{
    partial class frmPesquisa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbtNomeMedico = new System.Windows.Forms.RadioButton();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // rbtDescricao
            // 
            this.rbtDescricao.Size = new System.Drawing.Size(113, 17);
            this.rbtDescricao.Text = "Nome do Paciente";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtNomeMedico);
            this.groupBox1.Controls.SetChildIndex(this.rbtNomeMedico, 0);
            this.groupBox1.Controls.SetChildIndex(this.rbtCodigo, 0);
            this.groupBox1.Controls.SetChildIndex(this.rbtDescricao, 0);
            // 
            // lstPesquisa
            // 
            this.lstPesquisa.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Nome do Paciente";
            this.columnHeader2.Width = 160;
            // 
            // rbtNomeMedico
            // 
            this.rbtNomeMedico.AutoSize = true;
            this.rbtNomeMedico.Location = new System.Drawing.Point(16, 66);
            this.rbtNomeMedico.Name = "rbtNomeMedico";
            this.rbtNomeMedico.Size = new System.Drawing.Size(106, 17);
            this.rbtNomeMedico.TabIndex = 1;
            this.rbtNomeMedico.TabStop = true;
            this.rbtNomeMedico.Text = "Nome do Médico";
            this.rbtNomeMedico.UseVisualStyleBackColor = true;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Nome do Médico";
            this.columnHeader3.Width = 150;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Data";
            this.columnHeader4.Width = 80;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Hora";
            // 
            // frmPesquisa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(554, 467);
            this.Name = "frmPesquisa";
            this.Text = "Pesquisa";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbtNomeMedico;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
    }
}
