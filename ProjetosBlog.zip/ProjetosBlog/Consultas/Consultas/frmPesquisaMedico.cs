﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Consultas
{
    public partial class frmPesquisaMedico : Consultas.frmPesquisaBase
    {
        public frmPesquisaMedico()
        {
            InitializeComponent();
        }

        public override void Pesquisar()
        {
            try
            {
                AcessoDadosMedico acesso = new AcessoDadosMedico();
                DataTable dt = new DataTable();

                if (rbtCodigo.Checked)
                    dt = acesso.PesquisaID(int.Parse(txtPesquisa.Text));
                else
                    dt = acesso.PesquisaNome("%" + txtPesquisa.Text + "%");

                CarregarItens(dt);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }
    }
}
