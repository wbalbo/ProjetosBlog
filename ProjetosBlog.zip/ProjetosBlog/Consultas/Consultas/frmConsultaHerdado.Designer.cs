﻿namespace Consultas
{
    partial class frmConsultaHerdado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmConsultaHerdado));
            this.lblNomePaciente = new System.Windows.Forms.Label();
            this.lblNomeMedico = new System.Windows.Forms.Label();
            this.lblDtConsulta = new System.Windows.Forms.Label();
            this.lblHrInicio = new System.Windows.Forms.Label();
            this.lblObservacoes = new System.Windows.Forms.Label();
            this.lblHrFim = new System.Windows.Forms.Label();
            this.txtNomePaciente = new System.Windows.Forms.TextBox();
            this.txtNomeMedico = new System.Windows.Forms.TextBox();
            this.dtConsulta = new System.Windows.Forms.DateTimePicker();
            this.dtHrInicio = new System.Windows.Forms.DateTimePicker();
            this.dtHrFim = new System.Windows.Forms.DateTimePicker();
            this.txtObservacoes = new System.Windows.Forms.TextBox();
            this.btnConsultarPaciente = new System.Windows.Forms.Button();
            this.btnConsultarMedico = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // lblNomePaciente
            // 
            this.lblNomePaciente.AutoSize = true;
            this.lblNomePaciente.Location = new System.Drawing.Point(13, 49);
            this.lblNomePaciente.Name = "lblNomePaciente";
            this.lblNomePaciente.Size = new System.Drawing.Size(95, 13);
            this.lblNomePaciente.TabIndex = 2;
            this.lblNomePaciente.Text = "Nome do Paciente";
            // 
            // lblNomeMedico
            // 
            this.lblNomeMedico.AutoSize = true;
            this.lblNomeMedico.Location = new System.Drawing.Point(13, 74);
            this.lblNomeMedico.Name = "lblNomeMedico";
            this.lblNomeMedico.Size = new System.Drawing.Size(88, 13);
            this.lblNomeMedico.TabIndex = 2;
            this.lblNomeMedico.Text = "Nome do Médico";
            // 
            // lblDtConsulta
            // 
            this.lblDtConsulta.AutoSize = true;
            this.lblDtConsulta.Location = new System.Drawing.Point(12, 122);
            this.lblDtConsulta.Name = "lblDtConsulta";
            this.lblDtConsulta.Size = new System.Drawing.Size(89, 13);
            this.lblDtConsulta.TabIndex = 2;
            this.lblDtConsulta.Text = "Data da Consulta";
            // 
            // lblHrInicio
            // 
            this.lblHrInicio.AutoSize = true;
            this.lblHrInicio.Location = new System.Drawing.Point(13, 153);
            this.lblHrInicio.Name = "lblHrInicio";
            this.lblHrInicio.Size = new System.Drawing.Size(34, 13);
            this.lblHrInicio.TabIndex = 2;
            this.lblHrInicio.Text = "Início";
            // 
            // lblObservacoes
            // 
            this.lblObservacoes.AutoSize = true;
            this.lblObservacoes.Location = new System.Drawing.Point(13, 187);
            this.lblObservacoes.Name = "lblObservacoes";
            this.lblObservacoes.Size = new System.Drawing.Size(70, 13);
            this.lblObservacoes.TabIndex = 2;
            this.lblObservacoes.Text = "Observações";
            // 
            // lblHrFim
            // 
            this.lblHrFim.AutoSize = true;
            this.lblHrFim.Location = new System.Drawing.Point(266, 153);
            this.lblHrFim.Name = "lblHrFim";
            this.lblHrFim.Size = new System.Drawing.Size(23, 13);
            this.lblHrFim.TabIndex = 2;
            this.lblHrFim.Text = "Fim";
            // 
            // txtNomePaciente
            // 
            this.txtNomePaciente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomePaciente.Location = new System.Drawing.Point(114, 49);
            this.txtNomePaciente.Name = "txtNomePaciente";
            this.txtNomePaciente.ReadOnly = true;
            this.txtNomePaciente.Size = new System.Drawing.Size(353, 20);
            this.txtNomePaciente.TabIndex = 3;
            // 
            // txtNomeMedico
            // 
            this.txtNomeMedico.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeMedico.Location = new System.Drawing.Point(114, 77);
            this.txtNomeMedico.Name = "txtNomeMedico";
            this.txtNomeMedico.ReadOnly = true;
            this.txtNomeMedico.Size = new System.Drawing.Size(353, 20);
            this.txtNomeMedico.TabIndex = 3;
            // 
            // dtConsulta
            // 
            this.dtConsulta.CustomFormat = "dd/MM/yyyy";
            this.dtConsulta.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtConsulta.Location = new System.Drawing.Point(114, 113);
            this.dtConsulta.Name = "dtConsulta";
            this.dtConsulta.Size = new System.Drawing.Size(85, 20);
            this.dtConsulta.TabIndex = 4;
            // 
            // dtHrInicio
            // 
            this.dtHrInicio.CustomFormat = "HH:mm";
            this.dtHrInicio.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtHrInicio.Location = new System.Drawing.Point(114, 149);
            this.dtHrInicio.Name = "dtHrInicio";
            this.dtHrInicio.Size = new System.Drawing.Size(55, 20);
            this.dtHrInicio.TabIndex = 4;
            // 
            // dtHrFim
            // 
            this.dtHrFim.CustomFormat = "HH:mm";
            this.dtHrFim.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtHrFim.Location = new System.Drawing.Point(295, 149);
            this.dtHrFim.Name = "dtHrFim";
            this.dtHrFim.Size = new System.Drawing.Size(55, 20);
            this.dtHrFim.TabIndex = 4;
            // 
            // txtObservacoes
            // 
            this.txtObservacoes.Location = new System.Drawing.Point(16, 203);
            this.txtObservacoes.Multiline = true;
            this.txtObservacoes.Name = "txtObservacoes";
            this.txtObservacoes.Size = new System.Drawing.Size(493, 50);
            this.txtObservacoes.TabIndex = 5;
            // 
            // btnConsultarPaciente
            // 
            this.btnConsultarPaciente.ImageKey = "sql_query16.bmp";
            this.btnConsultarPaciente.ImageList = this.imageList1;
            this.btnConsultarPaciente.Location = new System.Drawing.Point(473, 44);
            this.btnConsultarPaciente.Name = "btnConsultarPaciente";
            this.btnConsultarPaciente.Size = new System.Drawing.Size(36, 23);
            this.btnConsultarPaciente.TabIndex = 6;
            this.btnConsultarPaciente.UseVisualStyleBackColor = true;
            this.btnConsultarPaciente.Click += new System.EventHandler(this.btnConsultarPaciente_Click);
            // 
            // btnConsultarMedico
            // 
            this.btnConsultarMedico.ImageKey = "sql_query16.bmp";
            this.btnConsultarMedico.ImageList = this.imageList1;
            this.btnConsultarMedico.Location = new System.Drawing.Point(473, 74);
            this.btnConsultarMedico.Name = "btnConsultarMedico";
            this.btnConsultarMedico.Size = new System.Drawing.Size(36, 23);
            this.btnConsultarMedico.TabIndex = 6;
            this.btnConsultarMedico.UseVisualStyleBackColor = true;
            this.btnConsultarMedico.Click += new System.EventHandler(this.btnConsultarMedico_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Magenta;
            this.imageList1.Images.SetKeyName(0, "sql_query16.bmp");
            // 
            // frmConsultaHerdado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(520, 289);
            this.Controls.Add(this.txtObservacoes);
            this.Controls.Add(this.btnConsultarMedico);
            this.Controls.Add(this.dtConsulta);
            this.Controls.Add(this.dtHrInicio);
            this.Controls.Add(this.btnConsultarPaciente);
            this.Controls.Add(this.lblNomePaciente);
            this.Controls.Add(this.txtNomePaciente);
            this.Controls.Add(this.lblDtConsulta);
            this.Controls.Add(this.txtNomeMedico);
            this.Controls.Add(this.lblHrInicio);
            this.Controls.Add(this.lblNomeMedico);
            this.Controls.Add(this.lblObservacoes);
            this.Controls.Add(this.lblHrFim);
            this.Controls.Add(this.dtHrFim);
            this.Name = "frmConsultaHerdado";
            this.Text = "Cadastro de Consultas";
            this.Controls.SetChildIndex(this.dtHrFim, 0);
            this.Controls.SetChildIndex(this.lblHrFim, 0);
            this.Controls.SetChildIndex(this.lblObservacoes, 0);
            this.Controls.SetChildIndex(this.lblNomeMedico, 0);
            this.Controls.SetChildIndex(this.lblHrInicio, 0);
            this.Controls.SetChildIndex(this.txtNomeMedico, 0);
            this.Controls.SetChildIndex(this.lblDtConsulta, 0);
            this.Controls.SetChildIndex(this.txtNomePaciente, 0);
            this.Controls.SetChildIndex(this.lblNomePaciente, 0);
            this.Controls.SetChildIndex(this.btnConsultarPaciente, 0);
            this.Controls.SetChildIndex(this.dtHrInicio, 0);
            this.Controls.SetChildIndex(this.dtConsulta, 0);
            this.Controls.SetChildIndex(this.btnConsultarMedico, 0);
            this.Controls.SetChildIndex(this.txtObservacoes, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomePaciente;
        private System.Windows.Forms.Label lblNomeMedico;
        private System.Windows.Forms.Label lblDtConsulta;
        private System.Windows.Forms.Label lblHrInicio;
        private System.Windows.Forms.Label lblObservacoes;
        private System.Windows.Forms.Label lblHrFim;
        private System.Windows.Forms.TextBox txtNomePaciente;
        private System.Windows.Forms.TextBox txtNomeMedico;
        private System.Windows.Forms.DateTimePicker dtConsulta;
        private System.Windows.Forms.DateTimePicker dtHrInicio;
        private System.Windows.Forms.DateTimePicker dtHrFim;
        private System.Windows.Forms.TextBox txtObservacoes;
        private System.Windows.Forms.Button btnConsultarPaciente;
        private System.Windows.Forms.Button btnConsultarMedico;
        private System.Windows.Forms.ImageList imageList1;
    }
}
