﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Consultas.dsConsultaTableAdapters;

namespace Consultas
{
    public class AcessoDados
    {
        public virtual bool Salvar(bool bInsert)
        {
            return false;
        }

        public virtual bool Delete()
        {
            return false;
        }

        public virtual DataTable PesquisaID(int nCodGenerico)
        {
            return null;
        }

        public virtual DataRow PesquisaID()
        {
            return null;
        }

        public virtual DataTable PesquisaNome(string sDsNome)
        {
            return null;
        }
    }

    public class AcessoDadosPaciente : AcessoDados
    {
        private int _nCodPaciente;
        private string _sNomePaciente;
        private string _sNumTelefone;

        public int nCodPaciente
        {
            get { return _nCodPaciente; }
            set { _nCodPaciente = value; }
        }
        public string sNomePaciente
        {
            get { return _sNomePaciente; }
            set { _sNomePaciente = value; }
        }
        public string sNumTelefone
        {
            get { return _sNumTelefone; }
            set { _sNumTelefone = value; }
        }

        public AcessoDadosPaciente()
        {

        }

        public AcessoDadosPaciente(int nCodPaciente)
        {
            this.nCodPaciente = nCodPaciente;
        }

        public AcessoDadosPaciente(int nCodPaciente, string sNomePaciente, string sNumTelefone)
        {
            this.nCodPaciente = nCodPaciente;
            this.sNomePaciente = sNomePaciente;
            this.sNumTelefone = sNumTelefone;
        }

        public AcessoDadosPaciente(string sNomePaciente, string sNumTelefone)
        {
            this.sNomePaciente = sNomePaciente;
            this.sNumTelefone = sNumTelefone;
        }

        public override bool Salvar(bool bInsert)
        {
            try
            {
                bool bSalvar = false;

                //Instancio o TableAdapter
                PacienteTableAdapter ta = new PacienteTableAdapter();

                //Comparação: se estiver inserindo (bInsert), chamo o método Insert e passo os parâmetros
                //Senão, chamo o método Update e passo os parâmetros, que são as propriedades declaradas acima
                if (bInsert)
                {
                    bSalvar = (ta.Insert(sNomePaciente, sNumTelefone) > 0);
                }
                else
                {
                    bSalvar = (ta.Update(sNomePaciente, sNumTelefone, nCodPaciente) > 0);
                }

                return bSalvar;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override bool Delete()
        {
            try
            {
                bool bExcluir = false;

                PacienteTableAdapter ta = new PacienteTableAdapter();

                bExcluir = (ta.Delete(nCodPaciente) > 0);

                return bExcluir;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override DataTable PesquisaID(int nCodGenerico)
        {
            try
            {
                dsConsulta.PacienteDataTable dt = new dsConsulta.PacienteDataTable();
                PacienteTableAdapter ta = new PacienteTableAdapter();

                dt = ta.PesquisaID(nCodGenerico);

                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override DataRow PesquisaID()
        {
            try
            {
                return this.PesquisaID(nCodPaciente).Rows[0];
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }

        }

        public override DataTable PesquisaNome(string sDsNome)
        {
            try
            {
                dsConsulta.PacienteDataTable dt = new dsConsulta.PacienteDataTable();
                PacienteTableAdapter ta = new PacienteTableAdapter();

                dt = ta.PesquisaNome(sDsNome);

                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }


        }

        public string PesquisaNome(int nCodGenerico)
        {
            //Crio um DataTable, que recebe meu método PesquisaID            
            DataTable dt = PesquisaID(nCodGenerico);

            //Verifico se meu DataTable contém linhas, se tiver retorno o método PesquisaID, 
            //Exibindo a primeira linha e a coluna com o nome do Paciente, convertido para string.
            //Se não tiver linhas retorno uma string vazia.
            if (dt.Rows.Count > 0)
            {
                return PesquisaID(nCodGenerico).Rows[0]["NOMEPACIENTE"].ToString();
            }
            else
            {
                return string.Empty;
            }
        }

        public DataTable Pesquisar()
        {
            try
            {
                //instancio o TableAdapter e o DataTable
                dsConsulta.PacienteDataTable dt = new dsConsulta.PacienteDataTable();
                PacienteTableAdapter ta = new PacienteTableAdapter();

                //uso o método Fill do TableAdapter, passando como parâmetro o DataTable
                ta.Fill(dt);

                //retorno o DataTable preenchido
                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }
    }

    public class AcessoDadosMedico : AcessoDados
    {
        private int _nCodMedico;
        private string _sNomeMedico;
        private string _sNumCRM;

        public string sNumCRM
        {
            get { return _sNumCRM; }
            set { _sNumCRM = value; }
        }
        public string sNomeMedico
        {
            get { return _sNomeMedico; }
            set { _sNomeMedico = value; }
        }
        public int nCodMedico
        {
            get { return _nCodMedico; }
            set { _nCodMedico = value; }
        }

        public AcessoDadosMedico()
        {

        }

        public AcessoDadosMedico(int nCdMedico)
        {
            this.nCodMedico = nCdMedico;
        }

        public AcessoDadosMedico(int nCodMedico, string sNomeMedico, string sNumCRM)
        {
            this.nCodMedico = nCodMedico;
            this.sNomeMedico = sNomeMedico;
            this.sNumCRM = sNumCRM;
        }

        public AcessoDadosMedico(string sNomeMedico, string sNumCRM)
        {
            this.sNomeMedico = sNomeMedico;
            this.sNumCRM = sNumCRM;
        }

        public override bool Salvar(bool bInsert)
        {
            try
            {
                bool bSalvar = false;

                MedicoTableAdapter ta = new MedicoTableAdapter();

                if (bInsert)
                    bSalvar = (ta.Insert(sNomeMedico, sNumCRM) > 0);
                else
                    bSalvar = (ta.Update(sNomeMedico, sNumCRM, nCodMedico) > 0);
                return bSalvar;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override bool Delete()
        {
            try
            {
                bool bExcluir = false;
                MedicoTableAdapter ta = new MedicoTableAdapter();

                bExcluir = (ta.Delete(nCodMedico) > 0);

                return bExcluir;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override DataTable PesquisaID(int nCdGenerico)
        {
            try
            {
                dsConsulta.MedicoDataTable dt = new dsConsulta.MedicoDataTable();
                MedicoTableAdapter ta = new MedicoTableAdapter();

                ta.PesquisaID(dt, nCdGenerico);

                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override DataRow PesquisaID()
        {
            try
            {
                return this.PesquisaID(nCodMedico).Rows[0];
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override DataTable PesquisaNome(string sDsNome)
        {
            try
            {
                dsConsulta.MedicoDataTable dt = new dsConsulta.MedicoDataTable();
                MedicoTableAdapter ta = new MedicoTableAdapter();

                ta.PesquisaNome(dt, sDsNome);

                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public string PesquisaNome(int nCodGenerico)
        {
            //Crio um DataTable, que recebe meu método PesquisaID            
            DataTable dt = PesquisaID(nCodGenerico);

            //Verifico se meu DataTable contém linhas, se tiver retorno o método PesquisaID, 
            //Exibindo a primeira linha e a coluna com o nome do Médico, convertido para string.
            //Se não tiver linhas retorno uma string vazia.
            if (dt.Rows.Count > 0)
            {
                return PesquisaID(nCodGenerico).Rows[0]["NOMEMEDICO"].ToString();
            }
            else
            {
                return string.Empty;
            }
        }
    }

    public class AcessoDadosConsulta : AcessoDados
    {
        public int nCodConsulta { get; set; }
        public int nCodMedico { get; set; }
        public int nCodPaciente { get; set; }
        public DateTime dDtConsulta { get; set; }
        public DateTime dHrInicio { get; set; }
        public DateTime dHrFim { get; set; }
        public string sObservacoes { get; set; }
        public bool bAtivo { get; set; }

        public AcessoDadosConsulta(int nCodConsulta)
        {
            this.nCodConsulta = nCodConsulta;
        }

        public override bool Salvar(bool bInsert)
        {
            try
            {
                //instancio o TableAdapter
                ConsultaTableAdapter ta = new ConsultaTableAdapter();

                //crio uma variável auxiliar, que será retornada preenchida no fim do método
                bool bSalvar = false;

                //verifico, se estiver inserindo, minha variável bSalvar recebe o método Insert
                //do TableAdapter, passando como parâmetro as propriedades criadas no começo da classe
                if (bInsert)
                {
                    bSalvar = (ta.Insert(nCodMedico, nCodPaciente, dDtConsulta,
                                   dHrInicio, dHrFim, sObservacoes, true) > 0);
                }
                //senão, uso o método Update e passo a propriedade bAtivo como parâmetro do método
                else
                {
                    bSalvar = (ta.Update(nCodMedico, nCodPaciente, dDtConsulta, dHrInicio,
                                         dHrFim, sObservacoes, bAtivo, nCodConsulta) > 0);
                }

                return bSalvar;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override bool Delete()
        {
            try
            {
                //instancio o TableAdapter
                ConsultaTableAdapter ta = new ConsultaTableAdapter();

                //retorno o método Delete passando a propriedade nCodConsulta como parâmetro
                return (ta.Delete(nCodConsulta) > 0);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override DataTable PesquisaID(int nCodGenerico)
        {
            try
            {
                //instancio o DataTable e o TableAdapter
                dsConsulta.PesquisasDataTable dt = new dsConsulta.PesquisasDataTable();
                PesquisasTableAdapter ta = new PesquisasTableAdapter();

                //uso o método PesquisaID, passando como parâmetro o dt e a variável nCodGenerico
                ta.PesquisaID(dt, nCodGenerico);

                //retorno o DataTable preenchido
                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override DataRow PesquisaID()
        {
            try
            {
                //retorno apenas a primeira linha de minha consulta
                return this.PesquisaID(nCodConsulta).Rows[0];
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public DataTable PesquisaNomePaciente(string sDsNomePaciente)
        {
            try
            {
                //instancio o DataTable e o TableAdapter
                dsConsulta.PesquisasDataTable dt = new dsConsulta.PesquisasDataTable();
                PesquisasTableAdapter ta = new PesquisasTableAdapter();

                //uso o método PesquisaNomePaciente, passando como parâmetro o dt 
                //e os caracteres coringas, concatenados com a variável sDsNomePaciente
                ta.PesquisaNomePaciente(dt, "%" + sDsNomePaciente + "%");

                //retorno o DataTable preenchido
                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public DataTable PesquisaNomeMedico(string sDsNomeMedico)
        {
            try
            {
                //instancio o DataTable e o TableAdapter
                dsConsulta.PesquisasDataTable dt = new dsConsulta.PesquisasDataTable();
                PesquisasTableAdapter ta = new PesquisasTableAdapter();

                //uso o método PesquisaNomePaciente, passando como parâmetro o dt 
                //e os caracteres coringas, concatenados com a variável sDsNomeMedico
                ta.PesquisaNomeMedico(dt, "%" + sDsNomeMedico + "%");

                //retorno o DataTable preenchido
                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public DataTable Pesquisar()
        {
            try
            {
                //instancio o TableAdapter e o DataTable
                dsConsulta.PesquisasDataTable dt = new dsConsulta.PesquisasDataTable();
                PesquisasTableAdapter ta = new PesquisasTableAdapter();

                //uso o método Fill do TableAdapter, passando como parâmetro o DataTable
                ta.Pesquisar(dt);

                //retorno o DataTable preenchido
                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }
    }
}
