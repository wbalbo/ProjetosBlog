﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Linq;

namespace Consultas
{
    public partial class frmPesquisaPaciente : Consultas.frmPesquisaBase
    {
        public frmPesquisaPaciente()
        {
            InitializeComponent();
        }

        public override void Pesquisar()
        {
            try
            {
                AcessoDadosPaciente acesso = new AcessoDadosPaciente();
                DataTable dt = acesso.Pesquisar();

                if (rbtCodigo.Checked)
                {
                    var consulta = from c in dt.AsEnumerable()
                                   where (c.Field<int>("IDPACIENTE") == int.Parse(txtPesquisa.Text))
                                   select new
                                   {
                                       _nCodPaciente = c.Field<int>("IDPACIENTE"),
                                       _sNomePaciente = c.Field<string>("NOMEPACIENTE")
                                   };

                    lstPesquisa.Items.Clear();

                    foreach (var registro in consulta)
                    {
                        ListViewItem item = new ListViewItem();
                        item.Text = registro._nCodPaciente.ToString();
                        item.SubItems.Add(registro._sNomePaciente);

                        lstPesquisa.Items.Add(item);
                    }
                }
                else
                {
                    var consulta = from c in dt.AsEnumerable()
                                   where (c.Field<string>("NOMEPACIENTE").Contains(txtPesquisa.Text))
                                   select new
                                   {
                                       _nCodPaciente = c.Field<int>("IDPACIENTE"),
                                       _sNomePaciente = c.Field<string>("NOMEPACIENTE")
                                   };

                    lstPesquisa.Items.Clear();

                    foreach (var registro in consulta)
                    {
                        ListViewItem item = new ListViewItem();
                        item.Text = registro._nCodPaciente.ToString();
                        item.SubItems.Add(registro._sNomePaciente);

                        lstPesquisa.Items.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }
    }
}
