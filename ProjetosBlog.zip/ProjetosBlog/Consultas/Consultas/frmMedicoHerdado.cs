﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Consultas
{
    public partial class frmMedicoHerdado : Consultas.frmBase
    {
        public frmMedicoHerdado()
        {
            InitializeComponent();
        }

        public override bool Salvar()
        {
            try
            {
                AcessoDadosMedico acesso = new AcessoDadosMedico();
                if (sStatus == StatusCadastro.scEditando)
                    acesso.nCodMedico = int.Parse(lblCodigo.Text);

                acesso.sNomeMedico = txtNome.Text;
                acesso.sNumCRM = txtCRM.Text;

                return acesso.Salvar(sStatus == StatusCadastro.scInserindo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override bool Excluir()
        {
            try
            {
                AcessoDadosMedico acesso = new AcessoDadosMedico(_nCodGenerico);
                return acesso.Delete();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override bool Localizar()
        {
            try
            {
                bool bLocaliza = false;
                frmPesquisaMedico frmPesquisa = new frmPesquisaMedico();
                if (frmPesquisa.ShowDialog() == DialogResult.OK)
                {
                    bLocaliza = (frmPesquisa.sCdCodigo != "");
                    if (bLocaliza)
                        _nCodGenerico = int.Parse(frmPesquisa.sCdCodigo);
                }

                return bLocaliza;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override void CarregaValores()
        {
            try
            {
                AcessoDadosMedico acesso = new AcessoDadosMedico(_nCodGenerico);
                DataRow dr = acesso.PesquisaID();

                if (dr != null)
                {
                    lblCodigo.Text = dr["IDMEDICO"].ToString();
                    txtNome.Text = dr["NOMEMEDICO"].ToString();
                    txtCRM.Text = dr["CRM"].ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }
    }
}
