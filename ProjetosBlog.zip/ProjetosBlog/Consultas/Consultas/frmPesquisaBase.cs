﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Consultas
{
    public partial class frmPesquisaBase : Form
    {
        //Declaramos as variáveis públicas do tipo string
        public string sCdCodigo;
        public string sDsNome;

        public frmPesquisaBase()
            {
                InitializeComponent();

                //Inicializamos as variáveis com valor vazio
                sCdCodigo = string.Empty;
                sDsNome = string.Empty;
            }

        #region Métodos

        public void CarregarItens(DataTable dt)
        {
            try
            {
                //limpo os registros do ListView
                lstPesquisa.Items.Clear();

                //carrego os dados no ListView            
                foreach (DataRow dr in dt.Rows)
                {
                    //para cada linha de meu DataTable, insiro uma linha no ListView
                    //instancio o ListViewItem, adiciono um item e um subitem, referentes
                    //ao código e a descrição que estou pesquisando em meu formulário
                    ListViewItem item = new ListViewItem();
                    item.Text = dr[0].ToString();
                    item.SubItems.Add(dr[1].ToString());

                    //aqui adiciono a varíavel instanciada item
                    //carregada com o item e subitem ao ListView
                    lstPesquisa.Items.Add(item);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public virtual void Pesquisar()
        {
            //método que será sobrescrito no formulário herdado
        }

        #endregion
        
        #region Botões

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                //faço a verificação se a variável sCdCodigo está vazia
                if (sCdCodigo == string.Empty)
                {
                    //se estiver vazia e o foco estiver no ListView preencho as variáveis
                    if (lstPesquisa.Focused)
                    {
                        sCdCodigo = lstPesquisa.SelectedItems[0].Text;
                        sDsNome = lstPesquisa.SelectedItems[0].SubItems[1].Text;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            try
            {
                //chamo o método Pesquisar
                Pesquisar();

                //configuro meu StatusStrip para retornar ao usuário informações referentes à pesquisa
                //para que fique entre aspas a qtde e o registro pesquisado apenas adiciono \""
                lblMensagem.Text = "Encontrado(s): \"" + lstPesquisa.Items.Count +
                    "\" registros com a palavra \"" + txtPesquisa.Text + "\"";

                //aqui habilito meu botão OK somente se minha pesquisa retornar ao menos 1 registro
                btnOK.Enabled = lstPesquisa.Items.Count > 0;

                //faço uma verificação se o botão OK estiver habilitado, meu ListView ganha o foco
                if (btnOK.Enabled)
                {
                    lstPesquisa.Focus();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }   
        }

        #endregion
        
        #region Eventos

        private void frmPesquisaBase_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Escape)
                {
                    Close();
                    DialogResult = DialogResult.Cancel;
                }

                if (e.KeyCode == Keys.Enter)
                {
                    Close();
                    DialogResult = DialogResult.Cancel;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void lstPesquisa_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                sCdCodigo = lstPesquisa.SelectedItems[0].Text;
                sDsNome = lstPesquisa.SelectedItems[0].SubItems[1].Text;
                Close();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void lstPesquisa_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Space)
                {
                    sCdCodigo = lstPesquisa.SelectedItems[0].Text;
                    sDsNome = lstPesquisa.SelectedItems[0].SubItems[1].Text;
                    Close();
                    DialogResult = DialogResult.OK;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void lstPesquisa_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                sCdCodigo = lstPesquisa.SelectedItems[0].Text;
                sDsNome = lstPesquisa.SelectedItems[0].SubItems[1].Text;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void rbtCodigo_Click(object sender, EventArgs e)
        {
            try
            {
                //quando o usuário clicar no RadioButton, o foco é
                //automaticamente "setado" para o TextBox de Pesquisa
                txtPesquisa.Focus();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void rbtDescricao_Click(object sender, EventArgs e)
        {
            try
            {
                txtPesquisa.Focus();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        #endregion
    }
}
