﻿namespace Consultas {
    
    
    public partial class dsConsulta {
        partial class ConsultaDataTable
        {
        }
    }
}

namespace Consultas.dsConsultaTableAdapters
{
    
    
    public partial class PacienteTableAdapter {
    }
}
