﻿namespace Consultas
{
    partial class frmConsulta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label iDCONSULTALabel;
            System.Windows.Forms.Label iDMEDICOLabel;
            System.Windows.Forms.Label iDPACIENTELabel;
            System.Windows.Forms.Label dATACONSULTALabel;
            System.Windows.Forms.Label hORAINICIOLabel;
            System.Windows.Forms.Label hORAFIMLabel;
            System.Windows.Forms.Label oBSERVACOESLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmConsulta));
            this.consultorioDataSet = new Consultas.ConsultorioDataSet();
            this.consultaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.consultaTableAdapter = new Consultas.ConsultorioDataSetTableAdapters.ConsultaTableAdapter();
            this.tableAdapterManager = new Consultas.ConsultorioDataSetTableAdapters.TableAdapterManager();
            this.medicoTableAdapter = new Consultas.ConsultorioDataSetTableAdapters.MedicoTableAdapter();
            this.pacienteTableAdapter = new Consultas.ConsultorioDataSetTableAdapters.PacienteTableAdapter();
            this.consultaBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.consultaBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.iDCONSULTALabel1 = new System.Windows.Forms.Label();
            this.iDMEDICOComboBox = new System.Windows.Forms.ComboBox();
            this.medicoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iDPACIENTEComboBox = new System.Windows.Forms.ComboBox();
            this.pacienteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dATACONSULTADateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.hORAINICIODateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.hORAFIMDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.oBSERVACOESTextBox = new System.Windows.Forms.TextBox();
            iDCONSULTALabel = new System.Windows.Forms.Label();
            iDMEDICOLabel = new System.Windows.Forms.Label();
            iDPACIENTELabel = new System.Windows.Forms.Label();
            dATACONSULTALabel = new System.Windows.Forms.Label();
            hORAINICIOLabel = new System.Windows.Forms.Label();
            hORAFIMLabel = new System.Windows.Forms.Label();
            oBSERVACOESLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.consultorioDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.consultaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.consultaBindingNavigator)).BeginInit();
            this.consultaBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.medicoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pacienteBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // iDCONSULTALabel
            // 
            iDCONSULTALabel.AutoSize = true;
            iDCONSULTALabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            iDCONSULTALabel.Location = new System.Drawing.Point(12, 45);
            iDCONSULTALabel.Name = "iDCONSULTALabel";
            iDCONSULTALabel.Size = new System.Drawing.Size(57, 16);
            iDCONSULTALabel.TabIndex = 1;
            iDCONSULTALabel.Text = "Código:";
            // 
            // iDMEDICOLabel
            // 
            iDMEDICOLabel.AutoSize = true;
            iDMEDICOLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            iDMEDICOLabel.Location = new System.Drawing.Point(12, 74);
            iDMEDICOLabel.Name = "iDMEDICOLabel";
            iDMEDICOLabel.Size = new System.Drawing.Size(119, 16);
            iDMEDICOLabel.TabIndex = 3;
            iDMEDICOLabel.Text = "Nome do Médico:";
            // 
            // iDPACIENTELabel
            // 
            iDPACIENTELabel.AutoSize = true;
            iDPACIENTELabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            iDPACIENTELabel.Location = new System.Drawing.Point(12, 101);
            iDPACIENTELabel.Name = "iDPACIENTELabel";
            iDPACIENTELabel.Size = new System.Drawing.Size(129, 16);
            iDPACIENTELabel.TabIndex = 5;
            iDPACIENTELabel.Text = "Nome do Paciente:";
            // 
            // dATACONSULTALabel
            // 
            dATACONSULTALabel.AutoSize = true;
            dATACONSULTALabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dATACONSULTALabel.Location = new System.Drawing.Point(12, 129);
            dATACONSULTALabel.Name = "dATACONSULTALabel";
            dATACONSULTALabel.Size = new System.Drawing.Size(41, 16);
            dATACONSULTALabel.TabIndex = 7;
            dATACONSULTALabel.Text = "Data:";
            // 
            // hORAINICIOLabel
            // 
            hORAINICIOLabel.AutoSize = true;
            hORAINICIOLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            hORAINICIOLabel.Location = new System.Drawing.Point(12, 155);
            hORAINICIOLabel.Name = "hORAINICIOLabel";
            hORAINICIOLabel.Size = new System.Drawing.Size(47, 16);
            hORAINICIOLabel.TabIndex = 9;
            hORAINICIOLabel.Text = "Início:";
            // 
            // hORAFIMLabel
            // 
            hORAFIMLabel.AutoSize = true;
            hORAFIMLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            hORAFIMLabel.Location = new System.Drawing.Point(12, 181);
            hORAFIMLabel.Name = "hORAFIMLabel";
            hORAFIMLabel.Size = new System.Drawing.Size(65, 16);
            hORAFIMLabel.TabIndex = 11;
            hORAFIMLabel.Text = "Término:";
            // 
            // oBSERVACOESLabel
            // 
            oBSERVACOESLabel.AutoSize = true;
            oBSERVACOESLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            oBSERVACOESLabel.Location = new System.Drawing.Point(12, 206);
            oBSERVACOESLabel.Name = "oBSERVACOESLabel";
            oBSERVACOESLabel.Size = new System.Drawing.Size(93, 16);
            oBSERVACOESLabel.TabIndex = 13;
            oBSERVACOESLabel.Text = "Observações:";
            // 
            // consultorioDataSet
            // 
            this.consultorioDataSet.DataSetName = "ConsultorioDataSet";
            this.consultorioDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // consultaBindingSource
            // 
            this.consultaBindingSource.DataMember = "Consulta";
            this.consultaBindingSource.DataSource = this.consultorioDataSet;
            // 
            // consultaTableAdapter
            // 
            this.consultaTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ConsultaTableAdapter = this.consultaTableAdapter;
            this.tableAdapterManager.MedicoTableAdapter = this.medicoTableAdapter;
            this.tableAdapterManager.PacienteTableAdapter = this.pacienteTableAdapter;
            this.tableAdapterManager.UpdateOrder = Consultas.ConsultorioDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // medicoTableAdapter
            // 
            this.medicoTableAdapter.ClearBeforeFill = true;
            // 
            // pacienteTableAdapter
            // 
            this.pacienteTableAdapter.ClearBeforeFill = true;
            // 
            // consultaBindingNavigator
            // 
            this.consultaBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.consultaBindingNavigator.BindingSource = this.consultaBindingSource;
            this.consultaBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.consultaBindingNavigator.CountItemFormat = "de {0}";
            this.consultaBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.consultaBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.consultaBindingNavigatorSaveItem,
            this.toolStripSeparator1,
            this.toolStripButton1});
            this.consultaBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.consultaBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.consultaBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.consultaBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.consultaBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.consultaBindingNavigator.Name = "consultaBindingNavigator";
            this.consultaBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.consultaBindingNavigator.Size = new System.Drawing.Size(483, 25);
            this.consultaBindingNavigator.TabIndex = 0;
            this.consultaBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(38, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // consultaBindingNavigatorSaveItem
            // 
            this.consultaBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.consultaBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("consultaBindingNavigatorSaveItem.Image")));
            this.consultaBindingNavigatorSaveItem.Name = "consultaBindingNavigatorSaveItem";
            this.consultaBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.consultaBindingNavigatorSaveItem.Text = "Save Data";
            this.consultaBindingNavigatorSaveItem.Click += new System.EventHandler(this.consultaBindingNavigatorSaveItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(44, 22);
            this.toolStripButton1.Text = "Fechar";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // iDCONSULTALabel1
            // 
            this.iDCONSULTALabel1.AutoSize = true;
            this.iDCONSULTALabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.consultaBindingSource, "IDCONSULTA", true));
            this.iDCONSULTALabel1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iDCONSULTALabel1.Location = new System.Drawing.Point(147, 45);
            this.iDCONSULTALabel1.Name = "iDCONSULTALabel1";
            this.iDCONSULTALabel1.Size = new System.Drawing.Size(47, 16);
            this.iDCONSULTALabel1.TabIndex = 2;
            this.iDCONSULTALabel1.Text = "label1";
            // 
            // iDMEDICOComboBox
            // 
            this.iDMEDICOComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.consultaBindingSource, "IDMEDICO", true));
            this.iDMEDICOComboBox.DataSource = this.medicoBindingSource;
            this.iDMEDICOComboBox.DisplayMember = "NOMEMEDICO";
            this.iDMEDICOComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.iDMEDICOComboBox.FormattingEnabled = true;
            this.iDMEDICOComboBox.Location = new System.Drawing.Point(147, 71);
            this.iDMEDICOComboBox.Name = "iDMEDICOComboBox";
            this.iDMEDICOComboBox.Size = new System.Drawing.Size(200, 21);
            this.iDMEDICOComboBox.TabIndex = 4;
            this.iDMEDICOComboBox.ValueMember = "IDMEDICO";
            // 
            // medicoBindingSource
            // 
            this.medicoBindingSource.DataMember = "Medico";
            this.medicoBindingSource.DataSource = this.consultorioDataSet;
            // 
            // iDPACIENTEComboBox
            // 
            this.iDPACIENTEComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.consultaBindingSource, "IDPACIENTE", true));
            this.iDPACIENTEComboBox.DataSource = this.pacienteBindingSource;
            this.iDPACIENTEComboBox.DisplayMember = "NOMEPACIENTE";
            this.iDPACIENTEComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.iDPACIENTEComboBox.FormattingEnabled = true;
            this.iDPACIENTEComboBox.Location = new System.Drawing.Point(147, 98);
            this.iDPACIENTEComboBox.Name = "iDPACIENTEComboBox";
            this.iDPACIENTEComboBox.Size = new System.Drawing.Size(200, 21);
            this.iDPACIENTEComboBox.TabIndex = 6;
            this.iDPACIENTEComboBox.ValueMember = "IDPACIENTE";
            // 
            // pacienteBindingSource
            // 
            this.pacienteBindingSource.DataMember = "Paciente";
            this.pacienteBindingSource.DataSource = this.consultorioDataSet;
            // 
            // dATACONSULTADateTimePicker
            // 
            this.dATACONSULTADateTimePicker.CustomFormat = "dd/MMM/yyyy";
            this.dATACONSULTADateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.consultaBindingSource, "DATACONSULTA", true));
            this.dATACONSULTADateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dATACONSULTADateTimePicker.Location = new System.Drawing.Point(147, 125);
            this.dATACONSULTADateTimePicker.Name = "dATACONSULTADateTimePicker";
            this.dATACONSULTADateTimePicker.Size = new System.Drawing.Size(98, 20);
            this.dATACONSULTADateTimePicker.TabIndex = 8;
            // 
            // hORAINICIODateTimePicker
            // 
            this.hORAINICIODateTimePicker.CustomFormat = "HH:mm";
            this.hORAINICIODateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.consultaBindingSource, "HORAINICIO", true));
            this.hORAINICIODateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.hORAINICIODateTimePicker.Location = new System.Drawing.Point(147, 151);
            this.hORAINICIODateTimePicker.Name = "hORAINICIODateTimePicker";
            this.hORAINICIODateTimePicker.Size = new System.Drawing.Size(58, 20);
            this.hORAINICIODateTimePicker.TabIndex = 10;
            // 
            // hORAFIMDateTimePicker
            // 
            this.hORAFIMDateTimePicker.CustomFormat = "HH:mm";
            this.hORAFIMDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.consultaBindingSource, "HORAFIM", true));
            this.hORAFIMDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.hORAFIMDateTimePicker.Location = new System.Drawing.Point(147, 177);
            this.hORAFIMDateTimePicker.Name = "hORAFIMDateTimePicker";
            this.hORAFIMDateTimePicker.Size = new System.Drawing.Size(58, 20);
            this.hORAFIMDateTimePicker.TabIndex = 12;
            // 
            // oBSERVACOESTextBox
            // 
            this.oBSERVACOESTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.consultaBindingSource, "OBSERVACOES", true));
            this.oBSERVACOESTextBox.Location = new System.Drawing.Point(147, 203);
            this.oBSERVACOESTextBox.Multiline = true;
            this.oBSERVACOESTextBox.Name = "oBSERVACOESTextBox";
            this.oBSERVACOESTextBox.Size = new System.Drawing.Size(324, 89);
            this.oBSERVACOESTextBox.TabIndex = 14;
            // 
            // frmConsulta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 304);
            this.Controls.Add(iDCONSULTALabel);
            this.Controls.Add(this.iDCONSULTALabel1);
            this.Controls.Add(iDMEDICOLabel);
            this.Controls.Add(this.iDMEDICOComboBox);
            this.Controls.Add(iDPACIENTELabel);
            this.Controls.Add(this.iDPACIENTEComboBox);
            this.Controls.Add(dATACONSULTALabel);
            this.Controls.Add(this.dATACONSULTADateTimePicker);
            this.Controls.Add(hORAINICIOLabel);
            this.Controls.Add(this.hORAINICIODateTimePicker);
            this.Controls.Add(hORAFIMLabel);
            this.Controls.Add(this.hORAFIMDateTimePicker);
            this.Controls.Add(oBSERVACOESLabel);
            this.Controls.Add(this.oBSERVACOESTextBox);
            this.Controls.Add(this.consultaBindingNavigator);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmConsulta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro de Consultas";
            this.Load += new System.EventHandler(this.frmConsulta_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmConsulta_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.consultorioDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.consultaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.consultaBindingNavigator)).EndInit();
            this.consultaBindingNavigator.ResumeLayout(false);
            this.consultaBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.medicoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pacienteBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ConsultorioDataSet consultorioDataSet;
        private System.Windows.Forms.BindingSource consultaBindingSource;
        private Consultas.ConsultorioDataSetTableAdapters.ConsultaTableAdapter consultaTableAdapter;
        private Consultas.ConsultorioDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator consultaBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton consultaBindingNavigatorSaveItem;
        private System.Windows.Forms.Label iDCONSULTALabel1;
        private System.Windows.Forms.ComboBox iDMEDICOComboBox;
        private System.Windows.Forms.ComboBox iDPACIENTEComboBox;
        private System.Windows.Forms.DateTimePicker dATACONSULTADateTimePicker;
        private System.Windows.Forms.DateTimePicker hORAINICIODateTimePicker;
        private System.Windows.Forms.DateTimePicker hORAFIMDateTimePicker;
        private System.Windows.Forms.TextBox oBSERVACOESTextBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private Consultas.ConsultorioDataSetTableAdapters.MedicoTableAdapter medicoTableAdapter;
        private System.Windows.Forms.BindingSource medicoBindingSource;
        private Consultas.ConsultorioDataSetTableAdapters.PacienteTableAdapter pacienteTableAdapter;
        private System.Windows.Forms.BindingSource pacienteBindingSource;
    }
}