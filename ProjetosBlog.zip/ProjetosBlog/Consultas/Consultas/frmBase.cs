﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Consultas
{
    public partial class frmBase : Form
    {
        public enum StatusCadastro
        {
            scInserindo,
            scNavegando,
            scEditando
        }

        public StatusCadastro sStatus;

        public int _nCodGenerico;

        public frmBase()
        {
            InitializeComponent();
        }

        private void frmBase_Load(object sender, EventArgs e)
        {
            sStatus = StatusCadastro.scNavegando;
            LimpaControles();
            HabilitaDesabilitaControles(false);
        }

        #region Métodos

        public virtual void CarregaValores()
        {

        }

        public virtual bool Excluir()
        {
            return false;
        }

        private void HabilitaDesabilitaControles(bool bValue)
        {
            try
            {
                //percorre os controles da tela e os habilita ou desabilita
                foreach (Control ctr in this.Controls)
                {
                    if (ctr is ToolStrip)
                        continue;

                    ctr.Enabled = bValue;
                }

                //habilitar os botões

                //Novo - será habilitado somente quando for navegação
                btnNovo.Enabled = (sStatus == StatusCadastro.scNavegando);

                //Salvar
                btnSalvar.Enabled = (sStatus == StatusCadastro.scEditando ||
                                     sStatus == StatusCadastro.scInserindo);

                //Excluir
                btnExcluir.Enabled = (sStatus == StatusCadastro.scEditando);

                //Localizar
                btnLocalizar.Enabled = (sStatus == StatusCadastro.scNavegando ||
                                        sStatus == StatusCadastro.scEditando ||
                                        sStatus == StatusCadastro.scInserindo);

                //Fechar
                btnFechar.Enabled = true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void LimpaControles()
        {
            try
            {
                foreach (Control ctr in this.Controls)
                {
                    if (ctr is TextBox)
                        (ctr as TextBox).Text = "";

                    if (ctr is ComboBox)
                        (ctr as ComboBox).SelectedIndex = -1;

                    if (ctr is ListBox)
                        (ctr as ListBox).SelectedIndex = -1;

                    if (ctr is RadioButton)
                        (ctr as RadioButton).Checked = false;

                    if (ctr is CheckBox)
                        (ctr as CheckBox).Checked = false;

                    if (ctr is CheckedListBox)
                    {
                        foreach (ListControl item in (ctr as CheckedListBox).Items)
                            item.SelectedIndex = -1;
                    }

                    if (ctr is Label)
                    {
                        if ((ctr as Label).Name == "lblCodigo")
                        {
                            (ctr as Label).Text = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public virtual bool Localizar()
        {
            return false;
        }

        public virtual bool Salvar()
        {
            return false;
        }

        #endregion


        #region Botões

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Deseja excluir o registro?", "Excluir",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    if (Excluir())
                    {
                        sStatus = StatusCadastro.scNavegando;
                        LimpaControles();
                        HabilitaDesabilitaControles(false);
                        MessageBox.Show("Registro excluído com sucesso", "Aviso do Sistema",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("O registro não foi excluído, por favor verifique os erros!", "Erro",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                if (Localizar())
                {
                    sStatus = StatusCadastro.scEditando;
                    HabilitaDesabilitaControles(true);
                    CarregaValores();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            try
            {
                sStatus = StatusCadastro.scInserindo;
                LimpaControles();
                HabilitaDesabilitaControles(true);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (Salvar())
                {
                    sStatus = StatusCadastro.scNavegando;
                    LimpaControles();
                    HabilitaDesabilitaControles(false);
                    MessageBox.Show("Registro salvo com sucesso", "Aviso do Sistema",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("O registro não foi salvo, por favor verifique os erros!", "Erro",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        #endregion


        #region Eventos

        private void frmBase_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                Close();
            }
        }

        #endregion
    }
}
