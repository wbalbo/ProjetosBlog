﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExemploViewState
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private void Ler()
        {
            try
            {
                this.lblNome.Text = "Valor armazenado: " + ViewState["Nome"].ToString();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void Salvar()
        {
            try
            {
                ViewState["Nome"] = this.txtNome.Text;
                this.txtNome.Text = string.Empty;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            Salvar();
        }

        protected void btnLer_Click(object sender, EventArgs e)
        {
            Ler();
        }
    }
}
