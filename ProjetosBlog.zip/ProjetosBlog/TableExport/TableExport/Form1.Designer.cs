﻿namespace TableExport
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTabela = new System.Windows.Forms.TextBox();
            this.txtDatabase = new System.Windows.Forms.TextBox();
            this.txtArquivo = new System.Windows.Forms.TextBox();
            this.txtServidor = new System.Windows.Forms.TextBox();
            this.lblArquivo = new System.Windows.Forms.Label();
            this.lblTabela = new System.Windows.Forms.Label();
            this.lblDatabase = new System.Windows.Forms.Label();
            this.lblServidor = new System.Windows.Forms.Label();
            this.btnAbrirXLS = new System.Windows.Forms.Button();
            this.btnGerarXLS = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtTabela
            // 
            this.txtTabela.Location = new System.Drawing.Point(130, 113);
            this.txtTabela.Name = "txtTabela";
            this.txtTabela.Size = new System.Drawing.Size(121, 20);
            this.txtTabela.TabIndex = 3;
            // 
            // txtDatabase
            // 
            this.txtDatabase.Location = new System.Drawing.Point(130, 71);
            this.txtDatabase.Name = "txtDatabase";
            this.txtDatabase.Size = new System.Drawing.Size(121, 20);
            this.txtDatabase.TabIndex = 2;
            // 
            // txtArquivo
            // 
            this.txtArquivo.Location = new System.Drawing.Point(130, 150);
            this.txtArquivo.Name = "txtArquivo";
            this.txtArquivo.Size = new System.Drawing.Size(121, 20);
            this.txtArquivo.TabIndex = 4;
            // 
            // txtServidor
            // 
            this.txtServidor.Location = new System.Drawing.Point(130, 33);
            this.txtServidor.Name = "txtServidor";
            this.txtServidor.Size = new System.Drawing.Size(121, 20);
            this.txtServidor.TabIndex = 1;
            // 
            // lblArquivo
            // 
            this.lblArquivo.AutoSize = true;
            this.lblArquivo.Location = new System.Drawing.Point(34, 157);
            this.lblArquivo.Name = "lblArquivo";
            this.lblArquivo.Size = new System.Drawing.Size(83, 13);
            this.lblArquivo.TabIndex = 19;
            this.lblArquivo.Text = "Arquivo EXCEL:";
            // 
            // lblTabela
            // 
            this.lblTabela.AutoSize = true;
            this.lblTabela.Location = new System.Drawing.Point(34, 120);
            this.lblTabela.Name = "lblTabela";
            this.lblTabela.Size = new System.Drawing.Size(43, 13);
            this.lblTabela.TabIndex = 18;
            this.lblTabela.Text = "Tabela:";
            // 
            // lblDatabase
            // 
            this.lblDatabase.AutoSize = true;
            this.lblDatabase.Location = new System.Drawing.Point(34, 78);
            this.lblDatabase.Name = "lblDatabase";
            this.lblDatabase.Size = new System.Drawing.Size(90, 13);
            this.lblDatabase.TabIndex = 17;
            this.lblDatabase.Text = "Banco de Dados:";
            // 
            // lblServidor
            // 
            this.lblServidor.AutoSize = true;
            this.lblServidor.Location = new System.Drawing.Point(34, 40);
            this.lblServidor.Name = "lblServidor";
            this.lblServidor.Size = new System.Drawing.Size(49, 13);
            this.lblServidor.TabIndex = 16;
            this.lblServidor.Text = "Servidor:";
            // 
            // btnAbrirXLS
            // 
            this.btnAbrirXLS.Location = new System.Drawing.Point(159, 206);
            this.btnAbrirXLS.Name = "btnAbrirXLS";
            this.btnAbrirXLS.Size = new System.Drawing.Size(75, 23);
            this.btnAbrirXLS.TabIndex = 6;
            this.btnAbrirXLS.Text = "Abrir XLS";
            this.btnAbrirXLS.UseVisualStyleBackColor = true;
            this.btnAbrirXLS.Click += new System.EventHandler(this.btnAbrirXLS_Click);
            // 
            // btnGerarXLS
            // 
            this.btnGerarXLS.Location = new System.Drawing.Point(50, 206);
            this.btnGerarXLS.Name = "btnGerarXLS";
            this.btnGerarXLS.Size = new System.Drawing.Size(75, 23);
            this.btnGerarXLS.TabIndex = 5;
            this.btnGerarXLS.Text = "Gerar XLS";
            this.btnGerarXLS.UseVisualStyleBackColor = true;
            this.btnGerarXLS.Click += new System.EventHandler(this.btnGerarXLS_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.txtTabela);
            this.Controls.Add(this.txtDatabase);
            this.Controls.Add(this.txtArquivo);
            this.Controls.Add(this.txtServidor);
            this.Controls.Add(this.lblArquivo);
            this.Controls.Add(this.lblTabela);
            this.Controls.Add(this.lblDatabase);
            this.Controls.Add(this.lblServidor);
            this.Controls.Add(this.btnAbrirXLS);
            this.Controls.Add(this.btnGerarXLS);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gerador de XLS";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTabela;
        private System.Windows.Forms.TextBox txtDatabase;
        private System.Windows.Forms.TextBox txtArquivo;
        private System.Windows.Forms.TextBox txtServidor;
        private System.Windows.Forms.Label lblArquivo;
        private System.Windows.Forms.Label lblTabela;
        private System.Windows.Forms.Label lblDatabase;
        private System.Windows.Forms.Label lblServidor;
        private System.Windows.Forms.Button btnAbrirXLS;
        private System.Windows.Forms.Button btnGerarXLS;
    }
}

