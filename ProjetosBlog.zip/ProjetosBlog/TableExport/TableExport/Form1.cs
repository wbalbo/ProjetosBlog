﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace TableExport
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void AbrirXLS()
        {
            try
            {
                System.Diagnostics.Process process = new System.Diagnostics.Process();
                process.EnableRaisingEvents = true;
                process.StartInfo.FileName = txtArquivo.Text;
                process.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu o seguinte erro: " + ex.Message);
            }
        }

        private void GerarXLS()
        {
            using (StreamWriter sw = File.CreateText(txtArquivo.Text))
            {
                string conexao = String.Format("Server={0};Database={1};Trusted_Connection=True", txtServidor.Text, txtDatabase.Text);
                
                using (SqlConnection objConexao = new SqlConnection(conexao))
                {
                    string sqlCommand = "SELECT * FROM " + txtTabela.Text;

                    SqlCommand objCommand = new SqlCommand(sqlCommand, objConexao);

                    try
                    {
                        objConexao.Open();

                        SqlDataReader dr = objCommand.ExecuteReader();

                        while (dr.Read())
                        {
                            sw.WriteLine(dr["ProductName"].ToString() + "\t" + dr["UnitPrice"].ToString());
                        }

                        MessageBox.Show("Arquivo " + txtArquivo.Text + " Gerado com Sucesso!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ocorreu o seguinte erro: " + ex.Message);
                    }
                    finally
                    {
                        objConexao.Close();
                    }
                }
            }
        }

        private void btnAbrirXLS_Click(object sender, EventArgs e)
        {
            AbrirXLS();
        }
        
        private void btnGerarXLS_Click(object sender, EventArgs e)
        {
            GerarXLS();
        }
    }
}
