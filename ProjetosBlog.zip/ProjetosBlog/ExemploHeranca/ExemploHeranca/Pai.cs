﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploHeranca
{
    public class Pai
    {
        public string Nome = "Arnaldo";
        public int Idade = 35;        
    }
}
