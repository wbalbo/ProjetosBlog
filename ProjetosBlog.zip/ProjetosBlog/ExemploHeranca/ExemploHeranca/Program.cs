﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploHeranca
{
    class Program
    {
        static void Main(string[] args)
        {
            //Exemplo 1:
            Cachorro objCachorro = new Cachorro();
            objCachorro.Idade = 4;

            //Exemplo 2:
            Filha objFilha = new Filha();
            objFilha.MostrarValores();

            Console.ReadKey();
        }
    }
}
