﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploHeranca
{
    public class Filha : Pai
    {
        public new string Nome = "Jaqueline";
        public new int Idade = 10;

        public void MostrarValores()
        {
            Console.WriteLine("Nome Filha: " + Nome);
            Console.WriteLine("Nome Pai: " + base.Nome);
            Console.WriteLine("Idade Filha: " + Idade);
            Console.WriteLine("Idade Pai: " + base.Idade);
        }
    }
}
