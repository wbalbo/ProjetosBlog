﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace ExemploCrystalReport
{
    public partial class Form2 : Form
    {
        private string strParametro = string.Empty;

        public Form2(string parametro)
        {
            this.strParametro = parametro;
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            CarregarRelatorio();
        }

        private void CarregarRelatorio()
        {
            try
            {
                string strConexao = ConfigurationManager.ConnectionStrings["NorthwindConnectionString"].ConnectionString;
                string strCommand = "SELECT * FROM Products";

                SqlConnection objConexao = new SqlConnection(strConexao);
                SqlCommand objCommand = new SqlCommand(strCommand, objConexao);
                SqlDataAdapter objAdapter = new SqlDataAdapter();
                DataSet objDataSet = new DataSet();
                Produtos objReport = new Produtos();
                
                objCommand.Connection = objConexao;
                objAdapter.SelectCommand = objCommand;
                objAdapter.Fill(objDataSet, "Products");
                objReport.SetDataSource(objDataSet);
                objReport.SetParameterValue("Param1", strParametro);

                crystalReportViewer1.ReportSource = objReport;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
        }
    }
}
