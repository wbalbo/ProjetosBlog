﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlesASPNETWebParts
{
    public partial class Exemplos : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            WebPartManager1.DisplayMode = WebPartManager1.DisplayModes["Edit"];
        }

        protected void btnCatalogo_Click(object sender, EventArgs e)
        {
            WebPartManager1.DisplayMode = WebPartManager1.DisplayModes["Catalog"];
        }
    }
}
