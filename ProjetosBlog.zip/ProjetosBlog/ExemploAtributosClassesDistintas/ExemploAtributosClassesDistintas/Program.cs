﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploAtributosClassesDistintas
{
    class Program
    {
        static void Main(string[] args)
        {
            Produto objProduto = new Produto();

            objProduto.Codigo = 1;
            objProduto.Nome = "Playstation 3";
            objProduto.Valor = 999.00;

            objProduto.ListaImposto.Add(new Imposto("IPI", 5.0));
            objProduto.ListaImposto.Add(new Imposto("IOF", 10.0));
            objProduto.ListaImposto.Add(new Imposto("Frete", 5.0));

            Console.Write(objProduto.CalcularValorBruto());
            Console.Read();
        }
    }
}
