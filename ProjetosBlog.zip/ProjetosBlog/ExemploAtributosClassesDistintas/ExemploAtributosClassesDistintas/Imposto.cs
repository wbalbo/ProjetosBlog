﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploAtributosClassesDistintas
{
    public class Imposto
    {
        public Imposto()
        {
            // Construtor Padrão
        }

        public Imposto(string strNome, double dblAliquota)
        {
            this.Nome = strNome;
            this.Aliquota = dblAliquota;
        }

        // Propriedades
        public string Nome { get; set; }
        public double Aliquota { get; set; }
    }
}
