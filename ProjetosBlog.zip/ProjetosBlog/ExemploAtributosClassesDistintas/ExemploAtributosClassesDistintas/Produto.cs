﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploAtributosClassesDistintas
{
    public class Produto
    {
        public Produto()
        {
            ListaImposto = new List<Imposto>();
        }

        // Propriedades
        public int Codigo { get; set; }
        public string Nome { get; set; }
        public double Valor { get; set; }
        public List<Imposto> ListaImposto { get; set; }

        // Método
        public double CalcularValorBruto()
        {
            double dblPercentualTotalImpostos = 0;

            foreach (Imposto itemImposto in ListaImposto)
            {
                dblPercentualTotalImpostos += itemImposto.Aliquota;
            }

            return this.Valor + (this.Valor * (dblPercentualTotalImpostos / 100));
        }
    }
}
