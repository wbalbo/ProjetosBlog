﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExemploBreakpoint
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        private void Salvar()
        {
            try
            {
                if (txtNome.Text != string.Empty)
                {
                    this.lblNome.Text = this.txtNome.Text;
                }
                else
                {
                    this.lblNome.Text = "Você não digitou nenhum texto!";
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            Salvar();
        }
    }
}
