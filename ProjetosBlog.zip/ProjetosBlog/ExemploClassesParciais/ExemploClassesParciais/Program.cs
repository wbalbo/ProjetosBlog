﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploClassesParciais
{
    class Program
    {
        static void Main(string[] args)
        {
            //DadosPessoa.DadosPessoais objDadosPessoa = new DadosPessoa.DadosPessoais();

            //objDadosPessoa.Nome = Console.ReadLine();
            //Console.WriteLine("\nSeu nome eh: \n" + objDadosPessoa.Nome);

            //Console.WriteLine(Environment.NewLine);

            //objDadosPessoa.Idade = int.Parse(Console.ReadLine());
            //Console.WriteLine("\nSua idade eh: \n" + objDadosPessoa.Idade);

            //Console.WriteLine(Environment.NewLine);

            //objDadosPessoa.VerificarIdade(objDadosPessoa.Idade);

            //Console.ReadKey();

            int x = 5, y = 10;

            string verdade = "sim", falso = "não";

            Console.WriteLine(x * y > y - x ? verdade : falso);

            Console.ReadKey();
        }
    }
}
