﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploClassesParciais
{
    public class DadosPessoa
    {
        public partial class DadosPessoais
        {
            public string Nome = string.Empty;
            public int Idade = int.MinValue;
        }

        public partial class DadosPessoais
        {
            public void VerificarIdade(int Idade)
            {
                if (Idade >= 18)
                {
                    Console.WriteLine("Você é maior de idade!");
                }
                else
                {
                    Console.WriteLine("Você é menor de idade!");
                }
            }
        }
    }
}
