﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VendasLoja
{
    public partial class frmCadastroClientes : Form
    {
        public frmCadastroClientes()
        {
            InitializeComponent();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (GravarClientes())
            {
                //Instancio a classe EventHandler, passando como parâmetro meu método que irá abrir o form de Cadastro de Vendas
                System.EventHandler objDelegate = new EventHandler(this.AtivaFormVendas);

                //Ativo meu delegate pelo método Invoke
                objDelegate.Invoke(sender, e);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void AtivaFormVendas(object sender, EventArgs e)
        {
            frmCadastroVendas objInstanciado = new frmCadastroVendas();
            objInstanciado.ShowDialog();
        }

        private bool GravarClientes()
        {
            bool bVerifica = false;

            try
            {
                Dados objDados = new Dados();

                objDados.GravarClientes(int.Parse(txtCodigo.Text), txtNome.Text, txtTelefone.Text, txtEmail.Text);

                MessageBox.Show("Registro gravado com sucesso!");

                bVerifica = true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return bVerifica;
        }        

        private void LimparCampos()
        {
            txtCodigo.Text = string.Empty;
            txtNome.Text = string.Empty;
            txtTelefone.Text = string.Empty;
            txtEmail.Text = string.Empty;
        }
    }
}
