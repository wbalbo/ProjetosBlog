﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VendasLoja
{
    public partial class frmCadastroVendas : Form
    {
        public frmCadastroVendas()
        {
            InitializeComponent();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            GravarVendas();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void GravarVendas()
        {
            try
            {
                Dados objDados = new Dados();

                objDados.GravarVendas(int.Parse(txtCodigo.Text), txtDescricao.Text, decimal.Parse(txtValorTotal.Text));

                MessageBox.Show("Registro gravado com sucesso!");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        
        private void LimparCampos()
        {
            txtCodigo.Text = string.Empty;
            txtDescricao.Text = string.Empty;
            txtValorTotal.Text = string.Empty;
        }
    }
}
