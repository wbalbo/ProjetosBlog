﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace VendasLoja
{
    public class Dados
    {
        //String de conexão com o banco
        public string strConexao = @"Data Source=WELLINGTON-PC\SQLEXPRESS;Initial Catalog=Vendas;Integrated Security=True;Pooling=False";

        #region Campos
        
        public int Codigo;
        public string Nome;
        public string Telefone;
        public string Email;
        public string Descricao;
        public decimal ValorTotal;

        #endregion

        #region Métodos

        public void GravarClientes(int codigo, string nome, string telefone, string email)
        {
            this.Codigo = codigo;
            this.Nome = nome;
            this.Telefone = telefone;
            this.Email = email;

            SqlConnection objConexao = new SqlConnection(strConexao);

            string strInstrucao = "INSERT INTO Clientes VALUES (@Codigo, @Nome, @Telefone, @Email)";
            SqlCommand objCommand = new SqlCommand(strInstrucao);

            objCommand.Connection = objConexao;

            objCommand.Parameters.AddWithValue("@Codigo", codigo);
            objCommand.Parameters.AddWithValue("@Nome", nome);
            objCommand.Parameters.AddWithValue("@Telefone", telefone);
            objCommand.Parameters.AddWithValue("@Email", email);

            objConexao.Open();

            objCommand.ExecuteNonQuery();

            objConexao.Close();
        }        

        public void GravarVendas(int codigo, string descricao, decimal valorTotal)
        {
            SqlConnection objConexao = new SqlConnection(strConexao);

            string strInstrucao = "INSERT INTO Vendas VALUES (@Codigo, @Descricao, @ValorTotal)";
            SqlCommand objCommand = new SqlCommand(strInstrucao);

            objCommand.Connection = objConexao;

            objCommand.Parameters.AddWithValue("@Codigo", codigo);
            objCommand.Parameters.AddWithValue("@Descricao", descricao);
            objCommand.Parameters.AddWithValue("@ValorTotal", valorTotal);

            objConexao.Open();

            objCommand.ExecuteNonQuery();

            objConexao.Close();
        }

        #endregion
    }
}
