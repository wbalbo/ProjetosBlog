﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Classes
{
    public class Elementos
    {
        /// <summary>
        /// Campos
        /// </summary>
        public class Cliente
        {
            public string Nome;
            
            public string Email;

            public string Telefone;

            private int Codigo;
        }

        /// <summary>
        /// Métodos
        /// </summary>
        public class Loja
        {
            public void EfetuarVenda()
            {
                //Código para enviar o email
            }

            public void CalcularTroco(decimal valor)
            {
                //Código para calcular o troco, que recebe como parâmetro o valor da compra, do tipo decimal
            }

            public DateTime DataDaVenda()
            {
                DateTime objData = DateTime.MinValue;

                return objData.Date;
            }

            public decimal CalcularImposto(decimal preco)
            {
                return preco * (1 * 10);
            }
        }

        /// <summary>
        /// Propriedades
        /// </summary>
        public class Produto
        {
            private decimal _preco;

            public decimal Preco
            {
                get { return _preco; }
                set { _preco = value; }
            }

            //Com code snippet
            public int MyProperty { get; set; }
        }

        /// <summary>
        /// Eventos
        /// </summary>
        public class Estoque
        {
            public event System.EventHandler EstoqueBaixo;
            public int totalEstoque;

            public void Retirada(int quantidade)
            {
                totalEstoque -= quantidade;

                if (totalEstoque < 5)
                {
                    if (EstoqueBaixo != null)
                    {
                        EstoqueBaixo(this, new EventArgs());
                    }
                }
            }
        }

        public void DadosCliente()
        {
            Cliente objCliente = new Cliente();
            objCliente.Nome = "Wellington";
            objCliente.Telefone = "3222-2223";
            objCliente.Email = "wellington@balbo.com";
        }
    }
}
