﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploClassesAbstratas
{
    public class Designer : Funcionario
    {
        public override void Reajustar()
        {
            Salario += 500;
        }
    }
}
