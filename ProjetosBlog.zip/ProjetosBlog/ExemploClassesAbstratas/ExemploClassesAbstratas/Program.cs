﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploClassesAbstratas
{
    class Program
    {
        static void Main(string[] args)
        {
            Programador objProgramador = new Programador();
            Designer objDesigner = new Designer();

            objProgramador.Salario = 1300M;
            Console.WriteLine("Calculando Reajuste Programador\n");
            objProgramador.Reajustar();
            Console.WriteLine("Novo salário: " + objProgramador.Salario);

            objDesigner.Salario = 1100M;
            Console.WriteLine("\nCalculando Reajuste Designer\n");
            objDesigner.Reajustar();
            Console.WriteLine("Novo salário: " + objDesigner.Salario);

            Console.ReadKey();
        }
    }
}
