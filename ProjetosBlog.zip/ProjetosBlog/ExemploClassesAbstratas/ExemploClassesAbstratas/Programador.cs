﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploClassesAbstratas
{
    public class Programador : Funcionario
    {
        public override void Reajustar()
        {
            Salario += 1000;
        }
    }
}
