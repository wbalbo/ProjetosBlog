﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploClassesAbstratas
{
    public class Pessoa
    {
        public decimal CalcularVendas()
        {
            decimal valorUnitario = 150;
            decimal produtosVendidos = 3800;
            decimal taxaAdicional = 100;

            return taxaAdicional + (valorUnitario * produtosVendidos);
        }

    }
}
