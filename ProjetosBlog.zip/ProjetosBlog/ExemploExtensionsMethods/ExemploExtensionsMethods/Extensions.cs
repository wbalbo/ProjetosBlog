﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Extensions
{
    public static class StringExtensions
    {
        public enum DateFormat
        { 
            USFormat,
            BrazilianFormat
        }

        public static string FormatDateString(this string strData, DateFormat dateFormato)
        {
            string strRetorno = "Data Inválida!";

            try
            {
                DateTime date = DateTime.Parse(strData);

                if (dateFormato == DateFormat.BrazilianFormat)
                    strRetorno = date.Date.ToString("dd/MM/yyyy");
                else
                    strRetorno = date.Date.ToString("MM/dd/yyyy");
            }
            catch
            {
                return strRetorno;
            }

            return strRetorno;
        }
    }
}
