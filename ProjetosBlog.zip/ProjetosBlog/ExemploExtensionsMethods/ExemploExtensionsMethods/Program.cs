﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Extensions;

namespace Extensions
{
    class Program
    {
        static void Main(string[] args)
        {
            string strData = "16/05/1989";

            Console.Write(strData.FormatDateString(StringExtensions.DateFormat.USFormat));
            Console.ReadKey();
        }
    }
}
