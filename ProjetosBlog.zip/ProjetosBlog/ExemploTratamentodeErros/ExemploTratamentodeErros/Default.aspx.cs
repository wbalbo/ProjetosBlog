﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace ExemploTratamentodeErros
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public void TratamentodeErros()
        {
            //try simples, sem uso da classe Exception
            try
            {
                //linha de código que pode disparar uma exceção
                int numero = Convert.ToInt32(txtValor.Text);
                int resultado = 100 / numero;
            }
            catch
            {
                //linha de código que trata o erro
                lblMensagem.Text = "Número inválido!";
            }

            //try com Exception
            try
            {
                int numero = Convert.ToInt32(txtValor.Text);
                int resultado = 100 / numero;
            }
            catch (Exception ex)
            {
                lblMensagem.Text = ex.Message;
            }

            //exemplo de try com vários catch's, sempre do mais específico para o mais genérico
            try
            {
                int numero = Convert.ToInt32(txtValor.Text);
                int resultado = 100 / numero;
            }
            catch (FormatException)
            {
                lblMensagem.Text = "Formato de número inválido!";
            }
            catch (DivideByZeroException)
            {
                lblMensagem.Text = "O número não pode ser zero!";
            }
            catch (Exception ex)
            {
                lblMensagem.Text = ex.Message;
            }

            //exemplo de uso da palavra reservada throw
            try
            {
                int numero = Convert.ToInt32(txtValor.Text);

                if ((numero % 2) > 0)
                {
                    throw new Exception("O número ímpar é inválido!");    
                }
            }
            catch (Exception ex)
            {
                lblMensagem.Text = ex.Message;
            }

            //exemplo com o uso do bloco finally
            StreamWriter objQualquer = new StreamWriter("teste.txt");
            try
            {
                objQualquer.WriteLine("Digitando algo...");
            }
            catch
            {
                lblMensagem.Text = "Erro ao digitar...";
            }
            finally
            {
                objQualquer.Close();
            }
        }
    }
}
