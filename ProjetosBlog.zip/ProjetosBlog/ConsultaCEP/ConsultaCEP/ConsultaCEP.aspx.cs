﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Web.UI;
using System.Xml;

namespace Programando.NET
{
    public partial class ConsultaCEP : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
                LockCleanControl(false, false, false);
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            try
            {
                Dictionary<string, string> lResult = Search(txtZipCode.Text);
                if (lResult.Count > 1)
                    LoadInformation(lResult);
                else
                {
                    TextBox1.Text = "CEP NÃO ENCONTRADO!";
                    LockCleanControl(false, true, true);
                }
            }
            catch (Exception error)
            {
                throw new Exception(error.Message);
            }
        }

        /// <summary>
        /// Search by CEP.
        /// </summary>
        /// <param name="pZipCode">Zip code</param>
        /// <returns>Dictionary</returns>
        private Dictionary<string, string> Search(string pZipCode)
        {
            //Framework 4.5
            Dictionary<string, string> Address = new Dictionary<string, string>();

            var lReturn = string.Empty;

            string lUrl = String.Format(@"http://cep.republicavirtual.com.br/web_cep.php?cep={0}", pZipCode);

            WebClient lWebClient = new WebClient();
            lWebClient.Credentials = new NetworkCredential();

            string lResponseXML = lWebClient.DownloadString(lUrl);

            XmlDocument lContextXML = new XmlDocument();

            lContextXML.LoadXml(lResponseXML);

            var lElementos = lContextXML.GetElementsByTagName("webservicecep");

            var lResultado = lElementos[0]["resultado"];

            if (lResultado.InnerText == "1")
            {
                var lUF = lElementos[0]["uf"];
                var lCidade = lElementos[0]["cidade"];
                var lBairro = lElementos[0]["bairro"];
                var lTipoLogradouro = lElementos[0]["tipo_logradouro"];
                var lLogradouro = lElementos[0]["logradouro"];

                Address.Add("UF:", lUF.InnerText);
                Address.Add("Cidade:", lCidade.InnerText);
                Address.Add("Bairro:", lBairro.InnerText);
                Address.Add("Tipo Logradouro:", lTipoLogradouro.InnerText);
                Address.Add("Logradouro:", lLogradouro.InnerText);
            }
            return Address;
        }

        /// <summary>
        /// Load informations zip code.
        /// </summary>
        /// <param name="pAdressInformation">Information zip code.</param>
        private void LoadInformation(Dictionary<string, string> pAdressInformation)
        {
            foreach (var item in pAdressInformation.Values)
            {
                TextBox1.Text += item + "\n";
            }
            LockCleanControl(true, true, true);
        }

        private void LockCleanControl(bool pLock, bool pVisible, bool pCleanZipCode)
        {
            TextBox1.Enabled = pLock;
            TextBox1.Visible = pVisible;

            if (pCleanZipCode)
                txtZipCode.Text = string.Empty;
        }

        protected void btnClean_Click(object sender, EventArgs e)
        {
            CleanAdress();
        }

        private void CleanAdress()
        {
            TextBox1.Text = string.Empty;
        }
    }
}