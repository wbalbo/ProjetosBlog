﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class frmAlterarFuncionarios : Form
    {
        public frmAlterarFuncionarios()
        {
            InitializeComponent();
        }

        #region Variáveis Públicas

        public int codigo;
        public string nome, endereco, cidade, estado, telefone, cargo, dataAdmissao, dataDemissao;         

        #endregion

        #region Botões / Eventos

        private void frmAlterarFuncionarios_Load(object sender, EventArgs e)
        {
            CarregarDados();
        }

        private void tsbtnCancelar_Click(object sender, EventArgs e)
        {
            CancelarAlteracoes();
        }

        private void tsbtnGravar_Click(object sender, EventArgs e)
        {
            AlterarDados();
        }               

        #endregion

        #region Métodos

        private void AlterarDados()
        {
            bool camposValidados = false;

            try
            {
                SqlConnection objConexao = new SqlConnection(@"Data Source=WELLINGTON-PC\SQLEXPRESS;
                                            Initial Catalog=LibrarySystem;Integrated Security=True");

                string strConn = @"UPDATE Funcionarios SET Nome_Funcionario = @Nome, Endereco_Funcionario = @Endereco, " +
                "Cidade_Funcionario = @Cidade, Estado_Funcionario = @Estado, Telefone_Funcionario = @Telefone, " +
                "Cargo_Funcionario = @Cargo, Data_Admissao_Funcionario = @Data_Admissao, Data_Demissao_Funcionario = @Data_Demissao " +
                "WHERE Id_Funcionario = " + codigo;

                SqlCommand objCommand = new SqlCommand(strConn, objConexao);

                #region Validações dos Campos

                if (!String.IsNullOrEmpty(txtNome.Text))
                {
                    objCommand.Parameters.AddWithValue("@Nome", txtNome.Text);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(txtNome, "O campo Nome é obrigatório!");

                    camposValidados = false;
                }

                if (!String.IsNullOrEmpty(txtEndereco.Text))
                {
                    objCommand.Parameters.AddWithValue("@Endereco", txtEndereco.Text);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(txtEndereco, "O campo Endereço é obrigatório!");

                    camposValidados = false;
                }

                if (!String.IsNullOrEmpty(txtCidade.Text))
                {
                    objCommand.Parameters.AddWithValue("@Cidade", txtCidade.Text);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(txtCidade, "O campo Cidade é obrigatório!");

                    camposValidados = false;
                }

                if (!String.IsNullOrEmpty(mtbTelefone.Text))
                {
                    objCommand.Parameters.AddWithValue("@Telefone", mtbTelefone.Text);

                    camposValidados = true;
                }

                if (ddlEstado.SelectedIndex > -1)
                {
                    objCommand.Parameters.AddWithValue("@Estado", ddlEstado.SelectedItem);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(ddlEstado, "O campo Estado é obrigatório!");

                    camposValidados = false;
                }

                if (!String.IsNullOrEmpty(mtbDataAdmissao.Text))
                {
                    objCommand.Parameters.AddWithValue("@Data_Admissao", mtbDataAdmissao.Text);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(ddlEstado, "O campo Data de Admissão é obrigatório!");

                    camposValidados = false;
                }

                if (!String.IsNullOrEmpty(mtbDataDemissao.Text))
                {
                    objCommand.Parameters.AddWithValue("@Data_Demissao", mtbDataDemissao.Text);

                    camposValidados = true;
                }

                if (!String.IsNullOrEmpty(txtCargo.Text))
                {
                    objCommand.Parameters.AddWithValue("@Cargo", txtCargo.Text);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(ddlEstado, "O campo Data de Admissão é obrigatório!");

                    camposValidados = false;
                }

                #endregion

                if (camposValidados)
                {
                    objConexao.Open();

                    objCommand.ExecuteNonQuery();

                    objConexao.Close();

                    MessageBox.Show("Registro alterado com sucesso!", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    LimparCampos();

                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CancelarAlteracoes()
        {
            if (MessageBox.Show("Tem certeza que deseja cancelar as alterações e voltar?", "Mensagem do Sistema",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                LimparCampos();
                this.Close();
            }
        }

        private void CarregarDados()
        {
            try
            {
                txtNome.Text = nome;
                txtEndereco.Text = endereco;
                txtCidade.Text = cidade;
                ddlEstado.SelectedText = estado;
                mtbTelefone.Text = telefone;
                mtbDataAdmissao.Text = dataAdmissao;
                mtbDataDemissao.Text = dataDemissao;
                txtCargo.Text = cargo;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LimparCampos()
        {
            try
            {
                txtNome.Text = string.Empty;
                txtEndereco.Text = string.Empty;
                txtCidade.Text = string.Empty;
                ddlEstado.SelectedIndex = -1;
                mtbTelefone.Text = string.Empty;
                mtbDataAdmissao.Text = string.Empty;
                mtbDataDemissao.Text = string.Empty;
                txtCargo.Text = string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion
    }
}
