﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class frmCadastrarFuncionarios : Form
    {
        public frmCadastrarFuncionarios()
        {
            InitializeComponent();
        }

        #region Botões

        private void tsbtnCancelar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você tem certeza que deseja voltar e cancelar o cadastro?", "Mensagem do Sistema",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void tsbtnGravar_Click(object sender, EventArgs e)
        {
            Gravar();
        }

        private void tsbtnVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

        #region Métodos

        private void Gravar()
        {
            //Crio uma variável booleana que irá verificar se os campos estão validados
            bool camposValidados = false;

            try
            {
                //Instancio a classe de conexão passando como parâmetro a string de conexão ao DataBase LibrarySystem
                SqlConnection objConexao = new SqlConnection(@"Data Source=WELLINGTON-PC\SQLEXPRESS;
                                            Initial Catalog=LibrarySystem;Integrated Security=True");

                //Armazeno em uma variável do tipo string minha instrução SQL referente à inserção do registro,
                //concatenando os valores parametrizados, referentes aos campos que serão preenchidos no form
                string strConn = @"INSERT INTO Funcionarios (Nome_Funcionario, Endereco_Funcionario, Cidade_Funcionario, Estado_Funcionario," +
                                "Telefone_Funcionario, Cargo_Funcionario, Data_Admissao_Funcionario, Data_Demissao_Funcionario) VALUES " + 
                                "(@Nome, @Endereco, @Cidade, @Estado, @Telefone, @Cargo, @DataAdmissao, @DataDemissao)";

                //Uso o objeto instanciado passando como parâmetro a string criada anteriomente e o objeto de conexão ao banco
                SqlCommand objCommand = new SqlCommand(strConn, objConexao);

                #region Validações dos Campos

                //Faço a verificação: se os campos do form estiverem diferentes de nulos uso o método AddWithValue passando como parâmetro
                //o Value parametrizado do Insert acima. Se os campos estiverem vazios, chamo o ErrorProvider disparando o erro ao usuário

                //Nome
                if (!String.IsNullOrEmpty(txtNome.Text))
                {
                    objCommand.Parameters.AddWithValue("@Nome", txtNome.Text);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(txtNome, "O campo Nome é obrigatório!");

                    camposValidados = false;
                }

                //Endereço
                if (!String.IsNullOrEmpty(txtEndereco.Text))
                {
                    objCommand.Parameters.AddWithValue("@Endereco", txtEndereco.Text);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(txtEndereco, "O campo Endereço é obrigatório!");

                    camposValidados = false;
                }

                //Cidade
                if (!String.IsNullOrEmpty(txtCidade.Text))
                {
                    objCommand.Parameters.AddWithValue("@Cidade", txtCidade.Text);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(txtCidade, "O campo Cidade é obrigatório!");

                    camposValidados = false;
                }

                //Estado
                if (ddlEstado.SelectedIndex > -1)
                {
                    objCommand.Parameters.AddWithValue("@Estado", ddlEstado.SelectedItem);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(ddlEstado, "O campo Estado é obrigatório!");

                    camposValidados = false;
                }

                //Telefone
                if (!String.IsNullOrEmpty(mtbTelefone.Text))
                {
                    objCommand.Parameters.AddWithValue("@Telefone", mtbTelefone.Text);

                    camposValidados = true;
                }

                //Data de Admissão
                if (!String.IsNullOrEmpty(mtbDataAdmissao.Text))
                {
                    objCommand.Parameters.AddWithValue("@DataAdmissao", mtbDataAdmissao.Text);
                        
                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(mtbDataAdmissao, "O campo Data de Admissão é obrigatório!");

                    camposValidados = false;
                }

                //Data de Demissão
                if (!String.IsNullOrEmpty(mtbDataDemissao.Text))
                {
                    objCommand.Parameters.AddWithValue("@DataDemissao", mtbDataDemissao.Text);

                    camposValidados = true;
                }

                //Cargo
                if (!String.IsNullOrEmpty(txtCargo.Text))
                {
                    objCommand.Parameters.AddWithValue("@Cargo", txtCargo.Text);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(txtCargo, "O campo Cargo é obrigatório!");

                    camposValidados = false;
                }

                #endregion

                //Verifico se o retorno de minha variável camposValidados é true
                if (camposValidados)
                {
                    //Abro a conexão
                    objConexao.Open();

                    //Uso o método ExecuteNonQuery para executar os comandos e realizar o Insert no banco
                    objCommand.ExecuteNonQuery();

                    //Fecho a conexão
                    objConexao.Close();

                    //Exibo a mensagem ao usuário de confirmação da inserção no banco
                    MessageBox.Show("Registro inserido com sucesso!", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //Chamo o método para limpar os campos e dou o foco ao txtNome
                    LimparCampos();
                    txtNome.Focus();

                    //Habilito o botão Voltar para o usuário
                    tsbtnVoltar.Enabled = true;
                }
                else
                {
                    //Exibo a mensagem ao usuário de erro
                    MessageBox.Show("Ops, ocorreram erros!\n\nPreencha os campos e tente novamente",
                        "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LimparCampos()
        {
            try
            {
                txtNome.Text = string.Empty;
                txtEndereco.Text = string.Empty;
                txtCidade.Text = string.Empty;
                ddlEstado.SelectedIndex = -1;
                mtbTelefone.Text = string.Empty;
                mtbDataAdmissao.Text = string.Empty;
                mtbDataDemissao.Text = string.Empty;
                txtCargo.Text = string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        private void mtbDataAdmissao_TypeValidationCompleted(object sender, TypeValidationEventArgs e)
        {
            if (e.ReturnValue != null)
            {
                DateTime valor = (DateTime)e.ReturnValue;
                MessageBox.Show("Validado: " + valor.ToLongDateString());
            }
            else
                MessageBox.Show("Informe uma data válida!");    
        }
    }
}
