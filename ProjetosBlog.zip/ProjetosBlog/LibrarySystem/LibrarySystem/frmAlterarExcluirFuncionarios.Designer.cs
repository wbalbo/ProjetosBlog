﻿namespace LibrarySystem
{
    partial class frmAlterarExcluirFuncionarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAlterarExcluirFuncionarios));
            this.lblMensagem = new System.Windows.Forms.Label();
            this.tsbtnVoltar = new System.Windows.Forms.ToolStripButton();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.dgvDados = new System.Windows.Forms.DataGridView();
            this.btnEditar = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btnExcluir = new System.Windows.Forms.DataGridViewButtonColumn();
            this.idFuncionarioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomeFuncionarioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.enderecoFuncionarioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cidadeFuncionarioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estadoFuncionarioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefoneFuncionarioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cargoFuncionarioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataAdmissaoFuncionarioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataDemissaoFuncionarioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.funcionariosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsLibrarySystem = new LibrarySystem.dsLibrarySystem();
            this.clientesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clientesTableAdapter = new LibrarySystem.dsLibrarySystemTableAdapters.ClientesTableAdapter();
            this.funcionariosTableAdapter = new LibrarySystem.dsLibrarySystemTableAdapters.FuncionariosTableAdapter();
            this.funcionariosBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.toolStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDados)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.funcionariosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsLibrarySystem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.funcionariosBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMensagem
            // 
            this.lblMensagem.AutoSize = true;
            this.lblMensagem.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMensagem.Location = new System.Drawing.Point(38, 11);
            this.lblMensagem.Name = "lblMensagem";
            this.lblMensagem.Size = new System.Drawing.Size(468, 19);
            this.lblMensagem.TabIndex = 17;
            this.lblMensagem.Text = "Selecione o Registro e clique nos botões para Alterar/Excluir";
            // 
            // tsbtnVoltar
            // 
            this.tsbtnVoltar.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnVoltar.Image")));
            this.tsbtnVoltar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbtnVoltar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnVoltar.Name = "tsbtnVoltar";
            this.tsbtnVoltar.Size = new System.Drawing.Size(90, 52);
            this.tsbtnVoltar.Text = "Voltar";
            this.tsbtnVoltar.Click += new System.EventHandler(this.tsbtnVoltar_Click);
            // 
            // toolStrip2
            // 
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnVoltar});
            this.toolStrip2.Location = new System.Drawing.Point(0, 317);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(544, 55);
            this.toolStrip2.TabIndex = 19;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // dgvDados
            // 
            this.dgvDados.AllowUserToAddRows = false;
            this.dgvDados.AllowUserToDeleteRows = false;
            this.dgvDados.AutoGenerateColumns = false;
            this.dgvDados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idFuncionarioDataGridViewTextBoxColumn,
            this.nomeFuncionarioDataGridViewTextBoxColumn,
            this.enderecoFuncionarioDataGridViewTextBoxColumn,
            this.cidadeFuncionarioDataGridViewTextBoxColumn,
            this.estadoFuncionarioDataGridViewTextBoxColumn,
            this.telefoneFuncionarioDataGridViewTextBoxColumn,
            this.cargoFuncionarioDataGridViewTextBoxColumn,
            this.dataAdmissaoFuncionarioDataGridViewTextBoxColumn,
            this.dataDemissaoFuncionarioDataGridViewTextBoxColumn,
            this.btnEditar,
            this.btnExcluir});
            this.dgvDados.DataSource = this.funcionariosBindingSource;
            this.dgvDados.Location = new System.Drawing.Point(6, 41);
            this.dgvDados.MultiSelect = false;
            this.dgvDados.Name = "dgvDados";
            this.dgvDados.ReadOnly = true;
            this.dgvDados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDados.Size = new System.Drawing.Size(526, 268);
            this.dgvDados.TabIndex = 18;
            this.dgvDados.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvDados_CellMouseClick);
            // 
            // btnEditar
            // 
            this.btnEditar.HeaderText = "Editar";
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.ReadOnly = true;
            this.btnEditar.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.btnEditar.Text = "Editar";
            this.btnEditar.UseColumnTextForButtonValue = true;
            this.btnEditar.Width = 60;
            // 
            // btnExcluir
            // 
            this.btnExcluir.HeaderText = "Excluir";
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.ReadOnly = true;
            this.btnExcluir.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.UseColumnTextForButtonValue = true;
            this.btnExcluir.Width = 60;
            // 
            // idFuncionarioDataGridViewTextBoxColumn
            // 
            this.idFuncionarioDataGridViewTextBoxColumn.DataPropertyName = "Id_Funcionario";
            this.idFuncionarioDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idFuncionarioDataGridViewTextBoxColumn.Name = "idFuncionarioDataGridViewTextBoxColumn";
            this.idFuncionarioDataGridViewTextBoxColumn.ReadOnly = true;
            this.idFuncionarioDataGridViewTextBoxColumn.Width = 5;
            // 
            // nomeFuncionarioDataGridViewTextBoxColumn
            // 
            this.nomeFuncionarioDataGridViewTextBoxColumn.DataPropertyName = "Nome_Funcionario";
            this.nomeFuncionarioDataGridViewTextBoxColumn.HeaderText = "Nome";
            this.nomeFuncionarioDataGridViewTextBoxColumn.Name = "nomeFuncionarioDataGridViewTextBoxColumn";
            this.nomeFuncionarioDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // enderecoFuncionarioDataGridViewTextBoxColumn
            // 
            this.enderecoFuncionarioDataGridViewTextBoxColumn.DataPropertyName = "Endereco_Funcionario";
            this.enderecoFuncionarioDataGridViewTextBoxColumn.HeaderText = "Endereço";
            this.enderecoFuncionarioDataGridViewTextBoxColumn.Name = "enderecoFuncionarioDataGridViewTextBoxColumn";
            this.enderecoFuncionarioDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cidadeFuncionarioDataGridViewTextBoxColumn
            // 
            this.cidadeFuncionarioDataGridViewTextBoxColumn.DataPropertyName = "Cidade_Funcionario";
            this.cidadeFuncionarioDataGridViewTextBoxColumn.HeaderText = "Cidade";
            this.cidadeFuncionarioDataGridViewTextBoxColumn.Name = "cidadeFuncionarioDataGridViewTextBoxColumn";
            this.cidadeFuncionarioDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // estadoFuncionarioDataGridViewTextBoxColumn
            // 
            this.estadoFuncionarioDataGridViewTextBoxColumn.DataPropertyName = "Estado_Funcionario";
            this.estadoFuncionarioDataGridViewTextBoxColumn.HeaderText = "Estado";
            this.estadoFuncionarioDataGridViewTextBoxColumn.Name = "estadoFuncionarioDataGridViewTextBoxColumn";
            this.estadoFuncionarioDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // telefoneFuncionarioDataGridViewTextBoxColumn
            // 
            this.telefoneFuncionarioDataGridViewTextBoxColumn.DataPropertyName = "Telefone_Funcionario";
            this.telefoneFuncionarioDataGridViewTextBoxColumn.HeaderText = "Telefone";
            this.telefoneFuncionarioDataGridViewTextBoxColumn.Name = "telefoneFuncionarioDataGridViewTextBoxColumn";
            this.telefoneFuncionarioDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cargoFuncionarioDataGridViewTextBoxColumn
            // 
            this.cargoFuncionarioDataGridViewTextBoxColumn.DataPropertyName = "Cargo_Funcionario";
            this.cargoFuncionarioDataGridViewTextBoxColumn.HeaderText = "Cargo";
            this.cargoFuncionarioDataGridViewTextBoxColumn.Name = "cargoFuncionarioDataGridViewTextBoxColumn";
            this.cargoFuncionarioDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dataAdmissaoFuncionarioDataGridViewTextBoxColumn
            // 
            this.dataAdmissaoFuncionarioDataGridViewTextBoxColumn.DataPropertyName = "Data_Admissao_Funcionario";
            this.dataAdmissaoFuncionarioDataGridViewTextBoxColumn.HeaderText = "Data de Admissão";
            this.dataAdmissaoFuncionarioDataGridViewTextBoxColumn.Name = "dataAdmissaoFuncionarioDataGridViewTextBoxColumn";
            this.dataAdmissaoFuncionarioDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dataDemissaoFuncionarioDataGridViewTextBoxColumn
            // 
            this.dataDemissaoFuncionarioDataGridViewTextBoxColumn.DataPropertyName = "Data_Demissao_Funcionario";
            this.dataDemissaoFuncionarioDataGridViewTextBoxColumn.HeaderText = "Data de Demissão";
            this.dataDemissaoFuncionarioDataGridViewTextBoxColumn.Name = "dataDemissaoFuncionarioDataGridViewTextBoxColumn";
            this.dataDemissaoFuncionarioDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // funcionariosBindingSource
            // 
            this.funcionariosBindingSource.DataMember = "Funcionarios";
            this.funcionariosBindingSource.DataSource = this.dsLibrarySystem;
            // 
            // dsLibrarySystem
            // 
            this.dsLibrarySystem.DataSetName = "dsLibrarySystem";
            this.dsLibrarySystem.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // clientesBindingSource
            // 
            this.clientesBindingSource.DataMember = "Clientes";
            this.clientesBindingSource.DataSource = this.dsLibrarySystem;
            // 
            // clientesTableAdapter
            // 
            this.clientesTableAdapter.ClearBeforeFill = true;
            // 
            // funcionariosTableAdapter
            // 
            this.funcionariosTableAdapter.ClearBeforeFill = true;
            // 
            // funcionariosBindingSource1
            // 
            this.funcionariosBindingSource1.DataMember = "Funcionarios";
            this.funcionariosBindingSource1.DataSource = this.dsLibrarySystem;
            // 
            // frmAlterarExcluirFuncionarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(544, 372);
            this.Controls.Add(this.lblMensagem);
            this.Controls.Add(this.toolStrip2);
            this.Controls.Add(this.dgvDados);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAlterarExcluirFuncionarios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Alterar / Excluir Funcionários";
            this.Load += new System.EventHandler(this.frmAlterarExcluirFuncionarios_Load);
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDados)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.funcionariosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsLibrarySystem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.funcionariosBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMensagem;
        public System.Windows.Forms.ToolStripButton tsbtnVoltar;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.DataGridView dgvDados;
        private dsLibrarySystem dsLibrarySystem;
        private System.Windows.Forms.BindingSource clientesBindingSource;
        private LibrarySystem.dsLibrarySystemTableAdapters.ClientesTableAdapter clientesTableAdapter;
        private System.Windows.Forms.BindingSource funcionariosBindingSource;
        private LibrarySystem.dsLibrarySystemTableAdapters.FuncionariosTableAdapter funcionariosTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idFuncionarioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomeFuncionarioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn enderecoFuncionarioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cidadeFuncionarioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn estadoFuncionarioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefoneFuncionarioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cargoFuncionarioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataAdmissaoFuncionarioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataDemissaoFuncionarioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn btnEditar;
        private System.Windows.Forms.DataGridViewButtonColumn btnExcluir;
        private System.Windows.Forms.BindingSource funcionariosBindingSource1;
    }
}