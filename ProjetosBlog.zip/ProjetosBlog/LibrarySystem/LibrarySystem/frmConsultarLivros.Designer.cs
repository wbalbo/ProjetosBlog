﻿namespace LibrarySystem
{
    partial class frmConsultarLivros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmConsultarLivros));
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.tsbtnVoltar = new System.Windows.Forms.ToolStripButton();
            this.lsvDados = new System.Windows.Forms.ListView();
            this.CodigoLivro = new System.Windows.Forms.ColumnHeader();
            this.NomeLivro = new System.Windows.Forms.ColumnHeader();
            this.AutorLivro = new System.Windows.Forms.ColumnHeader();
            this.AnoLivro = new System.Windows.Forms.ColumnHeader();
            this.GeneroLivro = new System.Windows.Forms.ColumnHeader();
            this.EditoraLivro = new System.Windows.Forms.ColumnHeader();
            this.PaginasLivro = new System.Windows.Forms.ColumnHeader();
            this.StatusLivro = new System.Windows.Forms.ColumnHeader();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.txtConsulta = new System.Windows.Forms.TextBox();
            this.gpbOpcoes = new System.Windows.Forms.GroupBox();
            this.rbtStatus = new System.Windows.Forms.RadioButton();
            this.rbtEditora = new System.Windows.Forms.RadioButton();
            this.rbtNome = new System.Windows.Forms.RadioButton();
            this.rbtDisponivel = new System.Windows.Forms.RadioButton();
            this.rbtIndisponivel = new System.Windows.Forms.RadioButton();
            this.toolStrip2.SuspendLayout();
            this.gpbOpcoes.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip2
            // 
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnVoltar});
            this.toolStrip2.Location = new System.Drawing.Point(0, 317);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(544, 55);
            this.toolStrip2.TabIndex = 6;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // tsbtnVoltar
            // 
            this.tsbtnVoltar.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnVoltar.Image")));
            this.tsbtnVoltar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbtnVoltar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnVoltar.Name = "tsbtnVoltar";
            this.tsbtnVoltar.Size = new System.Drawing.Size(90, 52);
            this.tsbtnVoltar.Text = "Voltar";
            this.tsbtnVoltar.Click += new System.EventHandler(this.tsbtnVoltar_Click);
            // 
            // lsvDados
            // 
            this.lsvDados.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsvDados.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CodigoLivro,
            this.NomeLivro,
            this.AutorLivro,
            this.AnoLivro,
            this.GeneroLivro,
            this.EditoraLivro,
            this.PaginasLivro,
            this.StatusLivro});
            this.lsvDados.FullRowSelect = true;
            this.lsvDados.GridLines = true;
            this.lsvDados.Location = new System.Drawing.Point(12, 86);
            this.lsvDados.MultiSelect = false;
            this.lsvDados.Name = "lsvDados";
            this.lsvDados.Size = new System.Drawing.Size(520, 218);
            this.lsvDados.TabIndex = 12;
            this.lsvDados.UseCompatibleStateImageBehavior = false;
            this.lsvDados.View = System.Windows.Forms.View.Details;
            // 
            // CodigoLivro
            // 
            this.CodigoLivro.Text = "Código";
            this.CodigoLivro.Width = 0;
            // 
            // NomeLivro
            // 
            this.NomeLivro.Text = "Nome do Livro";
            this.NomeLivro.Width = 180;
            // 
            // AutorLivro
            // 
            this.AutorLivro.Text = "Autor";
            this.AutorLivro.Width = 120;
            // 
            // AnoLivro
            // 
            this.AnoLivro.Text = "Ano";
            // 
            // GeneroLivro
            // 
            this.GeneroLivro.Text = "Gênero";
            this.GeneroLivro.Width = 100;
            // 
            // EditoraLivro
            // 
            this.EditoraLivro.Text = "Editora";
            this.EditoraLivro.Width = 120;
            // 
            // PaginasLivro
            // 
            this.PaginasLivro.Text = "Páginas";
            this.PaginasLivro.Width = 50;
            // 
            // StatusLivro
            // 
            this.StatusLivro.Text = "Status";
            // 
            // btnConsultar
            // 
            this.btnConsultar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultar.Location = new System.Drawing.Point(457, 51);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(75, 23);
            this.btnConsultar.TabIndex = 9;
            this.btnConsultar.Text = "Consultar";
            this.btnConsultar.UseVisualStyleBackColor = true;
            this.btnConsultar.Click += new System.EventHandler(this.btnConsultar_Click);
            // 
            // txtConsulta
            // 
            this.txtConsulta.Location = new System.Drawing.Point(247, 20);
            this.txtConsulta.Name = "txtConsulta";
            this.txtConsulta.Size = new System.Drawing.Size(285, 20);
            this.txtConsulta.TabIndex = 8;
            // 
            // gpbOpcoes
            // 
            this.gpbOpcoes.Controls.Add(this.rbtStatus);
            this.gpbOpcoes.Controls.Add(this.rbtEditora);
            this.gpbOpcoes.Controls.Add(this.rbtNome);
            this.gpbOpcoes.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbOpcoes.ForeColor = System.Drawing.Color.Black;
            this.gpbOpcoes.Location = new System.Drawing.Point(12, 12);
            this.gpbOpcoes.Name = "gpbOpcoes";
            this.gpbOpcoes.Size = new System.Drawing.Size(229, 62);
            this.gpbOpcoes.TabIndex = 7;
            this.gpbOpcoes.TabStop = false;
            this.gpbOpcoes.Text = "Filtro:";
            // 
            // rbtStatus
            // 
            this.rbtStatus.AutoSize = true;
            this.rbtStatus.Location = new System.Drawing.Point(157, 21);
            this.rbtStatus.Name = "rbtStatus";
            this.rbtStatus.Size = new System.Drawing.Size(65, 20);
            this.rbtStatus.TabIndex = 0;
            this.rbtStatus.Text = "Status";
            this.rbtStatus.UseVisualStyleBackColor = true;
            this.rbtStatus.CheckedChanged += new System.EventHandler(this.rbtStatus_CheckedChanged);
            // 
            // rbtEditora
            // 
            this.rbtEditora.AutoSize = true;
            this.rbtEditora.Location = new System.Drawing.Point(78, 21);
            this.rbtEditora.Name = "rbtEditora";
            this.rbtEditora.Size = new System.Drawing.Size(71, 20);
            this.rbtEditora.TabIndex = 0;
            this.rbtEditora.Text = "Editora";
            this.rbtEditora.UseVisualStyleBackColor = true;
            this.rbtEditora.CheckedChanged += new System.EventHandler(this.rbtEditora_CheckedChanged);
            // 
            // rbtNome
            // 
            this.rbtNome.AutoSize = true;
            this.rbtNome.Checked = true;
            this.rbtNome.Location = new System.Drawing.Point(7, 21);
            this.rbtNome.Name = "rbtNome";
            this.rbtNome.Size = new System.Drawing.Size(63, 20);
            this.rbtNome.TabIndex = 0;
            this.rbtNome.TabStop = true;
            this.rbtNome.Text = "Nome";
            this.rbtNome.UseVisualStyleBackColor = true;
            this.rbtNome.CheckedChanged += new System.EventHandler(this.rbtNome_CheckedChanged);
            // 
            // rbtDisponivel
            // 
            this.rbtDisponivel.AutoSize = true;
            this.rbtDisponivel.Checked = true;
            this.rbtDisponivel.Location = new System.Drawing.Point(247, 51);
            this.rbtDisponivel.Name = "rbtDisponivel";
            this.rbtDisponivel.Size = new System.Drawing.Size(76, 17);
            this.rbtDisponivel.TabIndex = 11;
            this.rbtDisponivel.TabStop = true;
            this.rbtDisponivel.Text = "Disponível";
            this.rbtDisponivel.UseVisualStyleBackColor = true;
            this.rbtDisponivel.Visible = false;
            // 
            // rbtIndisponivel
            // 
            this.rbtIndisponivel.AutoSize = true;
            this.rbtIndisponivel.Location = new System.Drawing.Point(329, 51);
            this.rbtIndisponivel.Name = "rbtIndisponivel";
            this.rbtIndisponivel.Size = new System.Drawing.Size(83, 17);
            this.rbtIndisponivel.TabIndex = 10;
            this.rbtIndisponivel.Text = "Indisponível";
            this.rbtIndisponivel.UseVisualStyleBackColor = true;
            this.rbtIndisponivel.Visible = false;
            // 
            // frmConsultarLivros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(544, 372);
            this.Controls.Add(this.lsvDados);
            this.Controls.Add(this.rbtIndisponivel);
            this.Controls.Add(this.rbtDisponivel);
            this.Controls.Add(this.btnConsultar);
            this.Controls.Add(this.txtConsulta);
            this.Controls.Add(this.gpbOpcoes);
            this.Controls.Add(this.toolStrip2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmConsultarLivros";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Consultar Livros";
            this.Load += new System.EventHandler(this.frmConsultarLivros_Load);
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.gpbOpcoes.ResumeLayout(false);
            this.gpbOpcoes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip2;
        public System.Windows.Forms.ToolStripButton tsbtnVoltar;
        private System.Windows.Forms.ColumnHeader CodigoLivro;
        private System.Windows.Forms.ColumnHeader NomeLivro;
        private System.Windows.Forms.ColumnHeader AutorLivro;
        private System.Windows.Forms.ColumnHeader AnoLivro;
        private System.Windows.Forms.ColumnHeader GeneroLivro;
        private System.Windows.Forms.ColumnHeader EditoraLivro;
        private System.Windows.Forms.ColumnHeader PaginasLivro;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.TextBox txtConsulta;
        private System.Windows.Forms.GroupBox gpbOpcoes;
        private System.Windows.Forms.RadioButton rbtStatus;
        private System.Windows.Forms.RadioButton rbtEditora;
        private System.Windows.Forms.RadioButton rbtNome;
        private System.Windows.Forms.RadioButton rbtDisponivel;
        private System.Windows.Forms.RadioButton rbtIndisponivel;
        private System.Windows.Forms.ColumnHeader StatusLivro;
        public System.Windows.Forms.ListView lsvDados;
    }
}