﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class frmCadastrarLivros : Form
    {
        public frmCadastrarLivros()
        {
            InitializeComponent();
        }

        #region Botões

        private void tsbtnCancelar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você tem certeza que deseja voltar e cancelar o cadastro?", "Mensagem do Sistema",
               MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void tsbtnGravar_Click(object sender, EventArgs e)
        {
            Gravar();
        }

        private void tsbtnVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

        #region Métodos

        private void Gravar()
        {
            //Crio uma variável booleana que irá verificar se os campos estão validados
            bool camposValidados = false;

            try
            {
                //Instancio a classe de conexão passando como parâmetro a string de conexão ao DataBase LibrarySystem
                SqlConnection objConexao = new SqlConnection(@"Data Source=WELLINGTON-PC\SQLEXPRESS;
                                            Initial Catalog=LibrarySystem;Integrated Security=True");

                //Armazeno em uma variável do tipo string minha instrução SQL referente à inserção do registro,
                //concatenando os valores parametrizados, referentes aos campos que serão preenchidos no form
                string strConn = @"INSERT INTO Livros (Nome_Livro, Autor_Livro, Ano_Livro, Genero_Livro, Editora_Livro," +
                                "Paginas_Livro, Status_Livro) VALUES (@Nome, @Autor, @Ano, @Genero, @Editora, @Paginas, @Status)";

                //Uso o objeto instanciado passando como parâmetro a string criada anteriomente e o objeto de conexão ao banco
                SqlCommand objCommand = new SqlCommand(strConn, objConexao);

                #region Validações dos Campos

                //Faço a verificação: se os campos do form estiverem diferentes de nulos uso o método AddWithValue passando como parâmetro
                //o Value parametrizado do Insert acima. Se os campos estiverem vazios, chamo o ErrorProvider disparando o erro ao usuário

                //Nome do Livro
                if (!String.IsNullOrEmpty(txtNomeLivro.Text))
                {
                    objCommand.Parameters.AddWithValue("@Nome", txtNomeLivro.Text);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(txtNomeLivro, "O campo Nome é obrigatório!");

                    camposValidados = false;
                }

                //Autor
                if (!String.IsNullOrEmpty(txtAutor.Text))
                {
                    objCommand.Parameters.AddWithValue("@Autor", txtAutor.Text);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(txtAutor, "O campo Autor é obrigatório!");

                    camposValidados = false;
                }

                //Ano
                if (!String.IsNullOrEmpty(txtAno.Text))
                {
                    objCommand.Parameters.AddWithValue("@Ano", txtAno.Text);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(txtAno, "O campo Ano é obrigatório!");

                    camposValidados = false;
                }

                //Número de Páginas
                if (!String.IsNullOrEmpty(txtPaginas.Text))
                {
                    objCommand.Parameters.AddWithValue("@Paginas", txtPaginas.Text);

                    camposValidados = true;
                }

                //Gênero
                if (!String.IsNullOrEmpty(txtGenero.Text))
                {
                    objCommand.Parameters.AddWithValue("@Genero", txtGenero.Text);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(txtGenero, "O campo Gênero é obrigatório!");

                    camposValidados = false;
                }

                //Status
                if (rbtDisponivel.Checked)
                {
                    objCommand.Parameters.AddWithValue("@Status", "D");

                    camposValidados = true;
                }
                else
                {
                    objCommand.Parameters.AddWithValue("@Status", "I");

                    camposValidados = true;
                }

                //Editora
                if (!String.IsNullOrEmpty(txtEditora.Text))
                {
                    objCommand.Parameters.AddWithValue("@Editora", txtEditora.Text);

                    camposValidados = true;
                }
                else
                {
                    epErro.SetError(txtGenero, "O campo Editora é obrigatório!");

                    camposValidados = false;
                }

                #endregion

                //Verifico se o retorno de minha variável camposValidados é true
                if (camposValidados)
                {
                    //Abro a conexão
                    objConexao.Open();

                    //Uso o método ExecuteNonQuery para executar os comandos e realizar o Insert no banco
                    objCommand.ExecuteNonQuery();

                    //Fecho a conexão
                    objConexao.Close();

                    //Exibo a mensagem ao usuário de confirmação da inserção no banco
                    MessageBox.Show("Registro inserido com sucesso!", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //Chamo o método para limpar os campos e dou o foco ao txtNome
                    LimparCampos();
                    txtNomeLivro.Focus();

                    //Habilito o botão Voltar para o usuário
                    tsbtnVoltar.Enabled = true;
                }
                else
                {
                    //Exibo a mensagem ao usuário de erro
                    MessageBox.Show("Ops, ocorreram erros!\n\nPreencha os campos e tente novamente",
                        "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LimparCampos()
        {
            txtNomeLivro.Text = string.Empty;
            txtAutor.Text = string.Empty;
            txtAno.Text = string.Empty;
            txtPaginas.Text = string.Empty;
            txtGenero.Text = string.Empty;
            txtEditora.Text = string.Empty;
            rbtDisponivel.Checked = true;
        }

        #endregion
    }
}