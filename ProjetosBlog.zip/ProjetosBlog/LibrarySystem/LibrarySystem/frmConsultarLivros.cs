﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LibrarySystem.dsLibrarySystemTableAdapters;

namespace LibrarySystem
{
    public partial class frmConsultarLivros : Form
    {
        public frmConsultarLivros()
        {
            InitializeComponent();
        }

        #region Botões

        private void tsbtnVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
        }

        #endregion

        #region Eventos

        private void frmConsultarLivros_Load(object sender, EventArgs e)
        {
            txtConsulta.Focus();
        }

        private void rbtEditora_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtEditora.Checked)
            {
                txtConsulta.Text = string.Empty;
                txtConsulta.Focus();
            }
        }

        private void rbtNome_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtNome.Checked)
            {
                txtConsulta.Text = string.Empty;
                txtConsulta.Focus();
            }
        }

        private void rbtStatus_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtStatus.Checked)
            {
                rbtDisponivel.Visible = true;
                rbtIndisponivel.Visible = true;
                txtConsulta.Enabled = false;
                rbtDisponivel.Checked = true;
            }
            else
            {
                rbtDisponivel.Visible = false;
                rbtIndisponivel.Visible = false;
                txtConsulta.Enabled = true;
            }
        }

        #endregion

        private void Consultar()
        {
            try
            {
                //Instancio o DataTable e TableAdapter de Livros
                dsLibrarySystem.LivrosDataTable objLivrosDataTable = new dsLibrarySystem.LivrosDataTable();
                LivrosTableAdapter objLivrosTableAdapter = new LivrosTableAdapter();

                //Verifico qual RadioButton o usuário checou e se o txtConsulta não está vazio para chamar o respectivo método
                if (rbtNome.Checked && !String.IsNullOrEmpty(txtConsulta.Text))
                {
                    //Preencho o TableAdapter com o método FillByNome, passando o DataTable e o txtConsulta como parâmetros
                    objLivrosTableAdapter.FillByNome(objLivrosDataTable, "%" + txtConsulta.Text + "%");

                    //Limpo os dados do meu ListView
                    lsvDados.Items.Clear();

                    //Uso o laço foreach para percorrer as linhas do ClientesDataTable e carregá-las em meu ListView
                    foreach (DataRow objDataRow in objLivrosDataTable.Rows)
                    {
                        //Instancio a classe ListViewItem e vou adicionando o item e subitens
                        ListViewItem objListViewItem = new ListViewItem();
                        objListViewItem.Text = objDataRow[0].ToString();
                        objListViewItem.SubItems.Add(objDataRow[1].ToString());
                        objListViewItem.SubItems.Add(objDataRow[2].ToString());
                        objListViewItem.SubItems.Add(objDataRow[3].ToString());
                        objListViewItem.SubItems.Add(objDataRow[4].ToString());
                        objListViewItem.SubItems.Add(objDataRow[5].ToString());
                        objListViewItem.SubItems.Add(objDataRow[6].ToString());

                        if (objDataRow[7].ToString() == "D")
                        {
                            objListViewItem.SubItems.Add("Disponível");
                        }
                        else
                        {
                            objListViewItem.SubItems.Add("Indisponível");
                        }

                        //No final adiciono os itens em meu ListView, passando como parâmetro o objListViewItem carregado
                        lsvDados.Items.Add(objListViewItem);
                    }
                }
                else if (rbtEditora.Checked && !String.IsNullOrEmpty(txtConsulta.Text))
                {
                    //Preencho o TableAdapter com o método FillByEditora, passando o DataTable e o txtConsulta como parâmetros
                    objLivrosTableAdapter.FillByEditora(objLivrosDataTable, "%" + txtConsulta.Text + "%");

                    //Limpo os dados do meu ListView
                    lsvDados.Items.Clear();

                    //Uso o laço foreach para percorrer as linhas do ClientesDataTable e carregá-las em meu ListView
                    foreach (DataRow objDataRow in objLivrosDataTable.Rows)
                    {
                        //Instancio a classe ListViewItem e vou adicionando o item e subitens
                        ListViewItem objListViewItem = new ListViewItem();
                        objListViewItem.Text = objDataRow[0].ToString();
                        objListViewItem.SubItems.Add(objDataRow[1].ToString());
                        objListViewItem.SubItems.Add(objDataRow[2].ToString());
                        objListViewItem.SubItems.Add(objDataRow[3].ToString());
                        objListViewItem.SubItems.Add(objDataRow[4].ToString());
                        objListViewItem.SubItems.Add(objDataRow[5].ToString());
                        objListViewItem.SubItems.Add(objDataRow[6].ToString());

                        if (objDataRow[7].ToString() == "D")
                        {
                            objListViewItem.SubItems.Add("Disponível");
                        }
                        else
                        {
                            objListViewItem.SubItems.Add("Indisponível");
                        }

                        //No final adiciono os itens em meu ListView, passando como parâmetro o objListViewItem carregado
                        lsvDados.Items.Add(objListViewItem);
                    }
                }
                else if (rbtStatus.Checked && rbtDisponivel.Checked)
                {
                    //Preencho o TableAdapter com o método FillByDisponivel, passando o DataTable como parâmetro
                    objLivrosTableAdapter.FillByDisponivel(objLivrosDataTable);

                    //Limpo os dados do meu ListView
                    lsvDados.Items.Clear();

                    //Uso o laço foreach para percorrer as linhas do ClientesDataTable e carregá-las em meu ListView
                    foreach (DataRow objDataRow in objLivrosDataTable.Rows)
                    {
                        //Instancio a classe ListViewItem e vou adicionando o item e subitens
                        ListViewItem objListViewItem = new ListViewItem();
                        objListViewItem.Text = objDataRow[0].ToString();
                        objListViewItem.SubItems.Add(objDataRow[1].ToString());
                        objListViewItem.SubItems.Add(objDataRow[2].ToString());
                        objListViewItem.SubItems.Add(objDataRow[3].ToString());
                        objListViewItem.SubItems.Add(objDataRow[4].ToString());
                        objListViewItem.SubItems.Add(objDataRow[5].ToString());
                        objListViewItem.SubItems.Add(objDataRow[6].ToString());
                        objListViewItem.SubItems.Add("Disponível");

                        //No final adiciono os itens em meu ListView, passando como parâmetro o objListViewItem carregado
                        lsvDados.Items.Add(objListViewItem);
                    }
                }
                else
                {
                    //Preencho o TableAdapter com o método FillByIndisponivel, passando o DataTable como parâmetro
                    objLivrosTableAdapter.FillByIndisponivel(objLivrosDataTable);

                    //Limpo os dados do meu ListView
                    lsvDados.Items.Clear();

                    //Uso o laço foreach para percorrer as linhas do ClientesDataTable e carregá-las em meu ListView
                    foreach (DataRow objDataRow in objLivrosDataTable.Rows)
                    {
                        //Instancio a classe ListViewItem e vou adicionando o item e subitens
                        ListViewItem objListViewItem = new ListViewItem();
                        objListViewItem.Text = objDataRow[0].ToString();
                        objListViewItem.SubItems.Add(objDataRow[1].ToString());
                        objListViewItem.SubItems.Add(objDataRow[2].ToString());
                        objListViewItem.SubItems.Add(objDataRow[3].ToString());
                        objListViewItem.SubItems.Add(objDataRow[4].ToString());
                        objListViewItem.SubItems.Add(objDataRow[5].ToString());
                        objListViewItem.SubItems.Add(objDataRow[6].ToString());
                        objListViewItem.SubItems.Add("Indisponível");

                        //No final adiciono os itens em meu ListView, passando como parâmetro o objListViewItem carregado
                        lsvDados.Items.Add(objListViewItem);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
