﻿namespace LibrarySystem {
    
    
    public partial class dsLibrarySystem {
    }
}


namespace LibrarySystem.dsLibrarySystemTableAdapters
{
    
    
    public partial class ClientesTableAdapter {
    }
}
