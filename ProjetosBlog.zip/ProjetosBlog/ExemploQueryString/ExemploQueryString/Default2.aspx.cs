﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExemploQueryString
{
    public partial class Default2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string valor = Request.QueryString["Parametro"];

            //if (valor != null)
            //{
            //    lblValorQueryString.Text = "Parâmetro: " + valor;
            //}

            foreach (String item in Request.QueryString.Keys)
            {
                lblValorQueryString.Text += "Chave= " + item + " --> " + Request.QueryString[item] + "<br>";                
            }

            
        }
    }
}
