﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ManipulandoArquivosTexto
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Declaro a variável que representará o arquivo e a inicializo como nula
        private string strPathFile = null;

        #region Métodos

        private void Abrir()
        {
            try
            {
                //Crio uma variável que irei definir o caminho onde vou abrir meu arquivo e a inicializo nula
                string strPath = null;

                //Instancio o OpenFileDialog e o chamo pelo método ShowDialog
                OpenFileDialog objOFD = new OpenFileDialog();
                objOFD.ShowDialog();

                //Atribuo minha variável strPath ao atributo FileName, que
                //representa o arquivo escolhido pelo usuário na caixa de diálogo
                strPath = objOFD.FileName;

                //Verifico se o arquivo que desejo abrir existe e passo como parâmetro a variável respectiva
                //Troco as variáveis strPathFile pela strPath, que está definindo o caminho do meu arquivo
                if (File.Exists(strPath))
                {
                    //Se existir "starto" um processo do sistema para abrir o arquivo e, sem precisar
                    //passar ao processo o aplicativo a ser aberto, ele abre automaticamente o Notepad
                    System.Diagnostics.Process.Start(strPath);
                }
                else
                { 
                    //Se não existir exibo a mensagem
                    MessageBox.Show("Arquivo não encontrado!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Alterar()
        {
            try
            {
                //Verifico se o arquivo que desejo abrir existe e passo como parâmetro a variável respectiva
                if (File.Exists(strPathFile))
                {
                    //Instancio o FileStream passando como parâmetro a variável padrão, o FileMode que será
                    //o modo Open e o FileAccess, que será Read(somente leitura). Este método é diferente dos
                    //demais: primeiro irei abrir o arquivo, depois criar um FileStream temporário que irá
                    //armazenar os novos dados e depois criarei outro FileStream para fazer a junção dos dois
                    using (FileStream fs = new FileStream(strPathFile, FileMode.Open, FileAccess.Read))
                    { 
                        //Aqui instancio o StreamReader passando como parâmetro o FileStream criado acima. 
                        //Uso o StreamReader já que faço 1º a leitura do arquivo. Irei percorrer o arquivo e
                        //quando encontrar uma string qualquer farei a alteração por outra string qualquer
                        using (StreamReader sr = new StreamReader(fs))
                        { 
                            //Crio o FileStream temporário onde irei gravar as informações
                            using (FileStream fsTmp = new FileStream(strPathFile + ".tmp", 
                                                       FileMode.Create, FileAccess.Write))
                            {
                                //Instancio o StreamWriter para escrever os dados no arquivo temporário,
                                //passando como parâmetro a variável fsTmp, referente ao FileStream criado
                                using (StreamWriter sw = new StreamWriter(fsTmp))
                                { 
                                    //Crio uma variável e a atribuo como nula. Faço um while que percorrerá
                                    //meu arquivo original e enquanto ele estiver diferente de nulo...
                                    string strLinha = null;
                                    while ((strLinha = sr.ReadLine()) != null)
                                    {
                                        //faço um indexof para verificar se existe a palavra adicionado,
                                        //se ela existir, a substituo pela palavra alterado
                                        if (strLinha.IndexOf("adicionado") > -1)
                                        {
                                            //uso o método Replace que espera o valor antigo e valor novo
                                            strLinha = strLinha.Replace("adicionado", "alterado");
                                        }
                                        //Chamo o método Write do StreamWriter passando o strLinha como parâmetro
                                        sw.Write(strLinha);
                                    }
                                }
                            }
                        }
                    }

                    //Ao final excluo o arquivo anterior e movo o temporário no lugar do original
                    //Dessa forma não perco os dados de modificação de meu arquivo
                    File.Delete(strPathFile);
                    
                    //No método Move passo o arquivo de origem, o temporário, e o de destino, o original
                    File.Move(strPathFile + ".tmp", strPathFile);
                    
                    //Exibo a mensagem ao usuário
                    MessageBox.Show("Arquivo alterado com sucesso!");
                }
                else
                {
                    //Se não existir exibo a mensagem
                    MessageBox.Show("Arquivo não encontrado!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Concatenar()
        {
            try
            {
                //Verifico se o arquivo que desejo abrir existe e passo como parâmetro a respectiva variável
                if (File.Exists(strPathFile))
                {
                    //Crio um using, dentro dele instancio o StreamWriter, uso a classe File e o método 
                    //AppendText para concatenar o texto, passando como parâmetro a variável strPathFile
                    using (StreamWriter sw = File.AppendText(strPathFile))
                    {
                        //Uso o método Write para escrever o arquivo que será adicionado no arquivo texto
                        sw.Write("\r\nTexto adicionado ao final do arquivo");
                    }

                    //Exibo a mensagem que o arquivo foi atualizado
                    MessageBox.Show("Arquivo atualizado!");
                }
                else
                {
                    //Se não existir exibo a mensagem
                    MessageBox.Show("Arquivo não encontrado!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Criar()
        {
            try
            {
                //Instancio o FolderBrowserDialog e o chamo pelo método ShowDialog
                FolderBrowserDialog objFBD = new FolderBrowserDialog();
                //Chamo o método sss para que esteja habilitado o botão para criar uma nova pasta
                objFBD.ShowNewFolderButton = true;
                objFBD.ShowDialog();

                //Crio uma variável que irei definir o caminho onde vou salvar meu arquivo de texto
                //Ela irá receber meu objFBD com o método SelectedPath, concatenado com meu arquivo
                string strPath = objFBD.SelectedPath + @"\Arquivo.txt";

                //Usarei a cláusula using como boas práticas de programação em todos os métodos
                //Instancio a classe FileStream, uso a classe File e o método Create para criar o
                //arquivo passando como parâmetro a variável strPathFile, que contém o arquivo

                //Troco a variável strPathFile pela strPath, que está definindo o caminho do meu arquivo
                using (FileStream fs = File.Create(strPath))
                {
                    //Crio outro using, dentro dele instancio o StreamWriter (classe para gravar os dados)
                    //que recebe como parâmetro a variável fs, referente ao FileStream criado anteriormente
                    using (StreamWriter sw = new StreamWriter(fs))
                    { 
                        //Uso o método Write para escrever algo em nosso arquivo texto
                        sw.Write("Texto adicionado ao exemplo!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //Se tudo ocorrer bem, exibo a mensagem ao usuário.
            MessageBox.Show("Arquivo criado com sucesso!!!");
        }

        private void Excluir()
        {
            try
            {
                //Verifico se o arquivo que desejo abrir existe e passo como parâmetro a variável respectiva
                if (File.Exists(strPathFile))
                {
                    //Se existir chamo o método Delete da classe File para apagá-lo e exibo uma msg ao usuário
                    File.Delete(strPathFile);
                    MessageBox.Show("Arquivo excluído com sucesso!");
                }
                else
                {
                    //Se não existir exibo a mensagem
                    MessageBox.Show("Arquivo não encontrado!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region Botões

        private void btnAbrir_Click(object sender, EventArgs e)
        {
            Abrir();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            Alterar();
        }

        private void btnConcatenar_Click(object sender, EventArgs e)
        {
            Concatenar();
        }

        private void btnCriar_Click(object sender, EventArgs e)
        {
            Criar();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            Excluir();
        }

        #endregion
    }
}
