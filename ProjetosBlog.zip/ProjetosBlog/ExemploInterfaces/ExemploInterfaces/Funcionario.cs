﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploInterfaces
{
    public class Funcionario
    {
        interface IReajuste
        {
            double Reajuste();
        }

        public class ReajusteFuncionario : IReajuste
        {
            //Propriedades públicas da minha classe
            public string nomeFuncionario;
            public double salarioFuncionario;

            //Implementação do método Reajuste, da interface IReajuste
            public double Reajuste()
            {
                salarioFuncionario = salarioFuncionario * 1.50;

                return salarioFuncionario;
                

                
            }

            public enum diasDaSemana { Domingo = 1, Segunda, Terca, Quarta, Quinta, Sexta, Sabado };            
        }
    }
}
