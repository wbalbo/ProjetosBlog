﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploInterfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            //Instancio a classe ReajusteFuncionario, que herda da interface IReajuste
            Funcionario.ReajusteFuncionario objReajusteFuncionario = new Funcionario.ReajusteFuncionario();

            //Atribuo valores fictícios para o nome e salário
            objReajusteFuncionario.nomeFuncionario = "Felipe Souza";
            objReajusteFuncionario.salarioFuncionario = 2500.00;

            //Escrevo os dados em tela
            Console.WriteLine("Antes do Reajuste: ");
            Console.WriteLine("\nNome: " + objReajusteFuncionario.nomeFuncionario);
            Console.WriteLine("\nSalário: R$ " + objReajusteFuncionario.salarioFuncionario);

            //Chamo o método Reajuste, implementado em minha classe, criado em minha interface
            objReajusteFuncionario.Reajuste();

            Console.WriteLine("\nDepois do Reajuste: ");
            Console.WriteLine("\nNome: " + objReajusteFuncionario.nomeFuncionario);
            Console.WriteLine("\nSalário: R$ " + objReajusteFuncionario.salarioFuncionario);

            //Paro a execução até que alguma tecla seja pressionada
            Console.ReadKey();
        }
    }
}
