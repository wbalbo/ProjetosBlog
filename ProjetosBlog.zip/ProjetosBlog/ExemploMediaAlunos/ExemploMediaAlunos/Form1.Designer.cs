﻿namespace ExemploMediaAlunos
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblNota1 = new System.Windows.Forms.Label();
            this.txtNota1 = new System.Windows.Forms.TextBox();
            this.lblNota2 = new System.Windows.Forms.Label();
            this.txtNota2 = new System.Windows.Forms.TextBox();
            this.lblNota3 = new System.Windows.Forms.Label();
            this.lblNota4 = new System.Windows.Forms.Label();
            this.txtNota3 = new System.Windows.Forms.TextBox();
            this.txtNota4 = new System.Windows.Forms.TextBox();
            this.lblNotaMaior = new System.Windows.Forms.Label();
            this.lblNotaMenor = new System.Windows.Forms.Label();
            this.lblMediaNota = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.lblMaiorNota = new System.Windows.Forms.Label();
            this.lblMenorNota = new System.Windows.Forms.Label();
            this.lblMedia = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(233, 46);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 5;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblNota1
            // 
            this.lblNota1.AutoSize = true;
            this.lblNota1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNota1.Location = new System.Drawing.Point(22, 46);
            this.lblNota1.Name = "lblNota1";
            this.lblNota1.Size = new System.Drawing.Size(93, 13);
            this.lblNota1.TabIndex = 1;
            this.lblNota1.Text = "Digite a Nota 1";
            // 
            // txtNota1
            // 
            this.txtNota1.Location = new System.Drawing.Point(143, 39);
            this.txtNota1.MaxLength = 3;
            this.txtNota1.Name = "txtNota1";
            this.txtNota1.Size = new System.Drawing.Size(46, 20);
            this.txtNota1.TabIndex = 1;
            this.txtNota1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNota1_KeyPress);
            // 
            // lblNota2
            // 
            this.lblNota2.AutoSize = true;
            this.lblNota2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNota2.Location = new System.Drawing.Point(22, 74);
            this.lblNota2.Name = "lblNota2";
            this.lblNota2.Size = new System.Drawing.Size(93, 13);
            this.lblNota2.TabIndex = 1;
            this.lblNota2.Text = "Digite a Nota 2";
            // 
            // txtNota2
            // 
            this.txtNota2.Location = new System.Drawing.Point(143, 67);
            this.txtNota2.MaxLength = 3;
            this.txtNota2.Name = "txtNota2";
            this.txtNota2.Size = new System.Drawing.Size(46, 20);
            this.txtNota2.TabIndex = 2;
            this.txtNota2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNota2_KeyPress);
            // 
            // lblNota3
            // 
            this.lblNota3.AutoSize = true;
            this.lblNota3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNota3.Location = new System.Drawing.Point(22, 102);
            this.lblNota3.Name = "lblNota3";
            this.lblNota3.Size = new System.Drawing.Size(93, 13);
            this.lblNota3.TabIndex = 1;
            this.lblNota3.Text = "Digite a Nota 3";
            // 
            // lblNota4
            // 
            this.lblNota4.AutoSize = true;
            this.lblNota4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNota4.Location = new System.Drawing.Point(22, 130);
            this.lblNota4.Name = "lblNota4";
            this.lblNota4.Size = new System.Drawing.Size(93, 13);
            this.lblNota4.TabIndex = 1;
            this.lblNota4.Text = "Digite a Nota 4";
            // 
            // txtNota3
            // 
            this.txtNota3.Location = new System.Drawing.Point(143, 95);
            this.txtNota3.MaxLength = 3;
            this.txtNota3.Name = "txtNota3";
            this.txtNota3.Size = new System.Drawing.Size(46, 20);
            this.txtNota3.TabIndex = 3;
            this.txtNota3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNota3_KeyPress);
            // 
            // txtNota4
            // 
            this.txtNota4.Location = new System.Drawing.Point(143, 123);
            this.txtNota4.MaxLength = 3;
            this.txtNota4.Name = "txtNota4";
            this.txtNota4.Size = new System.Drawing.Size(46, 20);
            this.txtNota4.TabIndex = 4;
            this.txtNota4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNota4_KeyPress);
            // 
            // lblNotaMaior
            // 
            this.lblNotaMaior.AutoSize = true;
            this.lblNotaMaior.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotaMaior.Location = new System.Drawing.Point(22, 181);
            this.lblNotaMaior.Name = "lblNotaMaior";
            this.lblNotaMaior.Size = new System.Drawing.Size(106, 13);
            this.lblNotaMaior.TabIndex = 1;
            this.lblNotaMaior.Text = "Sua Maior Nota é";
            // 
            // lblNotaMenor
            // 
            this.lblNotaMenor.AutoSize = true;
            this.lblNotaMenor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotaMenor.Location = new System.Drawing.Point(22, 208);
            this.lblNotaMenor.Name = "lblNotaMenor";
            this.lblNotaMenor.Size = new System.Drawing.Size(110, 13);
            this.lblNotaMenor.TabIndex = 1;
            this.lblNotaMenor.Text = "Sua Menor Nota é";
            // 
            // lblMediaNota
            // 
            this.lblMediaNota.AutoSize = true;
            this.lblMediaNota.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMediaNota.Location = new System.Drawing.Point(22, 235);
            this.lblMediaNota.Name = "lblMediaNota";
            this.lblMediaNota.Size = new System.Drawing.Size(78, 13);
            this.lblMediaNota.TabIndex = 1;
            this.lblMediaNota.Text = "Sua Média é";
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(233, 85);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 6;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(233, 124);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 7;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // lblMaiorNota
            // 
            this.lblMaiorNota.AutoSize = true;
            this.lblMaiorNota.Location = new System.Drawing.Point(151, 181);
            this.lblMaiorNota.Name = "lblMaiorNota";
            this.lblMaiorNota.Size = new System.Drawing.Size(0, 13);
            this.lblMaiorNota.TabIndex = 3;
            // 
            // lblMenorNota
            // 
            this.lblMenorNota.AutoSize = true;
            this.lblMenorNota.Location = new System.Drawing.Point(151, 208);
            this.lblMenorNota.Name = "lblMenorNota";
            this.lblMenorNota.Size = new System.Drawing.Size(0, 13);
            this.lblMenorNota.TabIndex = 3;
            // 
            // lblMedia
            // 
            this.lblMedia.AutoSize = true;
            this.lblMedia.Location = new System.Drawing.Point(151, 235);
            this.lblMedia.Name = "lblMedia";
            this.lblMedia.Size = new System.Drawing.Size(0, 13);
            this.lblMedia.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(343, 294);
            this.Controls.Add(this.lblMedia);
            this.Controls.Add(this.lblMenorNota);
            this.Controls.Add(this.lblMaiorNota);
            this.Controls.Add(this.txtNota4);
            this.Controls.Add(this.txtNota3);
            this.Controls.Add(this.txtNota2);
            this.Controls.Add(this.txtNota1);
            this.Controls.Add(this.lblMediaNota);
            this.Controls.Add(this.lblNotaMenor);
            this.Controls.Add(this.lblNotaMaior);
            this.Controls.Add(this.lblNota4);
            this.Controls.Add(this.lblNota3);
            this.Controls.Add(this.lblNota2);
            this.Controls.Add(this.lblNota1);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalcular);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Média dos Alunos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblNota1;
        private System.Windows.Forms.TextBox txtNota1;
        private System.Windows.Forms.Label lblNota2;
        private System.Windows.Forms.TextBox txtNota2;
        private System.Windows.Forms.Label lblNota3;
        private System.Windows.Forms.Label lblNota4;
        private System.Windows.Forms.TextBox txtNota3;
        private System.Windows.Forms.TextBox txtNota4;
        private System.Windows.Forms.Label lblNotaMaior;
        private System.Windows.Forms.Label lblNotaMenor;
        private System.Windows.Forms.Label lblMediaNota;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Label lblMaiorNota;
        private System.Windows.Forms.Label lblMenorNota;
        private System.Windows.Forms.Label lblMedia;
    }
}

