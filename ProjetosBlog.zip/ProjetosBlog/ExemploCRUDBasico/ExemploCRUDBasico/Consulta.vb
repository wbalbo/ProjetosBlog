﻿Public Class Consulta
    Dim index As Integer
#Region "Botões"
    Private Sub btnAlterar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAlterar.Click
        If lsvDados.SelectedItems.Count > 0 Then
            Dim instancia As New Cadastro()
            instancia.IdCliente = Integer.Parse(lsvDados.Items(index).Text)
            instancia.txtNome.Text = lsvDados.Items(index).SubItems(1).Text
            instancia.txtEndereco.Text = lsvDados.Items(index).SubItems(2).Text
            instancia.mtbTelefone.Text = lsvDados.Items(index).SubItems(3).Text

            If lsvDados.Items(index).SubItems(4).Text.Equals("Sim") Then
                instancia.rbtAtivo.Checked = True
            Else
                instancia.rbtInativo.Checked = True
            End If

            instancia.ShowDialog()
            Me.Close()
        End If
    End Sub

    Private Sub btnExcluir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExcluir.Click
        If lsvDados.SelectedItems.Count > 0 Then
            ExcluirRegistro(Integer.Parse(lsvDados.Items(index).Text))
            MessageBox.Show("Registro Excluído com Sucesso!")
        End If
    End Sub

    Private Sub btnVoltar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVoltar.Click
        Me.Close()
    End Sub
#End Region

#Region "Eventos"
    Private Sub Consulta_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CarregarListView()
    End Sub

    Private Sub lsvDados_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lsvDados.Click
        If lsvDados.SelectedItems.Count > 0 Then
            index = lsvDados.SelectedItems(0).Index
        End If
    End Sub
#End Region

#Region "Métodos"
    Private Sub CarregarListView()
        Dim objDados As New DadosClientes()
        Dim dt As New DataTable
        dt = objDados.ConsultarClientes()

        For Each linha As DataRow In dt.Rows
            Dim lista As New ListViewItem
            lista.Text = linha("IdCliente").ToString()
            lista.SubItems.Add(linha("Nome").ToString())
            lista.SubItems.Add(linha("Endereco").ToString())
            lista.SubItems.Add(linha("Telefone").ToString())

            If linha("Ativo").ToString().Equals("True") Then
                lista.SubItems.Add("Sim")
            Else
                lista.SubItems.Add("Não")
            End If

            lsvDados.Items.Add(lista)
        Next
    End Sub

    Private Sub ExcluirRegistro(ByVal IdCliente As Integer)
        Dim objDados As New DadosClientes()
        objDados.ExcluirCliente(IdCliente)
    End Sub
#End Region

    
End Class