﻿Imports System.Data.SqlClient

Public Class DadosClientes

    Public Class ClientesObj
        Public IdCliente As Integer = 0
        Public Nome As String = String.Empty
        Public Endereco As String = String.Empty
        Public Cidade As String = String.Empty
        Public Telefone As String = String.Empty
        Public Email As String = String.Empty
        Public Ativo As Boolean = False
    End Class

    'Variável com a string de conexão ao banco
    Public Const strConexao As String = "Data Source=WELLINGTON-PC\SQLEXPRESS;Initial Catalog=Artigos;Integrated Security=True"
    'Variável que receberá a Instrução SQL, que será passada de acordo com o método usado
    Public strInstrucao As String = String.Empty
    'Objeto instanciado da classe SqlConnection, com a string de conexão como parâmetro
    Public objConexao As New SqlConnection(strConexao)
    'Objeto instanciado da classe SqlCommand, com a instrução SQL e o objeto de conexão como parâmetro 
    Public objCommand As New SqlCommand(strInstrucao, objConexao)

    Public Sub AtualizarCliente(ByVal clientes As ClientesObj)

        strInstrucao = "UPDATE Clientes SET Nome = @Nome, Endereco = @Endereco, Cidade = @Cidade, Telefone = @Telefone, Email = @Email, Ativo = @Ativo Where IdCliente = @IdCliente"
        objCommand.CommandText = strInstrucao
        objCommand.Connection = objConexao
        objCommand.Parameters.AddWithValue("@IdCliente", clientes.IdCliente)
        objCommand.Parameters.AddWithValue("@Nome", clientes.Nome)
        objCommand.Parameters.AddWithValue("@Endereco", clientes.Endereco)
        objCommand.Parameters.AddWithValue("@Cidade", clientes.Cidade)
        objCommand.Parameters.AddWithValue("@Telefone", clientes.Telefone)
        objCommand.Parameters.AddWithValue("@Email", clientes.Email)
        objCommand.Parameters.AddWithValue("@Ativo", clientes.Ativo)

        objConexao.Open()
        objCommand.ExecuteNonQuery()
        objConexao.Close()

    End Sub

    Public Function ConsultarClientes() As DataTable

        Dim dt As New DataTable
        Dim ds As New DataSet()
        strInstrucao = "SELECT IdCliente, Nome, Endereco, Telefone, Ativo FROM Clientes"
        objCommand.CommandText = strInstrucao
        objCommand.Connection = objConexao

        objConexao.Open()
        Dim da As New SqlDataAdapter(objCommand)
        da.Fill(ds)
        dt = ds.Tables(0)

        objConexao.Close()
        Return dt

    End Function

    Public Sub ExcluirCliente(ByVal IdCliente As Integer)

        strInstrucao = "DELETE FROM Clientes WHERE IdCliente = @IdCliente"
        objCommand.CommandText = strInstrucao
        objCommand.Connection = objConexao
        objCommand.Parameters.AddWithValue("@IdCliente", IdCliente)

        objConexao.Open()
        objCommand.ExecuteNonQuery()
        objConexao.Close()

    End Sub

    Public Sub GravarCliente(ByVal clientes As ClientesObj)

        strInstrucao = "INSERT INTO Clientes VALUES (@Nome, @Endereco, @Cidade, @Telefone, @Email, @Ativo)"
        objCommand.CommandText = strInstrucao
        objCommand.Connection = objConexao
        objCommand.Parameters.AddWithValue("@Nome", clientes.Nome)
        objCommand.Parameters.AddWithValue("@Endereco", clientes.Endereco)
        objCommand.Parameters.AddWithValue("@Cidade", clientes.Cidade)
        objCommand.Parameters.AddWithValue("@Telefone", clientes.Telefone)
        objCommand.Parameters.AddWithValue("@Email", clientes.Email)
        objCommand.Parameters.AddWithValue("@Ativo", clientes.Ativo)

        objConexao.Open()
        objCommand.ExecuteNonQuery()
        objConexao.Close()

    End Sub

End Class
