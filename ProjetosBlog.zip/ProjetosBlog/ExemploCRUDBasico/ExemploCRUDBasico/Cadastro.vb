﻿Public Class Cadastro

    Public IdCliente As Integer = 0

#Region "Botões"
    Private Sub btnLimpar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLimpar.Click
        txtNome.Text = String.Empty
        txtEndereco.Text = String.Empty
        txtCidade.Text = String.Empty
        mtbTelefone.Text = String.Empty
        txtEmail.Text = String.Empty
        rbtAtivo.Checked = True
        txtNome.Focus()
    End Sub

    Private Sub btnGravar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGravar.Click
        If ValidarCampos() Then
            Gravar()
        End If
    End Sub

    Private Sub btnVerDados_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVerDados.Click
        Dim instancia As New Consulta()
        instancia.ShowDialog()
        Me.Close()
    End Sub

    Private Sub btnSair_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSair.Click
        If MessageBox.Show("Tem certeza que deseja sair do sistema?", "Pergunta do Sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            Me.Close()
        End If
    End Sub
#End Region

#Region "Métodos"
    Private Sub Gravar()
        Dim classe As New DadosClientes
        Dim objeto As New DadosClientes.ClientesObj

        objeto.Nome = txtNome.Text.Trim()
        objeto.Endereco = txtEndereco.Text.Trim()
        objeto.Cidade = txtCidade.Text.Trim()
        objeto.Telefone = mtbTelefone.Text.Trim()
        objeto.Email = txtEmail.Text.Trim()

        If rbtAtivo.Checked Then
            objeto.Ativo = True
        Else
            objeto.Ativo = False
        End If

        If (IdCliente > 0) Then
            objeto.IdCliente = IdCliente
            classe.AtualizarCliente(objeto)
            MessageBox.Show("Registro Alterado com Sucesso!")
        Else
            classe.GravarCliente(objeto)
            MessageBox.Show("Registro Gravado com Sucesso!")
        End If
    End Sub

    Private Function ValidarCampos() As Boolean
        Dim bRetorno As Boolean = True

        If String.IsNullOrEmpty(txtNome.Text) Then
            bRetorno = False
            epErro.SetError(txtNome, "Informe o Nome")
        End If

        If String.IsNullOrEmpty(txtEndereco.Text) Then
            bRetorno = False
            epErro.SetError(txtEndereco, "Informe o Endereço")
        End If

        If String.IsNullOrEmpty(txtCidade.Text) Then
            bRetorno = False
            epErro.SetError(txtCidade, "Informe a Cidade")
        End If

        Return bRetorno
    End Function
#End Region

End Class