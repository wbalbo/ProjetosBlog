﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Cadastro
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.rbtInativo = New System.Windows.Forms.RadioButton
        Me.rbtAtivo = New System.Windows.Forms.RadioButton
        Me.lblStatus = New System.Windows.Forms.Label
        Me.lblEmail = New System.Windows.Forms.Label
        Me.lblCidade = New System.Windows.Forms.Label
        Me.txtCidade = New System.Windows.Forms.TextBox
        Me.lblEndereco = New System.Windows.Forms.Label
        Me.txtEndereco = New System.Windows.Forms.TextBox
        Me.lblNome = New System.Windows.Forms.Label
        Me.txtNome = New System.Windows.Forms.TextBox
        Me.mtbTelefone = New System.Windows.Forms.MaskedTextBox
        Me.lblTelefone = New System.Windows.Forms.Label
        Me.txtEmail = New System.Windows.Forms.TextBox
        Me.btnGravar = New System.Windows.Forms.Button
        Me.btnLimpar = New System.Windows.Forms.Button
        Me.btnSair = New System.Windows.Forms.Button
        Me.btnVerDados = New System.Windows.Forms.Button
        Me.epErro = New System.Windows.Forms.ErrorProvider(Me.components)
        CType(Me.epErro, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'rbtInativo
        '
        Me.rbtInativo.AutoSize = True
        Me.rbtInativo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtInativo.Location = New System.Drawing.Point(221, 186)
        Me.rbtInativo.Name = "rbtInativo"
        Me.rbtInativo.Size = New System.Drawing.Size(57, 17)
        Me.rbtInativo.TabIndex = 7
        Me.rbtInativo.Text = "Inativo"
        Me.rbtInativo.UseVisualStyleBackColor = True
        '
        'rbtAtivo
        '
        Me.rbtAtivo.AutoSize = True
        Me.rbtAtivo.Checked = True
        Me.rbtAtivo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtAtivo.Location = New System.Drawing.Point(156, 186)
        Me.rbtAtivo.Name = "rbtAtivo"
        Me.rbtAtivo.Size = New System.Drawing.Size(49, 17)
        Me.rbtAtivo.TabIndex = 6
        Me.rbtAtivo.TabStop = True
        Me.rbtAtivo.Text = "Ativo"
        Me.rbtAtivo.UseVisualStyleBackColor = True
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.lblStatus.Location = New System.Drawing.Point(12, 186)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(56, 18)
        Me.lblStatus.TabIndex = 19
        Me.lblStatus.Text = "Status:"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.lblEmail.Location = New System.Drawing.Point(12, 155)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(52, 18)
        Me.lblEmail.TabIndex = 20
        Me.lblEmail.Text = "Email:"
        '
        'lblCidade
        '
        Me.lblCidade.AutoSize = True
        Me.lblCidade.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.lblCidade.Location = New System.Drawing.Point(12, 89)
        Me.lblCidade.Name = "lblCidade"
        Me.lblCidade.Size = New System.Drawing.Size(64, 18)
        Me.lblCidade.TabIndex = 17
        Me.lblCidade.Text = "Cidade:"
        '
        'txtCidade
        '
        Me.txtCidade.Location = New System.Drawing.Point(156, 89)
        Me.txtCidade.MaxLength = 20
        Me.txtCidade.Name = "txtCidade"
        Me.txtCidade.Size = New System.Drawing.Size(250, 20)
        Me.txtCidade.TabIndex = 3
        '
        'lblEndereco
        '
        Me.lblEndereco.AutoSize = True
        Me.lblEndereco.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.lblEndereco.Location = New System.Drawing.Point(12, 58)
        Me.lblEndereco.Name = "lblEndereco"
        Me.lblEndereco.Size = New System.Drawing.Size(80, 18)
        Me.lblEndereco.TabIndex = 15
        Me.lblEndereco.Text = "Endereço:"
        '
        'txtEndereco
        '
        Me.txtEndereco.Location = New System.Drawing.Point(156, 58)
        Me.txtEndereco.MaxLength = 40
        Me.txtEndereco.Name = "txtEndereco"
        Me.txtEndereco.Size = New System.Drawing.Size(250, 20)
        Me.txtEndereco.TabIndex = 2
        '
        'lblNome
        '
        Me.lblNome.AutoSize = True
        Me.lblNome.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNome.Location = New System.Drawing.Point(12, 27)
        Me.lblNome.Name = "lblNome"
        Me.lblNome.Size = New System.Drawing.Size(54, 18)
        Me.lblNome.TabIndex = 13
        Me.lblNome.Text = "Nome:"
        '
        'txtNome
        '
        Me.txtNome.Location = New System.Drawing.Point(156, 26)
        Me.txtNome.MaxLength = 40
        Me.txtNome.Name = "txtNome"
        Me.txtNome.Size = New System.Drawing.Size(250, 20)
        Me.txtNome.TabIndex = 1
        '
        'mtbTelefone
        '
        Me.mtbTelefone.Location = New System.Drawing.Point(158, 123)
        Me.mtbTelefone.Mask = "(99) 0000-0000"
        Me.mtbTelefone.Name = "mtbTelefone"
        Me.mtbTelefone.Size = New System.Drawing.Size(85, 20)
        Me.mtbTelefone.TabIndex = 4
        '
        'lblTelefone
        '
        Me.lblTelefone.AutoSize = True
        Me.lblTelefone.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.lblTelefone.Location = New System.Drawing.Point(12, 122)
        Me.lblTelefone.Name = "lblTelefone"
        Me.lblTelefone.Size = New System.Drawing.Size(70, 18)
        Me.lblTelefone.TabIndex = 25
        Me.lblTelefone.Text = "Telefone:"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(158, 153)
        Me.txtEmail.MaxLength = 20
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(250, 20)
        Me.txtEmail.TabIndex = 5
        '
        'btnGravar
        '
        Me.btnGravar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGravar.Location = New System.Drawing.Point(52, 226)
        Me.btnGravar.Name = "btnGravar"
        Me.btnGravar.Size = New System.Drawing.Size(75, 23)
        Me.btnGravar.TabIndex = 8
        Me.btnGravar.Text = "Gravar"
        Me.btnGravar.UseVisualStyleBackColor = True
        '
        'btnLimpar
        '
        Me.btnLimpar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLimpar.Location = New System.Drawing.Point(142, 226)
        Me.btnLimpar.Name = "btnLimpar"
        Me.btnLimpar.Size = New System.Drawing.Size(75, 23)
        Me.btnLimpar.TabIndex = 9
        Me.btnLimpar.Text = "Limpar"
        Me.btnLimpar.UseVisualStyleBackColor = True
        '
        'btnSair
        '
        Me.btnSair.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSair.Location = New System.Drawing.Point(322, 226)
        Me.btnSair.Name = "btnSair"
        Me.btnSair.Size = New System.Drawing.Size(75, 23)
        Me.btnSair.TabIndex = 11
        Me.btnSair.Text = "Sair"
        Me.btnSair.UseVisualStyleBackColor = True
        '
        'btnVerDados
        '
        Me.btnVerDados.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVerDados.Location = New System.Drawing.Point(232, 226)
        Me.btnVerDados.Name = "btnVerDados"
        Me.btnVerDados.Size = New System.Drawing.Size(75, 23)
        Me.btnVerDados.TabIndex = 10
        Me.btnVerDados.Text = "Ver"
        Me.btnVerDados.UseVisualStyleBackColor = True
        '
        'epErro
        '
        Me.epErro.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink
        Me.epErro.ContainerControl = Me
        '
        'Cadastro
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(449, 277)
        Me.Controls.Add(Me.btnVerDados)
        Me.Controls.Add(Me.btnSair)
        Me.Controls.Add(Me.btnLimpar)
        Me.Controls.Add(Me.btnGravar)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.mtbTelefone)
        Me.Controls.Add(Me.lblTelefone)
        Me.Controls.Add(Me.rbtInativo)
        Me.Controls.Add(Me.rbtAtivo)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.lblEmail)
        Me.Controls.Add(Me.lblCidade)
        Me.Controls.Add(Me.txtCidade)
        Me.Controls.Add(Me.lblEndereco)
        Me.Controls.Add(Me.txtEndereco)
        Me.Controls.Add(Me.lblNome)
        Me.Controls.Add(Me.txtNome)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Cadastro"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cadastro"
        CType(Me.epErro, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents lblStatus As System.Windows.Forms.Label
    Private WithEvents lblEmail As System.Windows.Forms.Label
    Private WithEvents lblCidade As System.Windows.Forms.Label
    Private WithEvents lblEndereco As System.Windows.Forms.Label
    Private WithEvents lblNome As System.Windows.Forms.Label
    Private WithEvents lblTelefone As System.Windows.Forms.Label
    Friend WithEvents btnGravar As System.Windows.Forms.Button
    Friend WithEvents btnLimpar As System.Windows.Forms.Button
    Friend WithEvents btnSair As System.Windows.Forms.Button
    Friend WithEvents btnVerDados As System.Windows.Forms.Button
    Friend WithEvents epErro As System.Windows.Forms.ErrorProvider
    Public WithEvents rbtInativo As System.Windows.Forms.RadioButton
    Public WithEvents rbtAtivo As System.Windows.Forms.RadioButton
    Public WithEvents txtCidade As System.Windows.Forms.TextBox
    Public WithEvents txtEndereco As System.Windows.Forms.TextBox
    Public WithEvents txtNome As System.Windows.Forms.TextBox
    Public WithEvents mtbTelefone As System.Windows.Forms.MaskedTextBox
    Public WithEvents txtEmail As System.Windows.Forms.TextBox
End Class
