﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.IO;

namespace ExemploWindowsService
{
    public partial class Service1 : ServiceBase
    {
        //Declare a variável global do tipo StreamWriter
        StreamWriter arquivoLog;

        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            //Instancie a variável criada, que receberá como parâmetro o caminho de meu arquivo de texto, 
            //que será o log destes eventos do meu serviço, e o parâmetro encoding com o valor true.
            arquivoLog = new StreamWriter(@"C:\testeLog.txt", true);

            //Escrevo no arquivo texto no momento exato que o arquivo for iniciado
            arquivoLog.WriteLine("Serviço iniciado em: " + DateTime.Now);

            //Limpo o buffer com o método Flush
            arquivoLog.Flush();            
        }

        protected override void OnStop()
        {
            //Escrevo no arquivo texto no momento exato que o arquivo for encerrado
            arquivoLog.WriteLine("Serviço encerrado em: " + DateTime.Now);

            //Fecho o arquivo com o método Close
            arquivoLog.Close();
        }
    }
}
