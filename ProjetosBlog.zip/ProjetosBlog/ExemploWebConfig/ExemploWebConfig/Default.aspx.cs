﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExemploWebConfig
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            RecuperaDados();
        }

        private void RecuperaDados()
        {
            try
            {
                //Instancio a classe InformacoesAmbiente
                InformacoesAmbiente objInfo = new InformacoesAmbiente();

                //Faço um Cast(conversão) em meu objeto instanciado e uso o método GetSection
                //para recuperar os dados da seção ConfigAmbiente que foi criada no Web.Config
                objInfo = (InformacoesAmbiente)ConfigurationManager.GetSection("ConfigAmbiente");

                //Com as informações armazenadas passo os valores das propriedades aos textboxes
                txtAmbiente.Text = objInfo.Ambiente;
                txtBancoDados.Text = objInfo.Database;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
