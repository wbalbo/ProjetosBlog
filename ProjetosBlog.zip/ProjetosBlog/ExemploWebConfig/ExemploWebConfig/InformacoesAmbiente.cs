﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace ExemploWebConfig
{
    public class InformacoesAmbiente : IConfigurationSectionHandler
    {
        [ConfigurationProperty("Ambiente", IsRequired = true)]
        public string Ambiente { get; set; }

        [ConfigurationProperty("Database", IsRequired = true)]
        public string Database { get; set; }

        #region IConfigurationSectionHandler Members

        public object Create(object parent, object configContext, System.Xml.XmlNode section)
        {
            Ambiente = section.Attributes["Ambiente"].Value;
            Database = section.Attributes["Database"].Value;

            return this;
        }

        #endregion
    }
}
