﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExemploCache
{
    public partial class DadosPessoa : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            RecuperaDadosDoCache();
        }

        private void RecuperaDadosDoCache()
        {
            try
            {
                //Verifico se meu Cache está diferente de nulo
                if (Cache["DadosPessoa"] != null)
                { 
                    //Instancio a classe Pessoa
                    Pessoa objPessoa = new Pessoa();

                    //Faço um Cast(conversão) no Cache para o tipo da classe Pessoa
                    objPessoa = (Pessoa)Cache["DadosPessoa"];

                    //Meus labels recebem os valores armazenados na classe Pessoa
                    lblNome.Text = objPessoa.Nome;
                    lblCidade.Text = objPessoa.Cidade;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
