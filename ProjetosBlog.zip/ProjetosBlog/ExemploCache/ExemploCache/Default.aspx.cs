﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExemploCache
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private void SalvarEmCache()        
        {
            try
            {
                //Instancio a classe Pessoa, passo as propriedades dela e as atribuo os valores aos textboxes
                Pessoa objPessoa = new Pessoa();
                objPessoa.Nome = txtNome.Text;
                objPessoa.Cidade = txtCidade.Text;

                //Crio o Cache com o nome DadosPessoa, que recebe o objeto instanciado da classe Pessoa
                //Forma 1:
                //Cache["DadosPessoa"] = objPessoa;

                //Forma 2 - método Insert:
                Cache.Insert("DadosPessoa", objPessoa, null, DateTime.Now.AddSeconds(30),
                 TimeSpan.Zero, System.Web.Caching.CacheItemPriority.NotRemovable, null);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        protected void btnSalvarCache_Click(object sender, EventArgs e)
        {
            SalvarEmCache();
        }

        protected void btnChamarPagina_Click(object sender, EventArgs e)
        {
            Response.Redirect("DadosPessoa.aspx");
        }
    }
}
