﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace ControlesASPNETData
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CarregaDadosRepeater();
            }
        }

        private void CarregaDadosRepeater()
        {
            string strConexao = @"Data Source=WELLINGTON-PC\SQLEXPRESS;Initial Catalog=Vendas;Integrated Security=True;Pooling=False";
            string strInstrucao = "SELECT DESCRICAO, QUANTIDADE FROM PEDIDOS";

            using (SqlConnection objConexao = new SqlConnection(strConexao))
            {
                using (SqlCommand objCommand = new SqlCommand(strInstrucao, objConexao))
                {
                    objCommand.Connection = objConexao;

                    objConexao.Open();

                    SqlDataReader objReader = objCommand.ExecuteReader();

                    Repeater1.DataSource = objReader;
                    Repeater1.DataBind();
                }
            }
        }
    }
}
