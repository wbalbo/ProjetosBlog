﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ExibicaoMestreDetalhe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            CarregarDados();
        }

        public DataViewManager dvManager;

        public void CarregarDados()
        {
            string strConexao = @"Data Source=WELLINGTON-PC\SQLEXPRESS;Initial Catalog=Northwind;Integrated Security=True";

            using (SqlConnection objConexao = new SqlConnection(strConexao))
            {
                DataSet ds = new DataSet("CustOrders");

                SqlDataAdapter daCustomers = new SqlDataAdapter("SELECT * FROM CUSTOMERS", objConexao);
                daCustomers.TableMappings.Add("Table", "Customers");
                daCustomers.Fill(ds);

                SqlDataAdapter daOrders = new SqlDataAdapter("SELECT * FROM ORDERS", objConexao);
                daOrders.TableMappings.Add("Table", "Orders");
                daOrders.Fill(ds);
                
                SqlDataAdapter daOrdersDetails = new SqlDataAdapter("SELECT * FROM [ORDER DETAILS]", objConexao);
                daOrdersDetails.TableMappings.Add("Table", "OrderDetails");
                daOrdersDetails.Fill(ds);

                DataRelation relCustOrder;
                DataColumn colMaster1;
                DataColumn colDetail1;
                colMaster1 = ds.Tables["Customers"].Columns["CustomerID"];
                colDetail1 = ds.Tables["Orders"].Columns["CustomerID"];
                relCustOrder = new DataRelation("RelCustomerOrder", colMaster1, colDetail1);
                ds.Relations.Add(relCustOrder);

                DataRelation relOrdDetail;
                DataColumn colMaster2;
                DataColumn colDetail2;
                colMaster2 = ds.Tables["Orders"].Columns["OrderID"];
                colDetail2 = ds.Tables["OrderDetails"].Columns["OrderID"];
                relOrdDetail = new DataRelation("RelOrderDetail", colMaster2, colDetail2);
                ds.Relations.Add(relOrdDetail);

                dvManager = ds.DefaultViewManager;

                dgvPedidos.DataSource = dvManager;
                dgvPedidos.DataMember = "Customers.RelCustomerOrder";

                dgvDetalhesPedido.DataSource = dvManager;
                dgvDetalhesPedido.DataMember = "Customers.RelCustomerOrder.RelOrderDetail";

                cboNome.DataSource = dvManager;
                cboNome.DisplayMember = "Customers.CompanyName";
                cboNome.ValueMember = "Customers.CustomerID";

                txtContato.DataBindings.Add("Text", dvManager, "Customers.ContactName");
                txtTelefone.DataBindings.Add("Text", dvManager, "Customers.Phone");
            }
        }

        private void btnAvancar_Click(object sender, EventArgs e)
        {
            CurrencyManager cm = (CurrencyManager)this.BindingContext[dvManager, "Customers"];

            if (cm.Position < cm.Count - 1)
            {
                cm.Position++;
            }
        }

        private void btnRetroceder_Click(object sender, EventArgs e)
        {
            if (this.BindingContext[dvManager, "Customers"].Position > 0)
            {
                this.BindingContext[dvManager, "Customers"].Position--;
            }
        }
    }
}
