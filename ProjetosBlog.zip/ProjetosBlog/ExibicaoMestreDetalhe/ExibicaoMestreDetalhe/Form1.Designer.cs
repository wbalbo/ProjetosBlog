﻿namespace ExibicaoMestreDetalhe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpbCliente = new System.Windows.Forms.GroupBox();
            this.lblTelefone = new System.Windows.Forms.Label();
            this.lblContato = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtTelefone = new System.Windows.Forms.TextBox();
            this.txtContato = new System.Windows.Forms.TextBox();
            this.cboNome = new System.Windows.Forms.ComboBox();
            this.btnAvancar = new System.Windows.Forms.Button();
            this.btnRetroceder = new System.Windows.Forms.Button();
            this.gpbPedidos = new System.Windows.Forms.GroupBox();
            this.dgvPedidos = new System.Windows.Forms.DataGridView();
            this.gpbDetalhesPedido = new System.Windows.Forms.GroupBox();
            this.dgvDetalhesPedido = new System.Windows.Forms.DataGridView();
            this.gpbCliente.SuspendLayout();
            this.gpbPedidos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPedidos)).BeginInit();
            this.gpbDetalhesPedido.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalhesPedido)).BeginInit();
            this.SuspendLayout();
            // 
            // gpbCliente
            // 
            this.gpbCliente.Controls.Add(this.lblTelefone);
            this.gpbCliente.Controls.Add(this.lblContato);
            this.gpbCliente.Controls.Add(this.lblNome);
            this.gpbCliente.Controls.Add(this.txtTelefone);
            this.gpbCliente.Controls.Add(this.txtContato);
            this.gpbCliente.Controls.Add(this.cboNome);
            this.gpbCliente.Controls.Add(this.btnAvancar);
            this.gpbCliente.Controls.Add(this.btnRetroceder);
            this.gpbCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbCliente.Location = new System.Drawing.Point(12, 12);
            this.gpbCliente.Name = "gpbCliente";
            this.gpbCliente.Size = new System.Drawing.Size(542, 100);
            this.gpbCliente.TabIndex = 0;
            this.gpbCliente.TabStop = false;
            this.gpbCliente.Text = "Cliente";
            // 
            // lblTelefone
            // 
            this.lblTelefone.AutoSize = true;
            this.lblTelefone.Location = new System.Drawing.Point(208, 71);
            this.lblTelefone.Name = "lblTelefone";
            this.lblTelefone.Size = new System.Drawing.Size(52, 13);
            this.lblTelefone.TabIndex = 9;
            this.lblTelefone.Text = "Telefone:";
            // 
            // lblContato
            // 
            this.lblContato.AutoSize = true;
            this.lblContato.Location = new System.Drawing.Point(213, 43);
            this.lblContato.Name = "lblContato";
            this.lblContato.Size = new System.Drawing.Size(47, 13);
            this.lblContato.TabIndex = 8;
            this.lblContato.Text = "Contato:";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(222, 16);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(38, 13);
            this.lblNome.TabIndex = 7;
            this.lblNome.Text = "Nome:";
            // 
            // txtTelefone
            // 
            this.txtTelefone.Location = new System.Drawing.Point(289, 68);
            this.txtTelefone.Name = "txtTelefone";
            this.txtTelefone.Size = new System.Drawing.Size(231, 20);
            this.txtTelefone.TabIndex = 6;
            // 
            // txtContato
            // 
            this.txtContato.Location = new System.Drawing.Point(289, 40);
            this.txtContato.Name = "txtContato";
            this.txtContato.Size = new System.Drawing.Size(231, 20);
            this.txtContato.TabIndex = 5;
            // 
            // cboNome
            // 
            this.cboNome.FormattingEnabled = true;
            this.cboNome.Location = new System.Drawing.Point(289, 13);
            this.cboNome.Name = "cboNome";
            this.cboNome.Size = new System.Drawing.Size(231, 21);
            this.cboNome.TabIndex = 4;
            // 
            // btnAvancar
            // 
            this.btnAvancar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAvancar.Location = new System.Drawing.Point(34, 24);
            this.btnAvancar.Name = "btnAvancar";
            this.btnAvancar.Size = new System.Drawing.Size(75, 23);
            this.btnAvancar.TabIndex = 2;
            this.btnAvancar.Text = ">>";
            this.btnAvancar.UseVisualStyleBackColor = true;
            this.btnAvancar.Click += new System.EventHandler(this.btnAvancar_Click);
            // 
            // btnRetroceder
            // 
            this.btnRetroceder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRetroceder.Location = new System.Drawing.Point(34, 53);
            this.btnRetroceder.Name = "btnRetroceder";
            this.btnRetroceder.Size = new System.Drawing.Size(75, 23);
            this.btnRetroceder.TabIndex = 3;
            this.btnRetroceder.Text = "<<";
            this.btnRetroceder.UseVisualStyleBackColor = true;
            this.btnRetroceder.Click += new System.EventHandler(this.btnRetroceder_Click);
            // 
            // gpbPedidos
            // 
            this.gpbPedidos.Controls.Add(this.dgvPedidos);
            this.gpbPedidos.Location = new System.Drawing.Point(12, 115);
            this.gpbPedidos.Name = "gpbPedidos";
            this.gpbPedidos.Size = new System.Drawing.Size(542, 100);
            this.gpbPedidos.TabIndex = 1;
            this.gpbPedidos.TabStop = false;
            this.gpbPedidos.Text = "Pedidos";
            // 
            // dgvPedidos
            // 
            this.dgvPedidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPedidos.Location = new System.Drawing.Point(19, 19);
            this.dgvPedidos.Name = "dgvPedidos";
            this.dgvPedidos.Size = new System.Drawing.Size(504, 75);
            this.dgvPedidos.TabIndex = 1;
            // 
            // gpbDetalhesPedido
            // 
            this.gpbDetalhesPedido.Controls.Add(this.dgvDetalhesPedido);
            this.gpbDetalhesPedido.Location = new System.Drawing.Point(12, 221);
            this.gpbDetalhesPedido.Name = "gpbDetalhesPedido";
            this.gpbDetalhesPedido.Size = new System.Drawing.Size(542, 100);
            this.gpbDetalhesPedido.TabIndex = 1;
            this.gpbDetalhesPedido.TabStop = false;
            this.gpbDetalhesPedido.Text = "Detalhes do Pedido";
            // 
            // dgvDetalhesPedido
            // 
            this.dgvDetalhesPedido.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetalhesPedido.Location = new System.Drawing.Point(19, 19);
            this.dgvDetalhesPedido.Name = "dgvDetalhesPedido";
            this.dgvDetalhesPedido.Size = new System.Drawing.Size(504, 75);
            this.dgvDetalhesPedido.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 333);
            this.Controls.Add(this.gpbPedidos);
            this.Controls.Add(this.gpbDetalhesPedido);
            this.Controls.Add(this.gpbCliente);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exibição Mestre-Detalhe";
            this.gpbCliente.ResumeLayout(false);
            this.gpbCliente.PerformLayout();
            this.gpbPedidos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPedidos)).EndInit();
            this.gpbDetalhesPedido.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalhesPedido)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gpbCliente;
        private System.Windows.Forms.TextBox txtTelefone;
        private System.Windows.Forms.TextBox txtContato;
        private System.Windows.Forms.ComboBox cboNome;
        private System.Windows.Forms.Button btnAvancar;
        private System.Windows.Forms.Button btnRetroceder;
        private System.Windows.Forms.GroupBox gpbPedidos;
        private System.Windows.Forms.GroupBox gpbDetalhesPedido;
        private System.Windows.Forms.Label lblTelefone;
        private System.Windows.Forms.Label lblContato;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.DataGridView dgvPedidos;
        private System.Windows.Forms.DataGridView dgvDetalhesPedido;
    }
}

