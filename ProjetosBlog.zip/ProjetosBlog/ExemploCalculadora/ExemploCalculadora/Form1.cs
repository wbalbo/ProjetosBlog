﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExemploCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void Visor()
        {
            
        }

        public void Somar()
        {
            if (txtValor.Text != string.Empty)
            {

            }
        }

        private void btnZero_MouseClick(object sender, MouseEventArgs e)
        {
            decimal zero = 0;
            txtValor.Text += zero.ToString();
        }

        private void btnUm_MouseClick(object sender, MouseEventArgs e)
        {
            decimal um = 1;
            txtValor.Text += um.ToString();
        }

        private void btnDois_MouseClick(object sender, MouseEventArgs e)
        {
            decimal dois = 2;
            txtValor.Text += dois.ToString();
        }

        private void btnTres_MouseClick(object sender, MouseEventArgs e)
        {
            decimal tres = 3;
            txtValor.Text += tres.ToString();
        }

        private void btnQuatro_MouseClick(object sender, MouseEventArgs e)
        {
            decimal quatro = 4;
            txtValor.Text += quatro.ToString();
        }

        private void btnCinco_MouseClick(object sender, MouseEventArgs e)
        {
            decimal cinco = 5;
            txtValor.Text += cinco.ToString();
        }

        private void btnSeis_MouseClick(object sender, MouseEventArgs e)
        {
            decimal seis = 6;
            txtValor.Text += seis.ToString();
        }

        private void btnSete_MouseClick(object sender, MouseEventArgs e)
        {
            decimal sete = 7;
            txtValor.Text += sete.ToString();
        }

        private void btnOito_MouseClick(object sender, MouseEventArgs e)
        {
            decimal oito = 8;
            txtValor.Text += oito.ToString();
        }

        private void btnNove_MouseClick(object sender, MouseEventArgs e)
        {
            decimal nove = 9;
            txtValor.Text += nove.ToString();
        }

        private void txtValor_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}