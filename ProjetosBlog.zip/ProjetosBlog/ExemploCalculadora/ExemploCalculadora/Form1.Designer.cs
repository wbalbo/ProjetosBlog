﻿namespace ExemploCalculadora
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBackspace = new System.Windows.Forms.Button();
            this.btnLimparNumero = new System.Windows.Forms.Button();
            this.btnLimparCalculo = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.btnLimparNroMemoria = new System.Windows.Forms.Button();
            this.btnSete = new System.Windows.Forms.Button();
            this.btnOito = new System.Windows.Forms.Button();
            this.btnNove = new System.Windows.Forms.Button();
            this.btnDividir = new System.Windows.Forms.Button();
            this.btnCalcularRaiz = new System.Windows.Forms.Button();
            this.btnRecuperarNroMemoria = new System.Windows.Forms.Button();
            this.btnQuatro = new System.Windows.Forms.Button();
            this.btnCinco = new System.Windows.Forms.Button();
            this.btnSeis = new System.Windows.Forms.Button();
            this.btnMultiplicar = new System.Windows.Forms.Button();
            this.btnCalcularPorcentagem = new System.Windows.Forms.Button();
            this.btnArmazenarNroMemoria = new System.Windows.Forms.Button();
            this.btnUm = new System.Windows.Forms.Button();
            this.btnDois = new System.Windows.Forms.Button();
            this.btnTres = new System.Windows.Forms.Button();
            this.btnSubtrair = new System.Windows.Forms.Button();
            this.btnCalcularReciprocaNro = new System.Windows.Forms.Button();
            this.btnArmazenarNroDaMemoria = new System.Windows.Forms.Button();
            this.btnZero = new System.Windows.Forms.Button();
            this.btnAlterarSinal = new System.Windows.Forms.Button();
            this.btnInserirVirgula = new System.Windows.Forms.Button();
            this.btnSomar = new System.Windows.Forms.Button();
            this.btnCalcularResultado = new System.Windows.Forms.Button();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnBackspace
            // 
            this.btnBackspace.ForeColor = System.Drawing.Color.Red;
            this.btnBackspace.Location = new System.Drawing.Point(28, 47);
            this.btnBackspace.Name = "btnBackspace";
            this.btnBackspace.Size = new System.Drawing.Size(75, 34);
            this.btnBackspace.TabIndex = 2;
            this.btnBackspace.Text = "Backspace";
            this.btnBackspace.UseVisualStyleBackColor = true;
            // 
            // btnLimparNumero
            // 
            this.btnLimparNumero.ForeColor = System.Drawing.Color.Red;
            this.btnLimparNumero.Location = new System.Drawing.Point(109, 47);
            this.btnLimparNumero.Name = "btnLimparNumero";
            this.btnLimparNumero.Size = new System.Drawing.Size(75, 34);
            this.btnLimparNumero.TabIndex = 5;
            this.btnLimparNumero.Text = "CE";
            this.btnLimparNumero.UseVisualStyleBackColor = true;
            // 
            // btnLimparCalculo
            // 
            this.btnLimparCalculo.ForeColor = System.Drawing.Color.Red;
            this.btnLimparCalculo.Location = new System.Drawing.Point(190, 47);
            this.btnLimparCalculo.Name = "btnLimparCalculo";
            this.btnLimparCalculo.Size = new System.Drawing.Size(75, 34);
            this.btnLimparCalculo.TabIndex = 6;
            this.btnLimparCalculo.Text = "C";
            this.btnLimparCalculo.UseVisualStyleBackColor = true;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(97, 211);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 19);
            this.lblResultado.TabIndex = 0;
            // 
            // btnLimparNroMemoria
            // 
            this.btnLimparNroMemoria.ForeColor = System.Drawing.Color.Red;
            this.btnLimparNroMemoria.Location = new System.Drawing.Point(7, 96);
            this.btnLimparNroMemoria.Name = "btnLimparNroMemoria";
            this.btnLimparNroMemoria.Size = new System.Drawing.Size(36, 27);
            this.btnLimparNroMemoria.TabIndex = 7;
            this.btnLimparNroMemoria.Text = "MC";
            this.btnLimparNroMemoria.UseVisualStyleBackColor = true;
            // 
            // btnSete
            // 
            this.btnSete.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSete.Location = new System.Drawing.Point(61, 97);
            this.btnSete.Name = "btnSete";
            this.btnSete.Size = new System.Drawing.Size(36, 27);
            this.btnSete.TabIndex = 7;
            this.btnSete.Text = "7";
            this.btnSete.UseVisualStyleBackColor = true;
            this.btnSete.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnSete_MouseClick);
            // 
            // btnOito
            // 
            this.btnOito.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnOito.Location = new System.Drawing.Point(103, 97);
            this.btnOito.Name = "btnOito";
            this.btnOito.Size = new System.Drawing.Size(36, 27);
            this.btnOito.TabIndex = 7;
            this.btnOito.Text = "8";
            this.btnOito.UseVisualStyleBackColor = true;
            this.btnOito.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnOito_MouseClick);
            // 
            // btnNove
            // 
            this.btnNove.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnNove.Location = new System.Drawing.Point(145, 97);
            this.btnNove.Name = "btnNove";
            this.btnNove.Size = new System.Drawing.Size(36, 27);
            this.btnNove.TabIndex = 7;
            this.btnNove.Text = "9";
            this.btnNove.UseVisualStyleBackColor = true;
            this.btnNove.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnNove_MouseClick);
            // 
            // btnDividir
            // 
            this.btnDividir.ForeColor = System.Drawing.Color.Red;
            this.btnDividir.Location = new System.Drawing.Point(187, 96);
            this.btnDividir.Name = "btnDividir";
            this.btnDividir.Size = new System.Drawing.Size(36, 27);
            this.btnDividir.TabIndex = 7;
            this.btnDividir.Text = "/";
            this.btnDividir.UseVisualStyleBackColor = true;
            // 
            // btnCalcularRaiz
            // 
            this.btnCalcularRaiz.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCalcularRaiz.Location = new System.Drawing.Point(229, 96);
            this.btnCalcularRaiz.Name = "btnCalcularRaiz";
            this.btnCalcularRaiz.Size = new System.Drawing.Size(36, 27);
            this.btnCalcularRaiz.TabIndex = 7;
            this.btnCalcularRaiz.Text = "sqrt";
            this.btnCalcularRaiz.UseVisualStyleBackColor = true;
            // 
            // btnRecuperarNroMemoria
            // 
            this.btnRecuperarNroMemoria.ForeColor = System.Drawing.Color.Red;
            this.btnRecuperarNroMemoria.Location = new System.Drawing.Point(7, 129);
            this.btnRecuperarNroMemoria.Name = "btnRecuperarNroMemoria";
            this.btnRecuperarNroMemoria.Size = new System.Drawing.Size(36, 27);
            this.btnRecuperarNroMemoria.TabIndex = 7;
            this.btnRecuperarNroMemoria.Text = "MR";
            this.btnRecuperarNroMemoria.UseVisualStyleBackColor = true;
            // 
            // btnQuatro
            // 
            this.btnQuatro.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnQuatro.Location = new System.Drawing.Point(61, 130);
            this.btnQuatro.Name = "btnQuatro";
            this.btnQuatro.Size = new System.Drawing.Size(36, 27);
            this.btnQuatro.TabIndex = 7;
            this.btnQuatro.Text = "4";
            this.btnQuatro.UseVisualStyleBackColor = true;
            this.btnQuatro.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnQuatro_MouseClick);
            // 
            // btnCinco
            // 
            this.btnCinco.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCinco.Location = new System.Drawing.Point(103, 130);
            this.btnCinco.Name = "btnCinco";
            this.btnCinco.Size = new System.Drawing.Size(36, 27);
            this.btnCinco.TabIndex = 7;
            this.btnCinco.Text = "5";
            this.btnCinco.UseVisualStyleBackColor = true;
            this.btnCinco.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnCinco_MouseClick);
            // 
            // btnSeis
            // 
            this.btnSeis.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSeis.Location = new System.Drawing.Point(145, 130);
            this.btnSeis.Name = "btnSeis";
            this.btnSeis.Size = new System.Drawing.Size(36, 27);
            this.btnSeis.TabIndex = 7;
            this.btnSeis.Text = "6";
            this.btnSeis.UseVisualStyleBackColor = true;
            this.btnSeis.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnSeis_MouseClick);
            // 
            // btnMultiplicar
            // 
            this.btnMultiplicar.ForeColor = System.Drawing.Color.Red;
            this.btnMultiplicar.Location = new System.Drawing.Point(187, 129);
            this.btnMultiplicar.Name = "btnMultiplicar";
            this.btnMultiplicar.Size = new System.Drawing.Size(36, 27);
            this.btnMultiplicar.TabIndex = 7;
            this.btnMultiplicar.Text = "*";
            this.btnMultiplicar.UseVisualStyleBackColor = true;
            // 
            // btnCalcularPorcentagem
            // 
            this.btnCalcularPorcentagem.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCalcularPorcentagem.Location = new System.Drawing.Point(229, 129);
            this.btnCalcularPorcentagem.Name = "btnCalcularPorcentagem";
            this.btnCalcularPorcentagem.Size = new System.Drawing.Size(36, 27);
            this.btnCalcularPorcentagem.TabIndex = 7;
            this.btnCalcularPorcentagem.Text = "%";
            this.btnCalcularPorcentagem.UseVisualStyleBackColor = true;
            // 
            // btnArmazenarNroMemoria
            // 
            this.btnArmazenarNroMemoria.ForeColor = System.Drawing.Color.Red;
            this.btnArmazenarNroMemoria.Location = new System.Drawing.Point(7, 162);
            this.btnArmazenarNroMemoria.Name = "btnArmazenarNroMemoria";
            this.btnArmazenarNroMemoria.Size = new System.Drawing.Size(36, 27);
            this.btnArmazenarNroMemoria.TabIndex = 7;
            this.btnArmazenarNroMemoria.Text = "MS";
            this.btnArmazenarNroMemoria.UseVisualStyleBackColor = true;
            // 
            // btnUm
            // 
            this.btnUm.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnUm.Location = new System.Drawing.Point(61, 163);
            this.btnUm.Name = "btnUm";
            this.btnUm.Size = new System.Drawing.Size(36, 27);
            this.btnUm.TabIndex = 7;
            this.btnUm.Text = "1";
            this.btnUm.UseVisualStyleBackColor = true;
            this.btnUm.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnUm_MouseClick);
            // 
            // btnDois
            // 
            this.btnDois.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDois.Location = new System.Drawing.Point(103, 163);
            this.btnDois.Name = "btnDois";
            this.btnDois.Size = new System.Drawing.Size(36, 27);
            this.btnDois.TabIndex = 7;
            this.btnDois.Text = "2";
            this.btnDois.UseVisualStyleBackColor = true;
            this.btnDois.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnDois_MouseClick);
            // 
            // btnTres
            // 
            this.btnTres.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnTres.Location = new System.Drawing.Point(145, 163);
            this.btnTres.Name = "btnTres";
            this.btnTres.Size = new System.Drawing.Size(36, 27);
            this.btnTres.TabIndex = 7;
            this.btnTres.Text = "3";
            this.btnTres.UseVisualStyleBackColor = true;
            this.btnTres.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnTres_MouseClick);
            // 
            // btnSubtrair
            // 
            this.btnSubtrair.ForeColor = System.Drawing.Color.Red;
            this.btnSubtrair.Location = new System.Drawing.Point(187, 162);
            this.btnSubtrair.Name = "btnSubtrair";
            this.btnSubtrair.Size = new System.Drawing.Size(36, 27);
            this.btnSubtrair.TabIndex = 7;
            this.btnSubtrair.Text = "-";
            this.btnSubtrair.UseVisualStyleBackColor = true;
            // 
            // btnCalcularReciprocaNro
            // 
            this.btnCalcularReciprocaNro.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCalcularReciprocaNro.Location = new System.Drawing.Point(229, 162);
            this.btnCalcularReciprocaNro.Name = "btnCalcularReciprocaNro";
            this.btnCalcularReciprocaNro.Size = new System.Drawing.Size(36, 27);
            this.btnCalcularReciprocaNro.TabIndex = 7;
            this.btnCalcularReciprocaNro.Text = "1/x";
            this.btnCalcularReciprocaNro.UseVisualStyleBackColor = true;
            // 
            // btnArmazenarNroDaMemoria
            // 
            this.btnArmazenarNroDaMemoria.ForeColor = System.Drawing.Color.Red;
            this.btnArmazenarNroDaMemoria.Location = new System.Drawing.Point(7, 195);
            this.btnArmazenarNroDaMemoria.Name = "btnArmazenarNroDaMemoria";
            this.btnArmazenarNroDaMemoria.Size = new System.Drawing.Size(36, 27);
            this.btnArmazenarNroDaMemoria.TabIndex = 7;
            this.btnArmazenarNroDaMemoria.Text = "M+";
            this.btnArmazenarNroDaMemoria.UseVisualStyleBackColor = true;
            // 
            // btnZero
            // 
            this.btnZero.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnZero.Location = new System.Drawing.Point(61, 196);
            this.btnZero.Name = "btnZero";
            this.btnZero.Size = new System.Drawing.Size(36, 27);
            this.btnZero.TabIndex = 7;
            this.btnZero.Text = "0";
            this.btnZero.UseVisualStyleBackColor = true;
            this.btnZero.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnZero_MouseClick);
            // 
            // btnAlterarSinal
            // 
            this.btnAlterarSinal.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAlterarSinal.Location = new System.Drawing.Point(103, 196);
            this.btnAlterarSinal.Name = "btnAlterarSinal";
            this.btnAlterarSinal.Size = new System.Drawing.Size(36, 27);
            this.btnAlterarSinal.TabIndex = 7;
            this.btnAlterarSinal.Text = "+/-";
            this.btnAlterarSinal.UseVisualStyleBackColor = true;
            // 
            // btnInserirVirgula
            // 
            this.btnInserirVirgula.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnInserirVirgula.Location = new System.Drawing.Point(145, 196);
            this.btnInserirVirgula.Name = "btnInserirVirgula";
            this.btnInserirVirgula.Size = new System.Drawing.Size(36, 27);
            this.btnInserirVirgula.TabIndex = 7;
            this.btnInserirVirgula.Text = ",";
            this.btnInserirVirgula.UseVisualStyleBackColor = true;
            // 
            // btnSomar
            // 
            this.btnSomar.ForeColor = System.Drawing.Color.Red;
            this.btnSomar.Location = new System.Drawing.Point(187, 195);
            this.btnSomar.Name = "btnSomar";
            this.btnSomar.Size = new System.Drawing.Size(36, 27);
            this.btnSomar.TabIndex = 7;
            this.btnSomar.Text = "+";
            this.btnSomar.UseVisualStyleBackColor = true;
            // 
            // btnCalcularResultado
            // 
            this.btnCalcularResultado.ForeColor = System.Drawing.Color.Red;
            this.btnCalcularResultado.Location = new System.Drawing.Point(229, 195);
            this.btnCalcularResultado.Name = "btnCalcularResultado";
            this.btnCalcularResultado.Size = new System.Drawing.Size(36, 27);
            this.btnCalcularResultado.TabIndex = 7;
            this.btnCalcularResultado.Text = "=";
            this.btnCalcularResultado.UseVisualStyleBackColor = true;
            // 
            // txtValor
            // 
            this.txtValor.Location = new System.Drawing.Point(61, 13);
            this.txtValor.MaxLength = 30;
            this.txtValor.Name = "txtValor";
            this.txtValor.ReadOnly = true;
            this.txtValor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtValor.Size = new System.Drawing.Size(204, 20);
            this.txtValor.TabIndex = 99;
            this.txtValor.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(270, 236);
            this.Controls.Add(this.txtValor);
            this.Controls.Add(this.btnCalcularResultado);
            this.Controls.Add(this.btnCalcularReciprocaNro);
            this.Controls.Add(this.btnCalcularPorcentagem);
            this.Controls.Add(this.btnCalcularRaiz);
            this.Controls.Add(this.btnSomar);
            this.Controls.Add(this.btnSubtrair);
            this.Controls.Add(this.btnMultiplicar);
            this.Controls.Add(this.btnDividir);
            this.Controls.Add(this.btnInserirVirgula);
            this.Controls.Add(this.btnTres);
            this.Controls.Add(this.btnSeis);
            this.Controls.Add(this.btnNove);
            this.Controls.Add(this.btnAlterarSinal);
            this.Controls.Add(this.btnDois);
            this.Controls.Add(this.btnCinco);
            this.Controls.Add(this.btnOito);
            this.Controls.Add(this.btnZero);
            this.Controls.Add(this.btnUm);
            this.Controls.Add(this.btnQuatro);
            this.Controls.Add(this.btnSete);
            this.Controls.Add(this.btnArmazenarNroDaMemoria);
            this.Controls.Add(this.btnArmazenarNroMemoria);
            this.Controls.Add(this.btnRecuperarNroMemoria);
            this.Controls.Add(this.btnLimparNroMemoria);
            this.Controls.Add(this.btnLimparCalculo);
            this.Controls.Add(this.btnLimparNumero);
            this.Controls.Add(this.btnBackspace);
            this.Controls.Add(this.lblResultado);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Calculadora 1.2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBackspace;
        private System.Windows.Forms.Button btnLimparNumero;
        private System.Windows.Forms.Button btnLimparCalculo;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Button btnLimparNroMemoria;
        private System.Windows.Forms.Button btnSete;
        private System.Windows.Forms.Button btnOito;
        private System.Windows.Forms.Button btnNove;
        private System.Windows.Forms.Button btnDividir;
        private System.Windows.Forms.Button btnCalcularRaiz;
        private System.Windows.Forms.Button btnRecuperarNroMemoria;
        private System.Windows.Forms.Button btnQuatro;
        private System.Windows.Forms.Button btnCinco;
        private System.Windows.Forms.Button btnSeis;
        private System.Windows.Forms.Button btnMultiplicar;
        private System.Windows.Forms.Button btnCalcularPorcentagem;
        private System.Windows.Forms.Button btnArmazenarNroMemoria;
        private System.Windows.Forms.Button btnUm;
        private System.Windows.Forms.Button btnDois;
        private System.Windows.Forms.Button btnTres;
        private System.Windows.Forms.Button btnSubtrair;
        private System.Windows.Forms.Button btnCalcularReciprocaNro;
        private System.Windows.Forms.Button btnArmazenarNroDaMemoria;
        private System.Windows.Forms.Button btnZero;
        private System.Windows.Forms.Button btnAlterarSinal;
        private System.Windows.Forms.Button btnInserirVirgula;
        private System.Windows.Forms.Button btnSomar;
        private System.Windows.Forms.Button btnCalcularResultado;
        private System.Windows.Forms.TextBox txtValor;
    }
}

