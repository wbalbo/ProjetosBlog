﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;

namespace ExemploImagemBinario
{
    public partial class _Default : System.Web.UI.Page
    {
        string fileType = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnEnviar_Click(object sender, EventArgs e)
        {
            if (fupImagem.HasFile)
            {
                VerificaImagem();
            }
        }

        private void SalvarImagem(bool bRetorno)
        {
            if (bRetorno)
            {	        
            	using (SqlConnection objConexao = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
                {
                    try
                    {
                        const string strInsert = "Insert Into Imagens (Nome, Extensao, Imagem) values (@Nome, @Extensao, @Imagem) Select Scope_Identity()";
                        SqlCommand cmd = new SqlCommand(strInsert, objConexao);

                        cmd.Parameters.AddWithValue("@Nome", txtNomeArquivo.Text.Trim());
                        cmd.Parameters.AddWithValue("@Extensao", fileType);

                        byte[] imagemBytes = new byte[fupImagem.PostedFile.InputStream.Length + 1];
                        fupImagem.PostedFile.InputStream.Read(imagemBytes, 0, imagemBytes.Length);

                        cmd.Parameters.AddWithValue("@Imagem", imagemBytes);

                        objConexao.Open();
                        int imagemId = Convert.ToInt32("0" + cmd.ExecuteScalar());
                        hypExibeImagem.NavigateUrl = "~/Imagem.aspx?ID=" + imagemId.ToString();
                        objConexao.Close();

                        lblmsg.Text = "Upload efetuado com Sucesso!";
                    }
                    catch (Exception ex)
                    {
                        lblmsg.Text = "Ocorreu o seguinte erro: " + ex.Message;
                    }
                } 
            }
            else
            {
                lblmsg.Text = "<br />Erro - tipo de arquivo inválido.<br />";          
            }
        }

        private void VerificaImagem()
        {
            bool bRetorno = false;

            string extension = Path.GetExtension(fupImagem.PostedFile.FileName).ToLower();

            switch (extension)
            {
                case ".gif":
                    fileType = "gif";
                    bRetorno = true;
                    break;
                case ".jpg":
                case ".jpeg":
                    fileType = "jpeg";
                    bRetorno = true;
                    break;
                default:
                    lblmsg.Text = "<br />Erro - tipo de arquivo inválido.<br />";
                    bRetorno = false;
                    break;
            }

            SalvarImagem(bRetorno);
        }
    }
}
