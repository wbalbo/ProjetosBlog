﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace ExemploImagemBinario
{
    public partial class Imagem : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString.HasKeys())
            {
                int IdImagem = Convert.ToInt32(Request.QueryString["ID"].ToString());
                CarregarImagem(IdImagem);
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }

        private void CarregarImagem(int IdImagem)
        {
            using (SqlConnection objConexao = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
            {
                try
                {
                    const string strSelect = "Select Extensao, Imagem From Imagens Where IdImagem = @IdImagem";
                    SqlCommand cmd = new SqlCommand(strSelect, objConexao);

                    cmd.Parameters.AddWithValue("@IdImagem", IdImagem);

                    objConexao.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while(reader.Read())
                    {
                        Response.ContentType = reader["Extensao"].ToString();
                        Response.BinaryWrite((byte[])reader["Imagem"]);
                    }

                    reader.Close();
                    objConexao.Close();
                }
                catch (Exception ex)
                {
                    Response.Write("Ocorreu o seguinte erro: " + ex.Message);
                }
            }
        }
    }
}
