﻿namespace ExemploFileSystemWatcher
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPasta = new System.Windows.Forms.Label();
            this.txtPasta = new System.Windows.Forms.TextBox();
            this.txtFiltro = new System.Windows.Forms.TextBox();
            this.lblFiltro = new System.Windows.Forms.Label();
            this.lblNotificacoes = new System.Windows.Forms.Label();
            this.txtNotificacoes = new System.Windows.Forms.TextBox();
            this.cboHabilitaEventos = new System.Windows.Forms.CheckBox();
            this.cboIncluirSubDiretorios = new System.Windows.Forms.CheckBox();
            this.gboFSW = new System.Windows.Forms.GroupBox();
            this.btnDeletaArquivo = new System.Windows.Forms.Button();
            this.btnCriaDiretorio = new System.Windows.Forms.Button();
            this.btnCriaArquivo = new System.Windows.Forms.Button();
            this.txtArquivoDiretorio = new System.Windows.Forms.TextBox();
            this.lblArquivoDiretorio = new System.Windows.Forms.Label();
            this.fsw = new System.IO.FileSystemWatcher();
            this.gboFSW.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fsw)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPasta
            // 
            this.lblPasta.AutoSize = true;
            this.lblPasta.Location = new System.Drawing.Point(14, 20);
            this.lblPasta.Name = "lblPasta";
            this.lblPasta.Size = new System.Drawing.Size(34, 13);
            this.lblPasta.TabIndex = 0;
            this.lblPasta.Text = "Pasta";
            // 
            // txtPasta
            // 
            this.txtPasta.Location = new System.Drawing.Point(74, 20);
            this.txtPasta.Name = "txtPasta";
            this.txtPasta.Size = new System.Drawing.Size(166, 20);
            this.txtPasta.TabIndex = 1;
            this.txtPasta.Text = "C:\\exemploFSW";
            // 
            // txtFiltro
            // 
            this.txtFiltro.Location = new System.Drawing.Point(74, 54);
            this.txtFiltro.Name = "txtFiltro";
            this.txtFiltro.Size = new System.Drawing.Size(100, 20);
            this.txtFiltro.TabIndex = 3;
            this.txtFiltro.Text = "*.*";
            // 
            // lblFiltro
            // 
            this.lblFiltro.AutoSize = true;
            this.lblFiltro.Location = new System.Drawing.Point(13, 54);
            this.lblFiltro.Name = "lblFiltro";
            this.lblFiltro.Size = new System.Drawing.Size(29, 13);
            this.lblFiltro.TabIndex = 2;
            this.lblFiltro.Text = "Filtro";
            // 
            // lblNotificacoes
            // 
            this.lblNotificacoes.AutoSize = true;
            this.lblNotificacoes.Location = new System.Drawing.Point(13, 83);
            this.lblNotificacoes.Name = "lblNotificacoes";
            this.lblNotificacoes.Size = new System.Drawing.Size(66, 13);
            this.lblNotificacoes.TabIndex = 2;
            this.lblNotificacoes.Text = "Notificações";
            // 
            // txtNotificacoes
            // 
            this.txtNotificacoes.Location = new System.Drawing.Point(16, 99);
            this.txtNotificacoes.Multiline = true;
            this.txtNotificacoes.Name = "txtNotificacoes";
            this.txtNotificacoes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNotificacoes.Size = new System.Drawing.Size(409, 88);
            this.txtNotificacoes.TabIndex = 3;
            // 
            // cboHabilitaEventos
            // 
            this.cboHabilitaEventos.AutoSize = true;
            this.cboHabilitaEventos.Checked = true;
            this.cboHabilitaEventos.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cboHabilitaEventos.Location = new System.Drawing.Point(16, 202);
            this.cboHabilitaEventos.Name = "cboHabilitaEventos";
            this.cboHabilitaEventos.Size = new System.Drawing.Size(103, 17);
            this.cboHabilitaEventos.TabIndex = 4;
            this.cboHabilitaEventos.Text = "Habilita Eventos";
            this.cboHabilitaEventos.UseVisualStyleBackColor = true;
            // 
            // cboIncluirSubDiretorios
            // 
            this.cboIncluirSubDiretorios.AutoSize = true;
            this.cboIncluirSubDiretorios.Checked = true;
            this.cboIncluirSubDiretorios.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cboIncluirSubDiretorios.Location = new System.Drawing.Point(138, 202);
            this.cboIncluirSubDiretorios.Name = "cboIncluirSubDiretorios";
            this.cboIncluirSubDiretorios.Size = new System.Drawing.Size(118, 17);
            this.cboIncluirSubDiretorios.TabIndex = 4;
            this.cboIncluirSubDiretorios.Text = "Incluir Subdiretórios";
            this.cboIncluirSubDiretorios.UseVisualStyleBackColor = true;
            // 
            // gboFSW
            // 
            this.gboFSW.Controls.Add(this.btnDeletaArquivo);
            this.gboFSW.Controls.Add(this.btnCriaDiretorio);
            this.gboFSW.Controls.Add(this.btnCriaArquivo);
            this.gboFSW.Controls.Add(this.txtArquivoDiretorio);
            this.gboFSW.Controls.Add(this.lblArquivoDiretorio);
            this.gboFSW.Location = new System.Drawing.Point(452, 13);
            this.gboFSW.Name = "gboFSW";
            this.gboFSW.Size = new System.Drawing.Size(151, 215);
            this.gboFSW.TabIndex = 5;
            this.gboFSW.TabStop = false;
            this.gboFSW.Text = "Teste com FSW";
            // 
            // btnDeletaArquivo
            // 
            this.btnDeletaArquivo.Location = new System.Drawing.Point(9, 177);
            this.btnDeletaArquivo.Name = "btnDeletaArquivo";
            this.btnDeletaArquivo.Size = new System.Drawing.Size(136, 23);
            this.btnDeletaArquivo.TabIndex = 8;
            this.btnDeletaArquivo.Text = "Deleta Arquivo";
            this.btnDeletaArquivo.UseVisualStyleBackColor = true;
            this.btnDeletaArquivo.Click += new System.EventHandler(this.btnDeletaArquivo_Click);
            // 
            // btnCriaDiretorio
            // 
            this.btnCriaDiretorio.Location = new System.Drawing.Point(9, 136);
            this.btnCriaDiretorio.Name = "btnCriaDiretorio";
            this.btnCriaDiretorio.Size = new System.Drawing.Size(136, 23);
            this.btnCriaDiretorio.TabIndex = 8;
            this.btnCriaDiretorio.Text = "Cria Diretório";
            this.btnCriaDiretorio.UseVisualStyleBackColor = true;
            this.btnCriaDiretorio.Click += new System.EventHandler(this.btnCriaDiretorio_Click);
            // 
            // btnCriaArquivo
            // 
            this.btnCriaArquivo.Location = new System.Drawing.Point(9, 98);
            this.btnCriaArquivo.Name = "btnCriaArquivo";
            this.btnCriaArquivo.Size = new System.Drawing.Size(136, 23);
            this.btnCriaArquivo.TabIndex = 8;
            this.btnCriaArquivo.Text = "Cria Arquivo";
            this.btnCriaArquivo.UseVisualStyleBackColor = true;
            this.btnCriaArquivo.Click += new System.EventHandler(this.btnCriaArquivo_Click);
            // 
            // txtArquivoDiretorio
            // 
            this.txtArquivoDiretorio.Location = new System.Drawing.Point(9, 63);
            this.txtArquivoDiretorio.Name = "txtArquivoDiretorio";
            this.txtArquivoDiretorio.Size = new System.Drawing.Size(136, 20);
            this.txtArquivoDiretorio.TabIndex = 7;
            // 
            // lblArquivoDiretorio
            // 
            this.lblArquivoDiretorio.AutoSize = true;
            this.lblArquivoDiretorio.Location = new System.Drawing.Point(6, 34);
            this.lblArquivoDiretorio.Name = "lblArquivoDiretorio";
            this.lblArquivoDiretorio.Size = new System.Drawing.Size(93, 13);
            this.lblArquivoDiretorio.TabIndex = 6;
            this.lblArquivoDiretorio.Text = "Arquivo / Diretório";
            // 
            // fsw
            // 
            this.fsw.EnableRaisingEvents = true;
            this.fsw.SynchronizingObject = this;
            this.fsw.Renamed += new System.IO.RenamedEventHandler(this.fsw_Renamed);
            this.fsw.Deleted += new System.IO.FileSystemEventHandler(this.fsw_Deleted);
            this.fsw.Created += new System.IO.FileSystemEventHandler(this.fsw_Created);
            this.fsw.Changed += new System.IO.FileSystemEventHandler(this.fsw_Changed);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(623, 240);
            this.Controls.Add(this.gboFSW);
            this.Controls.Add(this.cboIncluirSubDiretorios);
            this.Controls.Add(this.cboHabilitaEventos);
            this.Controls.Add(this.txtNotificacoes);
            this.Controls.Add(this.txtFiltro);
            this.Controls.Add(this.lblNotificacoes);
            this.Controls.Add(this.lblFiltro);
            this.Controls.Add(this.txtPasta);
            this.Controls.Add(this.lblPasta);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exemplo com FileSystemWatcher";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gboFSW.ResumeLayout(false);
            this.gboFSW.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fsw)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtFiltro;
        private System.Windows.Forms.Label lblFiltro;
        private System.Windows.Forms.TextBox txtPasta;
        private System.Windows.Forms.Label lblPasta;
        private System.Windows.Forms.Label lblNotificacoes;
        private System.Windows.Forms.GroupBox gboFSW;
        private System.Windows.Forms.CheckBox cboIncluirSubDiretorios;
        private System.Windows.Forms.CheckBox cboHabilitaEventos;
        private System.Windows.Forms.TextBox txtNotificacoes;
        private System.Windows.Forms.Button btnDeletaArquivo;
        private System.Windows.Forms.Button btnCriaDiretorio;
        private System.Windows.Forms.Button btnCriaArquivo;
        private System.Windows.Forms.TextBox txtArquivoDiretorio;
        private System.Windows.Forms.Label lblArquivoDiretorio;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
    }
}

