﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GeradorDeNumerosRandomicos
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        private static Random random;
        private static object syncObj = new object();
        private static int GerarNumeroRandomico(int valorMinimo, int valorMaximo)
        {
            lock (syncObj)
            {
                if (random == null)
                    random = new Random();
                return random.Next(valorMinimo, valorMaximo);
            }
        }

        private void btnGerar_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtValorMinimo.Text) && !String.IsNullOrEmpty(txtValorMaximo.Text))
            {
                int numeroGerado = GerarNumeroRandomico(Convert.ToInt32(txtValorMinimo.Text), Convert.ToInt32(txtValorMaximo.Text));
                lblResultado.Text = numeroGerado.ToString();
            }
            else
                MessageBox.Show("Preencha os campos com números de 1 a 100!");
        }

        private void txtValorMinimo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar < 48 || e.KeyChar > 57;
        }

        private void txtValorMaximo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar < 48 || e.KeyChar > 57;
        }
    }
}
