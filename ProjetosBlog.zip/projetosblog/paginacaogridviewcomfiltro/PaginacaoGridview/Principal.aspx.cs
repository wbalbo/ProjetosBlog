﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PaginacaoGridview
{
    public partial class Principal : System.Web.UI.Page
    {
        protected string conexaoSQL = ConfigurationManager.ConnectionStrings["Northwind"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                this.ColocarListaNaViewState();
        }

        [Serializable]
        private class Produtos
        {
            public int ProductID { get; set; }
            public string ProductName { get; set; }
            public int UnitsInStock { get; set; }
        }

        private List<Produtos> CarregarProdutos()
        {
            List<Produtos> listaRetorno = new List<Produtos>();
            using (SqlConnection objConexao = new SqlConnection(conexaoSQL))
            {
                string instrucaoSql = "SELECT ProductID, ProductName, UnitsInStock FROM PRODUCTS";
                using (SqlCommand objCommand = new SqlCommand(instrucaoSql, objConexao))
                {
                    try
                    {
                        objConexao.Open();
                        SqlDataReader reader = objCommand.ExecuteReader();
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                Produtos modelo = new Produtos();
                                modelo.ProductID = Convert.ToInt32(reader["ProductID"].ToString());
                                modelo.ProductName = reader["ProductName"].ToString();
                                modelo.UnitsInStock = Convert.ToInt32(reader["UnitsInStock"].ToString());
                                listaRetorno.Add(modelo);
                            }

                        }
                    }
                    catch
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Aviso", "alert('Erro no método!');", true);
                    }
                    finally
                    {
                        objConexao.Close();
                    }
                }
            }
            return listaRetorno;
        }

        private void ColocarListaNaViewState()
        {
            var listaProdutos = this.CarregarProdutos();
            vwListaProdutos = listaProdutos;
            this.PopularGrid(string.Empty);
        }

        private void PopularGrid(string filtro, bool temFiltro = false)
        {
            var cultura = new CultureInfo("en-US");
            Stopwatch contador = new Stopwatch();
            long milissegundosContains = 0;
            long milissegundosIndexOf = 0;

            contador.Start();
            grdProdutos.DataSource = temFiltro ? vwListaProdutos.FindAll(l => l.ProductName.Contains(filtro)) : vwListaProdutos;
            contador.Stop();
            milissegundosContains = contador.ElapsedMilliseconds;

            contador.Reset();

            contador.Start();
            grdProdutos.DataSource = temFiltro ?
                vwListaProdutos.FindAll(l => cultura.CompareInfo.IndexOf(l.ProductName, filtro, CompareOptions.IgnoreCase) >= 0) : vwListaProdutos;
            contador.Stop();
            milissegundosIndexOf = contador.ElapsedMilliseconds;

            string total = milissegundosContains.ToString() + "|" + milissegundosIndexOf.ToString();

            grdProdutos.DataBind();
        }

        protected void btnFiltrar_Click(object sender, EventArgs e)
        {
            this.PopularGrid(txtFiltro.Text, !string.IsNullOrEmpty(txtFiltro.Text));
        }

        protected void grdProdutos_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdProdutos.PageIndex = e.NewPageIndex;
            this.PopularGrid(txtFiltro.Text, !string.IsNullOrEmpty(txtFiltro.Text));
        }

        protected void grdProdutos_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        private List<Produtos> vwListaProdutos
        {
            get
            {
                List<Produtos> listaProdutos = new List<Produtos>();
                if (ViewState["vwListaProdutos"] != null)
                    listaProdutos = (List<Produtos>)ViewState["vwListaProdutos"];
                return listaProdutos;
            }
            set
            {
                ViewState["vwListaProdutos"] = value;
            }
        }
    }
}