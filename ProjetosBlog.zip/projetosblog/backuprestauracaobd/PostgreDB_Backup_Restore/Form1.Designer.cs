﻿namespace PostgreDB_Backup_Restore
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.butSelectLoc = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.butBackupFilePath = new System.Windows.Forms.Button();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.GetDB = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnCheckPostgres = new System.Windows.Forms.Button();
            this.grpboxConfig = new System.Windows.Forms.GroupBox();
            this.txtCriarBanco = new System.Windows.Forms.TextBox();
            this.txtSnh = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtServidor = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.btnResetarConfig = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpboxConfig.SuspendLayout();
            this.panel2.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Location = new System.Drawing.Point(10, 241);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(406, 120);
            this.panel1.TabIndex = 7;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.butSelectLoc);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.butBackupFilePath);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(5, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(398, 109);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Operações";
            // 
            // butSelectLoc
            // 
            this.butSelectLoc.BackColor = System.Drawing.SystemColors.Control;
            this.butSelectLoc.Enabled = false;
            this.butSelectLoc.ForeColor = System.Drawing.Color.Black;
            this.butSelectLoc.Location = new System.Drawing.Point(314, 19);
            this.butSelectLoc.Name = "butSelectLoc";
            this.butSelectLoc.Size = new System.Drawing.Size(79, 37);
            this.butSelectLoc.TabIndex = 2;
            this.butSelectLoc.Text = "Backup";
            this.butSelectLoc.UseVisualStyleBackColor = true;
            this.butSelectLoc.Click += new System.EventHandler(this.butSelectLoc_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(6, 19);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(303, 80);
            this.textBox1.TabIndex = 3;
            // 
            // butBackupFilePath
            // 
            this.butBackupFilePath.BackColor = System.Drawing.SystemColors.Control;
            this.butBackupFilePath.Location = new System.Drawing.Point(315, 61);
            this.butBackupFilePath.Name = "butBackupFilePath";
            this.butBackupFilePath.Size = new System.Drawing.Size(78, 37);
            this.butBackupFilePath.TabIndex = 0;
            this.butBackupFilePath.Text = "Restauração";
            this.butBackupFilePath.UseVisualStyleBackColor = true;
            this.butBackupFilePath.Click += new System.EventHandler(this.butBackupFilePath_Click);
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(319, 53);
            this.txtPort.MaxLength = 5;
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(64, 20);
            this.txtPort.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(274, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Porta:";
            // 
            // GetDB
            // 
            this.GetDB.BackColor = System.Drawing.SystemColors.Control;
            this.GetDB.Location = new System.Drawing.Point(9, 81);
            this.GetDB.Name = "GetDB";
            this.GetDB.Size = new System.Drawing.Size(71, 23);
            this.GetDB.TabIndex = 8;
            this.GetDB.Text = "Listar BD";
            this.GetDB.UseVisualStyleBackColor = true;
            this.GetDB.Click += new System.EventHandler(this.GetDB_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(86, 82);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(296, 21);
            this.comboBox1.TabIndex = 7;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // btnCheckPostgres
            // 
            this.btnCheckPostgres.BackColor = System.Drawing.SystemColors.Control;
            this.btnCheckPostgres.Location = new System.Drawing.Point(18, 20);
            this.btnCheckPostgres.Name = "btnCheckPostgres";
            this.btnCheckPostgres.Size = new System.Drawing.Size(258, 47);
            this.btnCheckPostgres.TabIndex = 8;
            this.btnCheckPostgres.Text = "Checar a Instação do Postgres";
            this.btnCheckPostgres.UseVisualStyleBackColor = true;
            this.btnCheckPostgres.Click += new System.EventHandler(this.btnCheckPostgres_Click);
            // 
            // grpboxConfig
            // 
            this.grpboxConfig.Controls.Add(this.txtCriarBanco);
            this.grpboxConfig.Controls.Add(this.txtSnh);
            this.grpboxConfig.Controls.Add(this.label4);
            this.grpboxConfig.Controls.Add(this.txtUsuario);
            this.grpboxConfig.Controls.Add(this.label3);
            this.grpboxConfig.Controls.Add(this.button1);
            this.grpboxConfig.Controls.Add(this.txtPort);
            this.grpboxConfig.Controls.Add(this.label2);
            this.grpboxConfig.Controls.Add(this.comboBox1);
            this.grpboxConfig.Controls.Add(this.GetDB);
            this.grpboxConfig.Controls.Add(this.label1);
            this.grpboxConfig.Controls.Add(this.txtServidor);
            this.grpboxConfig.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpboxConfig.Location = new System.Drawing.Point(8, 3);
            this.grpboxConfig.Name = "grpboxConfig";
            this.grpboxConfig.Size = new System.Drawing.Size(390, 151);
            this.grpboxConfig.TabIndex = 10;
            this.grpboxConfig.TabStop = false;
            this.grpboxConfig.Text = "Configurações";
            // 
            // txtCriarBanco
            // 
            this.txtCriarBanco.Location = new System.Drawing.Point(86, 111);
            this.txtCriarBanco.MaxLength = 40;
            this.txtCriarBanco.Name = "txtCriarBanco";
            this.txtCriarBanco.Size = new System.Drawing.Size(296, 20);
            this.txtCriarBanco.TabIndex = 18;
            // 
            // txtSnh
            // 
            this.txtSnh.Location = new System.Drawing.Point(318, 25);
            this.txtSnh.MaxLength = 20;
            this.txtSnh.Name = "txtSnh";
            this.txtSnh.Size = new System.Drawing.Size(65, 20);
            this.txtSnh.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(273, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Senha:";
            // 
            // txtUsuario
            // 
            this.txtUsuario.Location = new System.Drawing.Point(85, 24);
            this.txtUsuario.MaxLength = 30;
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(185, 20);
            this.txtUsuario.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Usuário:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(9, 110);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(71, 23);
            this.button1.TabIndex = 13;
            this.button1.Text = "Criar Banco";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Servidor:";
            // 
            // txtServidor
            // 
            this.txtServidor.Location = new System.Drawing.Point(86, 53);
            this.txtServidor.MaxLength = 50;
            this.txtServidor.Name = "txtServidor";
            this.txtServidor.Size = new System.Drawing.Size(185, 20);
            this.txtServidor.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.grpboxConfig);
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(10, 82);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(406, 161);
            this.panel2.TabIndex = 11;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 371);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(425, 22);
            this.statusStrip1.TabIndex = 12;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // btnResetarConfig
            // 
            this.btnResetarConfig.Location = new System.Drawing.Point(282, 20);
            this.btnResetarConfig.Name = "btnResetarConfig";
            this.btnResetarConfig.Size = new System.Drawing.Size(131, 47);
            this.btnResetarConfig.TabIndex = 13;
            this.btnResetarConfig.Text = "Reiniciar Configuração";
            this.btnResetarConfig.UseVisualStyleBackColor = true;
            this.btnResetarConfig.Click += new System.EventHandler(this.btnResetarConfig_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(425, 393);
            this.Controls.Add(this.btnResetarConfig);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnCheckPostgres);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Backup e Restauração de Banco de Dados";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpboxConfig.ResumeLayout(false);
            this.grpboxConfig.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button butBackupFilePath;
        private System.Windows.Forms.Button butSelectLoc;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button GetDB;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnCheckPostgres;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpboxConfig;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtServidor;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtSnh;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.TextBox txtCriarBanco;
        private System.Windows.Forms.Button btnResetarConfig;

    }
}

