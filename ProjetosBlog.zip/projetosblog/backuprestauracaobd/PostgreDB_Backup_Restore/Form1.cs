﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Npgsql;
using System.IO;
using System.Diagnostics;
using System.Threading;
using System.ServiceProcess;

namespace PostgreDB_Backup_Restore
{
    public partial class Form1 : Form
    {
        public NpgsqlConnection m_NpgsqlConnection;
        string strConnection = "";
        string strServer = string.Empty;
        string strPort = string.Empty;
        string strDatabaseName = string.Empty;
        StringBuilder sbPG_dumpPath = new StringBuilder();
        String strPG_dumpPath = String.Empty;
        string strInstallLocation = string.Empty;

        public Form1()
        {
            try
            {
                InitializeComponent();

                CarregaConfiguracao();

                strConnection = "Server=" + this.txtServidor.Text + ";Port=" + this.txtPort.Text + ";Database=postgres;Userid=postgres;Password=" + this.txtSnh.Text;

                int start = strConnection.IndexOf("Server");
                start = start + ("Server").Length + 1;
                int end = strConnection.IndexOf(";", start);
                end = end - start;
                strServer = strConnection.Substring(start, end);

                start = strConnection.IndexOf("Port");
                start = start + ("Port").Length + 1;
                end = strConnection.IndexOf(";", start);
                end = end - start;
                strPort = strConnection.Substring(start, end);

                UpdateStatusBar("");

            }
            catch (Exception ex)
            { }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Enabled = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        }

        private void btnCheckPostgres_Click(object sender, EventArgs e)
        {
            try
            {
                string msg = string.Empty;

                if (sbPG_dumpPath.Length == 0)
                {
                    //string strProcess = System.IO.Path.GetDirectoryName(Application.StartupPath) + "\\Progress.exe";
                    /** Não precisa usar o codigo abaixo, caso tenha interesse descomente
                     * Cria uma pasta com o nome PostgreDB_Backup_Restore e adicione o arquivo Progress.exe
                     * Conforme caminho abaixo
                     * 
                    string strProcess = @"C:\PostgreDB_Backup_Restore\Progress.exe";
                    Process objProcess = null;
                    if (System.IO.File.Exists(strProcess))
                    {
                        objProcess = new Process();
                        objProcess = Process.Start(strProcess);
                    }
                    else
                    {
                        MessageBox.Show("Arquivo Progress.exe não encontrado.");
                    }
                    */

                    bool bPostgresService = false;
                    ServiceController[] services = ServiceController.GetServices();
                    // try to find service name
                    foreach (ServiceController service in services)
                    {
                        if (service.ServiceName.Contains("postgre") == true)
                        {
                            bPostgresService = true;
                            break;
                        }
                    }
                    if (bPostgresService == true)
                    {
                        PG_DumpExePath();
                        //objProcess.Kill();
                        if (sbPG_dumpPath.Length != 0)
                        {
                            this.toolStripStatusLabel1.Text = "Local de Instalação é " + strInstallLocation;
                            statusStrip1.Enabled = true;
                            btnCheckPostgres.BackColor = Color.Green;

                            GetBancoDados();
                            panel1.Enabled = true;
                            AtivarTodosComponentes();
                        }
                    }
                    else
                    {
                        //objProcess.Kill();
                        msg = "Banco de Dados Postgres Não Está Instalado";
                        UpdateStatusBar(msg);
                      }
                }
            }
            catch (Exception ex)
            { }


        }

        private void PG_DumpExePath()
        {
            try
            {
                // Do not change lines / spaces b/w words.
                if (sbPG_dumpPath.Length == 0)
                {
                    //string strPG_dumpPath = string.Empty;
                    if (strPG_dumpPath == string.Empty)
                    {
                        strPG_dumpPath = LookForFile("pg_dump.exe");
                        if (strPG_dumpPath == string.Empty)
                        {
                            UpdateStatusBar("Postgres Não Está Instalado");
                            MessageBox.Show("Postgres Não Está Instalado");
                        }
                    }

                    int a = strPG_dumpPath.IndexOf(":\\", 0);
                    a = a + 2;
                    string strSub = strPG_dumpPath.Substring(0, (a - 2));
                    strPG_dumpPath = strPG_dumpPath.Substring(a, (strPG_dumpPath.Length - a));

                    StringBuilder sbSB1 = new StringBuilder(strPG_dumpPath);
                    sbSB1.Replace("\\", "\r\n\r\ncd ");

                    StringBuilder sbSB2 = new StringBuilder("cd /D ");
                    sbSB2.Append(strSub);
                    sbSB2.Append(":\\");

                    sbSB1 = sbSB2.Append(sbSB1);
                    sbSB1 = sbSB1.Remove((sbSB1.Length - 3), 3);
                    sbPG_dumpPath = sbSB1;
                    strPG_dumpPath = sbSB1.ToString();
                }
            }
            catch (Exception ex)
            { }
        }

        private string LookForFile(string strFileName)
        {
            string strPG_dumpPath = string.Empty;
            try
            {
                DriveInfo[] drives = DriveInfo.GetDrives();

                foreach (DriveInfo drive in drives)
                {
                    strPG_dumpPath = performFileSearchTask(drive.Name, strFileName);
                    if (strPG_dumpPath.Length != 0)
                        break;
                }

            }
            catch (Exception ex)
            { }
            return strPG_dumpPath;
        }

        private string performFileSearchTask(string dirName, string strfileName)
        {
            try
            {
                if (strPG_dumpPath.Length == 0)
                {
                    try
                    {

                        foreach (string ddir in Directory.GetDirectories(dirName))
                        {
                            System.Security.Permissions.FileIOPermission ReadPermission =
                                new System.Security.Permissions.FileIOPermission(System.Security.Permissions.FileIOPermissionAccess.Write, ddir);
                            if (System.Security.SecurityManager.IsGranted(ReadPermission))
                            {
                                try
                                {
                                    foreach (string dfile in Directory.GetFiles(ddir, strfileName))
                                    {
                                        strPG_dumpPath = ddir + "\\";
                                        if (strPG_dumpPath.Length > 0)
                                        {
                                            strInstallLocation = strPG_dumpPath;
                                            break;
                                        }
                                    }
                                    if (strPG_dumpPath.Length == 0)
                                        performFileSearchTask(ddir, strfileName);
                                }
                                catch (Exception ex)
                                { }
                            }
                            if (strPG_dumpPath != string.Empty)
                                break;
                        }
                    }
                    catch (Exception ex)
                    { }

                }

            }
            catch (Exception ex)
            { }
            return strPG_dumpPath;
        }

        private void GetDB_Click(object sender, EventArgs e)
        {
            GetBancoDados();
            this.txtCriarBanco.Text = string.Empty;
        }

        public void GetBancoDados()
        {
            try
            {
                comboBox1.Items.Clear();
                comboBox1.Text = string.Empty;
                DataSet dsDB = new DataSet();
                strPort = txtPort.Text;

                strConnection = "Server=" + strServer + ";Port=" + strPort + ";Database=postgres;Userid=postgres;Password=" + this.txtSnh.Text + ";";

                dsDB = GetData("SELECT datname FROM pg_database WHERE datistemplate IS FALSE AND datallowconn IS TRUE AND datname!='postgres';");

                if (dsDB != null)
                {
                    Int32 rows = Convert.ToInt32(dsDB.Tables[0].Rows.Count);

                    if (dsDB.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < dsDB.Tables[0].Rows.Count; i++)
                        {
                            comboBox1.Items.Add(dsDB.Tables[0].Rows[i][0].ToString());
                        }
                        comboBox1.SelectedIndex = 0;
                        strDatabaseName = comboBox1.Text;
                    }
                    else
                    {
                        UpdateStatusBar("Banco de Dados Não Existe.");
                    }
                }
                else { UpdateStatusBar("Verifique Se o Postgres Foi Inicializado."); }

            }
            catch (NpgsqlException ex)
            {
                UpdateStatusBar(ex.Message.ToString());
            }
        }

        public void AtivarTodosComponentes()
        {
            this.textBox1.Enabled = true;
            this.butSelectLoc.Enabled = true;
            this.butBackupFilePath.Enabled = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                strDatabaseName = comboBox1.Text;
            }
            catch (Exception ex)
            { }
        }

        private void butSelectLoc_Click(object sender, EventArgs e)
        {
            //Path to be saved for the backup file
            try
            {
                textBox1.Text = string.Empty;
                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                saveFileDialog1.Title = "Localização Do Arquivo de Backup";
                saveFileDialog1.Filter = "Backup File|*.backup";
                saveFileDialog1.FilterIndex = 0;
                saveFileDialog1.RestoreDirectory = true;
                string fileName = strDatabaseName + "_Backup" + "_" + System.DateTime.Now.ToString("ddMMyyyy_HHmm");
                saveFileDialog1.FileName = fileName;

                if (strDatabaseName== string.Empty)
                {
                    UpdateStatusBar("Favor Selecionar o Banco de Dados.");
                    return;
                }

                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    textBox1.Text = saveFileDialog1.FileName;
                    ExecutarBackup(textBox1.Text);
                }
                else
                    UpdateStatusBar("Favor Selecione o Caminho Para Salvar o Backup.");
            }
            catch (Exception ex)
            {
            }
        }

        public void ExecutarBackup(string _caminho)
        {
            try
            {
                if (_caminho == "-------")
                {
                    MessageBox.Show("Selecione o Local Para Salvar");
                    UpdateStatusBar("Selecione o Local Para Salvar");
                    return;
                }
                StreamWriter sw = new StreamWriter("DBBackup.bat");
                // Não mude linhas / espaços b / w palavras.
                StringBuilder strSB = new StringBuilder(strPG_dumpPath);

                string msg = string.Empty;

                if (strSB.Length != 0)
                {
                    UpdateStatusBar("Favor Informe a Senha Do Banco de Dados.");

                    strSB.Append("pg_dump.exe --host " + strServer + " --port " + strPort + " --username postgres --format custom --blobs --verbose --file ");
                    strSB.Append("\"" + textBox1.Text + "\"");
                    strSB.Append(" \"" + strDatabaseName + "\r\n\r\n");
                    sw.WriteLine(strSB);
                    sw.Dispose();
                    sw.Close();
                    Process processDB = Process.Start("DBBackup.bat");
                    do
                    {//dont perform anything
                    }
                    while (!processDB.HasExited);
                    {
                        GetBancoDados();
                        msg = "Backup Realizado Com Sucesso.";
                        UpdateStatusBar(msg);
                       
                    }
                }
                else
                {
                    msg = "Por favor, forneça o local para tirar cópia de segurança!";
                    UpdateStatusBar(msg);
                }
            }
            catch (Exception ex)
            { }
        }

        public void UpdateStatusBar(string status)
        {
            this.toolStripStatusLabel1.Text = status;
        }

        private void butBackupFilePath_Click(object sender, EventArgs e)
        {
            try
            {

                textBox1.Text = string.Empty;
                OpenFileDialog objOpenFileDialog = new OpenFileDialog();
                objOpenFileDialog.Title = "Selecione o Arquivo de Backup";
                objOpenFileDialog.Filter = "backup files|*.backup";
                objOpenFileDialog.RestoreDirectory = true;
                if (objOpenFileDialog.ShowDialog() == DialogResult.OK)
                {
                    textBox1.Text = objOpenFileDialog.FileName;
                    ExecutarRestoreBD(textBox1.Text);
                }
                else
                    UpdateStatusBar("Favor Selecione o Arquivo de Backup Para Restauração do Banco de Dados.");
            }
            catch (Exception ex)
            {

            }
        }

        public void CriarBanco(string _BancoDados)
        {
            try
            {
                UpdateStatusBar("");

                string DBlist = "SELECT datname FROM pg_database WHERE datistemplate IS FALSE AND datallowconn IS TRUE AND datname!='postgres';";
                DataSet ds = new DataSet();
                ds = GetData(DBlist);
                bool databaseExists = false;
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (ds.Tables[0].Rows[i][0].ToString() == _BancoDados)
                    {
                        databaseExists = true;
                        break;
                    }
                }

                if (databaseExists)
                {
                    UpdateStatusBar("Banco De Dados Já Existe.");
                }
                else
                {
                    string str = "create database \"" + _BancoDados + "\" ";
                    ExecuteQuery(str);
                    Thread.Sleep(1000);
                    UpdateStatusBar("Banco De Dados Criado Com Sucesso.");
                }

                //return false;
            }
            catch (Exception ex)
            {
            }

        }

        public void ExecutarRestoreBD(string _caminho)
        {
            try
            {

                if (_caminho == string.Empty)
                {
                    MessageBox.Show("Selecione o Arquivo de Backup");
                    UpdateStatusBar("Selecione o Arquivo de Backup");
                    return;
                }

                string msg = string.Empty;

                if (strDatabaseName != "")
                {
                    if (textBox1.Text != "")
                    {
                        StreamWriter sw = new StreamWriter("DBRestore.bat");
                        // Não mude linhas / espaços b / w palavras.
                        StringBuilder strSB = new StringBuilder(strPG_dumpPath);

                        if (strSB.Length != 0)
                        {
                            UpdateStatusBar("Favor Informe a Senha Do Banco de Dados.");

                            checkDBExists(strDatabaseName);
                            strSB.Append("pg_restore.exe --host " + strServer + " --port " + strPort + " --username postgres --dbname");
                            strSB.Append(" \"" + strDatabaseName + "\"");
                            strSB.Append(" --verbose ");
                            strSB.Append("\"" + textBox1.Text + "\"");
                            sw.WriteLine(strSB);
                            sw.Dispose();
                            sw.Close();

                            Process processDB = Process.Start("DBRestore.bat");
                            do
                            {//dont perform anything
                            }
                            while (!processDB.HasExited);
                            {
                                msg = "Banco de Dados " + strDatabaseName + " Foi Restaurado com Sucesso.";
                                UpdateStatusBar(msg);
                            }
                        }
                        else
                        {
                            msg = "Por favor, indique o caminho para salvar e obter a cópia de segurança!";
                        }
                    }
                }
                else
                {
                    msg = "Por favor, informe o nome do banco de dados para restaurar!";
                }
            }
            catch (Exception ex)
            { }

        }

        private bool checkDBExists(string strdatabase)
        {
            try
            {
                string DBlist = "SELECT datname FROM pg_database WHERE datistemplate IS FALSE AND datallowconn IS TRUE AND datname!='postgres';";
                DataSet ds = new DataSet();
                ds = GetData(DBlist);
                bool databaseExists = false;
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (ds.Tables[0].Rows[i][0].ToString() == strdatabase)
                    {
                        databaseExists = true;
                        break;
                    }
                }
                if (databaseExists)//existing database
                {
                    //fechar as conexões DB
                    string str = "select pg_terminate_backend(procpid) from pg_stat_activity where datname='" + strdatabase + "'";
                    ExecuteQuery(str);
                    //drop o database
                    string str1 = "drop database \"" + strdatabase + "\" ";
                    ExecuteQuery(str1);

                    string str2 = "create database \"" + strdatabase + "\" ";
                    ExecuteQuery(str2);

                    return true;
                }
                else
                {
                    string str = "create database \"" + strdatabase + "\" ";
                    ExecuteQuery(str);
                    Thread.Sleep(1000);
                    return true;
                }

                //return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool ExecuteQuery(string strQuery)
        {
            bool bstatus = false;
            try
            {
                NpgsqlConnection m_NpgsqlConnection = new NpgsqlConnection(strConnection);
                int snReturnValue = 0;

                try
                {
                    if (m_NpgsqlConnection.State != ConnectionState.Open)
                        m_NpgsqlConnection.Open();
                    if (m_NpgsqlConnection.State == ConnectionState.Open)
                    {
                        NpgsqlCommand objSqlCommand = new NpgsqlCommand(strQuery, m_NpgsqlConnection);

                        snReturnValue = objSqlCommand.ExecuteNonQuery();
                        if (snReturnValue == -1)
                            bstatus = false;
                        else
                            bstatus = true;
                    }
                    if (m_NpgsqlConnection.State == ConnectionState.Open)
                        m_NpgsqlConnection.Close();

                    if (m_NpgsqlConnection != null)
                        m_NpgsqlConnection.Dispose();
                }
                catch (Exception ex)
                {
                    bstatus = false;

                    if (m_NpgsqlConnection.State == ConnectionState.Open)
                        m_NpgsqlConnection.Close();

                    if (m_NpgsqlConnection != null)
                        m_NpgsqlConnection.Dispose();
                }
            }
            catch (Exception ex)
            { }
            return bstatus;

        }

        public DataSet GetData(string strQuery)
        {
            DataSet objDataSet = new DataSet();
            try
            {
                // if (m_NpgsqlConnection == null)
                {
                    m_NpgsqlConnection = new NpgsqlConnection(strConnection);
                }

                NpgsqlDataAdapter objSqlAdapter = new NpgsqlDataAdapter(strQuery, m_NpgsqlConnection);
                objSqlAdapter.Fill(objDataSet);
                return objDataSet;
            }
            catch (Exception Ex)
            {
                UpdateStatusBar("Falha ao Estabelecer uma Conexão Com Banco de Dados.");
                objDataSet = null;
                return objDataSet;
            }
        }

        public void CarregaConfiguracao()
        {
            this.txtUsuario.Text = "postgres";
            this.txtServidor.Text = "127.0.0.1";
            this.txtPort.Text = "5432";
            this.txtSnh.Text = "admin";
            this.txtCriarBanco.Text = string.Empty;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.txtCriarBanco.Text == string.Empty)
            {
                UpdateStatusBar("Favor Informar o Nome do Banco De Dados.");
                this.txtCriarBanco.Focus();
            }
            else
            {
                CriarBanco(txtCriarBanco.Text);
            }
        }

        private void btnResetarConfig_Click(object sender, EventArgs e)
        {
            CarregaConfiguracao();
            this.textBox1.Text = string.Empty;
            UpdateStatusBar("Configuração Reinicializada.");
            GetBancoDados();
        }

    }

}
