﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PaginacaoGridview
{
    public partial class Principal : System.Web.UI.Page
    {
        protected string conexaoSQL = ConfigurationManager.ConnectionStrings["Northwind"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                this.PopularGrid();
        }

        private class Produtos
        {
            public int ProductID { get; set; }
            public string ProductName { get; set; }
            public int UnitsInStock { get; set; }
        }
                
        private List<Produtos> CarregarProdutos()
        {
            List<Produtos> listaRetorno = new List<Produtos>();
            using (SqlConnection objConexao = new SqlConnection(conexaoSQL))
            {
                string instrucaoSql = "SELECT ProductID, ProductName, UnitsInStock FROM PRODUCTS";
                using (SqlCommand objCommand = new SqlCommand(instrucaoSql, objConexao))
                {
                    try
                    {                        
                        objConexao.Open();
                        SqlDataReader reader = objCommand.ExecuteReader();
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                Produtos modelo = new Produtos();
                                modelo.ProductID = Convert.ToInt32(reader["ProductID"].ToString());
                                modelo.ProductName = reader["ProductName"].ToString();
                                modelo.UnitsInStock = Convert.ToInt32(reader["UnitsInStock"].ToString());
                                listaRetorno.Add(modelo);
                            }
                            
                        }
                    }
                    catch
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Aviso", "alert('Erro no método!');", true);
                    }
                    finally
                    {
                        objConexao.Close();
                    }
                }
            }
            return listaRetorno;
        }
        private void PopularGrid()
        {
            var listaProdutos = this.CarregarProdutos();
            grdProdutos.DataSource = listaProdutos != null && listaProdutos.Count > 0 ? listaProdutos : null;
            grdProdutos.DataBind();
        }

        protected void grdProdutos_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdProdutos.PageIndex = e.NewPageIndex;
            this.PopularGrid();
        }

        protected void grdProdutos_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    e.Row.BackColor = e.Row.RowState == DataControlRowState.Alternate ? Color.Yellow : e.Row.RowState == DataControlRowState.Normal ? Color.Green : Color.White;
            //}
        }
    }
}