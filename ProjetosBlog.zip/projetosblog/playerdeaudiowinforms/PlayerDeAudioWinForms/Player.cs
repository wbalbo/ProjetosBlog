﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace PlayerDeAudioWinForms
{
    public partial class Player : Form
    {
        public Player()
        {
            InitializeComponent();
        }

        [DllImport("winmm.dll")]
        private static extern long mciSendString(string lpstrCommand, StringBuilder lpstrReturnString, int uReturnLength, int hwndCallback);

        private string comando = string.Empty;

        #region Métodos

        private void Abrir(string arquivo)
        {
            comando = "open \"" + arquivo + "\" type MPEGVideo alias TocadorMP3";
            mciSendString(comando, null, 0, 0);
        }

        private void Tocar()
        {
            if (lblMusica.Text.Equals("Música:"))
                MessageBox.Show("Escolha e abra a música antes!");
            else
            {
                comando = "play TocadorMP3";
                mciSendString(comando, null, 0, 0);
            }
        }

        private void Pausar()
        {
            if (lblMusica.Text.Equals("Música:"))
                MessageBox.Show("Escolha e abra a música antes!");
            else
            {
                comando = "pause TocadorMP3";
                mciSendString(comando, null, 0, 0);
            }
        }

        private void Parar()
        {
            comando = "stop TocadorMP3";
            mciSendString(comando, null, 0, 0);

            comando = "close TocadorMP3";
            mciSendString(comando, null, 0, 0);

            lblMusica.Text = "Música:";
        }

        #endregion

        #region Eventos

        private void btnAbrir_Click(object sender, EventArgs e)
        {
            ofdMusica.ShowDialog();
        }

        private void btnTocar_Click(object sender, EventArgs e)
        {
            this.Tocar();
        }

        private void btnPausar_Click(object sender, EventArgs e)
        {
            this.Pausar();
        }

        private void btnParar_Click(object sender, EventArgs e)
        {
            this.Parar();
        }

        private void ofdMusica_FileOk(object sender, CancelEventArgs e)
        {
            lblMusica.Text = "Música:" + ofdMusica.SafeFileName;
            this.Abrir(ofdMusica.FileName);
        }

        #endregion
    }
}
